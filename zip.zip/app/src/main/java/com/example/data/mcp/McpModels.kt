package com.example.data.mcp

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Supported MCP integrations and third-party tools
 */
enum class McpIntegrationType(
    val id: String,
    val displayNameArabic: String,
    val descriptionArabic: String,
    val categoryArabic: String,
    val defaultEndpoint: String,
    val placeholderToken: String,
    val docsHint: String
) {
    NOTION(
        id = "notion",
        displayNameArabic = "Notion (الملاحظات وقواعد البيانات)",
        descriptionArabic = "الاتصال بمساحة عمل Notion للبحث في الصفحات، قراءة المستندات، وإنشاء الملاحظات آلياً.",
        categoryArabic = "إنتاجية وتنظيم",
        defaultEndpoint = "https://api.notion.com/v1",
        placeholderToken = "secret_...",
        docsHint = "احصل على رمز التكامل من notion.so/my-integrations"
    ),
    CANVA(
        id = "canva",
        displayNameArabic = "Canva (التصميم والجرافيك)",
        descriptionArabic = "توليد قوالب التصميم، البحث في تصاميم السوشيال ميديا، والملصقات والعروض التقديمية.",
        categoryArabic = "تصميم وإبداع",
        defaultEndpoint = "https://api.canva.com/v1",
        placeholderToken = "canva_pat_...",
        docsHint = "أنشئ رمز الوصول من Canva Developers Portal"
    ),
    ADOBE(
        id = "adobe",
        displayNameArabic = "Adobe Creative Cloud & Express",
        descriptionArabic = "البحث في أصول ومكتبات Adobe Stock و Creative Cloud وتجهيز موجهات التعديل.",
        categoryArabic = "تصميم وإبداع",
        defaultEndpoint = "https://stock.adobe.io/Rest/Media/1/Search/Files",
        placeholderToken = "Bearer ... / Client ID",
        docsHint = "مفتاح الوصول من Adobe Developer Console"
    ),
    GITHUB(
        id = "github",
        displayNameArabic = "GitHub (المستودعات والبرمجة)",
        descriptionArabic = "البحث في المستودعات، قراءة ملفات الكود، ومتابعة قضايا البرمجة (Issues).",
        categoryArabic = "برمجة ومطورين",
        defaultEndpoint = "https://api.github.com",
        placeholderToken = "ghp_...",
        docsHint = "رمز الوصول الشخصي من إعدادات GitHub Developer Settings"
    ),
    WEB_SEARCH(
        id = "web_search",
        displayNameArabic = "بحث الويب المباشر (Live Web Search)",
        descriptionArabic = "أداة تصفح وبحث حقيقي على الإنترنت لجلب أحدث المعلومات والأخبار والمصادر.",
        categoryArabic = "معلومات وأبحاث",
        defaultEndpoint = "https://html.duckduckgo.com/html",
        placeholderToken = "غير مطلوب (متاح مجاناً)",
        docsHint = "مفعلة وتعمل مباشرة بدون مفتاح خارجي"
    ),
    CUSTOM_MCP(
        id = "custom_mcp",
        displayNameArabic = "خادم MCP مخصص (Model Context Protocol)",
        descriptionArabic = "الاتصال بأي خادم MCP محلي أو سحابي يدعم بروتوكول JSON-RPC 2.0 عبر HTTP/SSE.",
        categoryArabic = "بروتوكول مخصص",
        defaultEndpoint = "http://10.0.2.2:8000/mcp",
        placeholderToken = "Authorization Token (اختياري)",
        docsHint = "أدخل عنوان الخادم مثل http://localhost:8000 أو خادمك الخاص"
    )
}

/**
 * Configuration state for an individual MCP service
 */
data class McpServiceConfig(
    val type: McpIntegrationType,
    val isEnabled: Boolean = false,
    val token: String = "",
    val endpoint: String = type.defaultEndpoint,
    val extraParam: String = "", // e.g. Notion database ID or Adobe client ID
    val lastTestedSuccess: Boolean? = null,
    val lastStatusMessage: String? = null
)

/**
 * Definition of an individual tool that the AI agent can call
 */
data class McpToolDefinition(
    val id: String,
    val serviceType: McpIntegrationType,
    val nameArabic: String,
    val descriptionArabic: String,
    val exampleUsage: String
)

/**
 * Result of a tool call
 */
data class ToolCallResult(
    val toolId: String,
    val toolName: String,
    val serviceType: McpIntegrationType,
    val isSuccess: Boolean,
    val outputText: String,
    val rawJson: String = "",
    val latencyMs: Long = 0
)

/**
 * In-chat tool call representation
 */
data class ChatToolInvocation(
    val toolId: String,
    val toolName: String,
    val serviceType: McpIntegrationType,
    val parameters: Map<String, String>,
    val isExecuting: Boolean = false,
    val result: ToolCallResult? = null
)
