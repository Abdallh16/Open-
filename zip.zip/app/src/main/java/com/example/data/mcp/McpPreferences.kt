package com.example.data.mcp

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

class McpPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("nexus_ai_mcp_prefs", Context.MODE_PRIVATE)

    private val _configsFlow = MutableStateFlow(loadAllConfigs())
    val configsFlow: StateFlow<Map<McpIntegrationType, McpServiceConfig>> = _configsFlow.asStateFlow()

    fun getAllConfigs(): Map<McpIntegrationType, McpServiceConfig> = _configsFlow.value

    fun getConfig(type: McpIntegrationType): McpServiceConfig {
        return _configsFlow.value[type] ?: defaultFor(type)
    }

    fun updateConfig(config: McpServiceConfig) {
        val json = JSONObject().apply {
            put("isEnabled", config.isEnabled)
            put("token", config.token.trim())
            put("endpoint", config.endpoint.trim())
            put("extraParam", config.extraParam.trim())
            if (config.lastTestedSuccess != null) {
                put("lastTestedSuccess", config.lastTestedSuccess)
            }
            if (config.lastStatusMessage != null) {
                put("lastStatusMessage", config.lastStatusMessage)
            }
        }
        prefs.edit().putString(KEY_PREFIX + config.type.name, json.toString()).apply()

        val updatedMap = _configsFlow.value.toMutableMap()
        updatedMap[config.type] = config
        _configsFlow.value = updatedMap
    }

    fun updateTestResult(type: McpIntegrationType, success: Boolean, message: String) {
        val current = getConfig(type)
        val updated = current.copy(
            lastTestedSuccess = success,
            lastStatusMessage = message
        )
        updateConfig(updated)
    }

    private fun loadAllConfigs(): Map<McpIntegrationType, McpServiceConfig> {
        val map = mutableMapOf<McpIntegrationType, McpServiceConfig>()
        for (type in McpIntegrationType.entries) {
            val rawJson = prefs.getString(KEY_PREFIX + type.name, null)
            if (rawJson != null) {
                try {
                    val obj = JSONObject(rawJson)
                    map[type] = McpServiceConfig(
                        type = type,
                        isEnabled = obj.optBoolean("isEnabled", type == McpIntegrationType.WEB_SEARCH),
                        token = obj.optString("token", ""),
                        endpoint = obj.optString("endpoint", type.defaultEndpoint),
                        extraParam = obj.optString("extraParam", ""),
                        lastTestedSuccess = if (obj.has("lastTestedSuccess")) obj.optBoolean("lastTestedSuccess") else null,
                        lastStatusMessage = if (obj.has("lastStatusMessage")) obj.optString("lastStatusMessage") else null
                    )
                } catch (_: Exception) {
                    map[type] = defaultFor(type)
                }
            } else {
                map[type] = defaultFor(type)
            }
        }
        return map
    }

    private fun defaultFor(type: McpIntegrationType): McpServiceConfig {
        // Web search enabled by default as a baseline real tool
        return McpServiceConfig(
            type = type,
            isEnabled = type == McpIntegrationType.WEB_SEARCH,
            token = "",
            endpoint = type.defaultEndpoint,
            extraParam = ""
        )
    }

    companion object {
        private const val KEY_PREFIX = "mcp_service_"

        @Volatile
        private var INSTANCE: McpPreferences? = null

        fun getInstance(context: Context): McpPreferences {
            return INSTANCE ?: synchronized(this) {
                val instance = McpPreferences(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
