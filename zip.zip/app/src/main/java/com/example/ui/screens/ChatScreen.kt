package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.ConversationEntity
import com.example.data.local.MessageEntity
import com.example.data.mcp.McpIntegrationType
import com.example.ui.components.MarkdownContent
import com.example.ui.components.TypingIndicator
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalDark
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceVariant
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PurpleDeep
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.ChatViewModel
import com.example.util.DateFormatter
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun MainChatScreen(
    viewModel: ChatViewModel,
    onNavigateToSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    val apiSettings by viewModel.apiSettings.collectAsState()
    val isOnline by viewModel.isOnline.collectAsState()
    val allConversations by viewModel.allConversations.collectAsState()
    val currentConvId by viewModel.currentConversationId.collectAsState()
    val currentConv by viewModel.currentConversation.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val isGenerating by viewModel.isGenerating.collectAsState()
    val activeToolExecuting by viewModel.activeToolExecuting.collectAsState()
    val mcpConfigs by viewModel.mcpConfigs.collectAsState()

    var inputText by remember { mutableStateOf("") }
    var showClearConfirmDialog by remember { mutableStateOf(false) }
    var conversationToDelete by remember { mutableStateOf<ConversationEntity?>(null) }
    var showMcpSheet by remember { mutableStateOf(false) }

    val listState = rememberLazyListState()
    val activeToolsCount = viewModel.getActiveToolsCount()

    // Handle back button to close drawer if open
    BackHandler(enabled = drawerState.isOpen) {
        coroutineScope.launch { drawerState.close() }
    }

    // Auto-scroll when new messages arrive
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.scrollToItem(messages.size - 1)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = false, // Critical: prevents RTL swipe gesture glitch where drawer snaps back immediately!
        scrimColor = Color.Black.copy(alpha = 0.65f),
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = CharcoalSurface,
                drawerContentColor = TextPrimary,
                modifier = Modifier
                    .fillMaxWidth(0.82f)
                    .widthIn(max = 310.dp)
            ) {
                // Top Header in Drawer: Settings button & New Chat
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(PurplePrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "Nexus AI",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = TextPrimary
                                )
                                Text(
                                    text = if (apiSettings.isConfigured) apiSettings.model else "يحتاج تهيئة",
                                    fontSize = 11.sp,
                                    color = if (apiSettings.isConfigured) CyanAccent else Color(0xFFF59E0B)
                                )
                            }
                        }

                        // Settings Button in Drawer Header
                        IconButton(
                            onClick = {
                                coroutineScope.launch { drawerState.close() }
                                onNavigateToSettings()
                            },
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(CharcoalSurfaceVariant)
                                .testTag("drawer_settings_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Settings,
                                contentDescription = "الإعدادات",
                                tint = TextPrimary
                            )
                        }
                    }

                    // MCP Status Quick Bar inside Drawer
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CharcoalDark)
                            .border(1.dp, CharcoalBorder, RoundedCornerShape(8.dp))
                            .clickable {
                                coroutineScope.launch { drawerState.close() }
                                showMcpSheet = true
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Hub,
                                contentDescription = null,
                                tint = CyanAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "بروتوكول MCP: $activeToolsCount أدوات مفعّلة",
                                color = CyanAccent,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }

                    // New Chat Action Button
                    Button(
                        onClick = {
                            viewModel.startNewConversation()
                            inputText = ""
                            coroutineScope.launch { drawerState.close() }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("drawer_new_chat_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.size(8.dp))
                        Text(
                            text = "محادثة جديدة",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }

                HorizontalDivider(color = CharcoalBorder, thickness = 1.dp)

                // Bottom: Conversations List in Drawer
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 4.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "سجل المحادثات",
                            color = TextSecondary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        if (allConversations.isNotEmpty()) {
                            Text(
                                text = "${allConversations.size}",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }

                    if (allConversations.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(top = 40.dp),
                            contentAlignment = Alignment.TopCenter
                        ) {
                            Text(
                                text = "لا توجد محادثات سابقة حتى الآن",
                                color = TextMuted,
                                fontSize = 13.sp
                            )
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            contentPadding = PaddingValues(top = 6.dp, bottom = 16.dp)
                        ) {
                            items(allConversations, key = { it.id }) { conv ->
                                val isSelected = conv.id == currentConvId
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (isSelected) PurplePrimary.copy(alpha = 0.2f) else Color.Transparent
                                        )
                                        .border(
                                            1.dp,
                                            if (isSelected) PurplePrimary.copy(alpha = 0.5f) else Color.Transparent,
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable {
                                            viewModel.selectConversation(conv.id)
                                            coroutineScope.launch { drawerState.close() }
                                        }
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(
                                        modifier = Modifier.weight(1f),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Chat,
                                            contentDescription = null,
                                            tint = if (isSelected) PurplePrimary else TextMuted,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = conv.title,
                                                color = if (isSelected) TextPrimary else TextSecondary,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                                fontSize = 13.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = DateFormatter.formatConversationDate(conv.updatedAt),
                                                color = TextMuted,
                                                fontSize = 10.sp
                                            )
                                        }
                                    }

                                    IconButton(
                                        onClick = { conversationToDelete = conv },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "حذف",
                                            tint = TextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        modifier = modifier
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = currentConv?.title ?: "Nexus AI",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(
                                    text = if (apiSettings.isConfigured) "${apiSettings.provider.displayNameArabic} • ${apiSettings.model}" else "يحتاج تهيئة المفتاح",
                                    color = if (apiSettings.isConfigured) CyanAccent else Color(0xFFF59E0B),
                                    fontSize = 11.sp
                                )
                                Text(text = "•", color = TextMuted, fontSize = 10.sp)
                                Text(
                                    text = "MCP: $activeToolsCount أدوات",
                                    color = PurplePrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    },
                    navigationIcon = {
                        IconButton(
                            onClick = { coroutineScope.launch { drawerState.open() } },
                            modifier = Modifier.testTag("chat_menu_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Menu,
                                contentDescription = "القائمة",
                                tint = TextPrimary
                            )
                        }
                    },
                    actions = {
                        // MCP Quick Sheet Action
                        IconButton(
                            onClick = { showMcpSheet = true },
                            modifier = Modifier.testTag("chat_mcp_hub_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Hub,
                                contentDescription = "أدوات MCP",
                                tint = CyanAccent
                            )
                        }

                        // New Chat icon
                        IconButton(
                            onClick = {
                                viewModel.startNewConversation()
                                inputText = ""
                            },
                            modifier = Modifier.testTag("chat_new_conv_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.AddComment,
                                contentDescription = "محادثة جديدة",
                                tint = PurplePrimary
                            )
                        }

                        if (messages.isNotEmpty()) {
                            IconButton(
                                onClick = { showClearConfirmDialog = true },
                                modifier = Modifier.testTag("chat_clear_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CleaningServices,
                                    contentDescription = "مسح المحادثة",
                                    tint = TextSecondary
                                )
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = CharcoalDark
                    )
                )
            },
            containerColor = CharcoalDark,
            contentWindowInsets = WindowInsets.statusBars
        ) { innerPadding ->
            // SINGLE COLUMN: Messages take weight(1f), Input sits flush at bottom with single imePadding
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = innerPadding.calculateTopPadding())
                    .navigationBarsPadding()
                    .imePadding()
            ) {
                // 1. MESSAGES AREA: takes full available height between topBar and input bar
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                ) {
                    if (messages.isEmpty() && !isGenerating) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(CircleShape)
                                    .background(PurpleDeep.copy(alpha = 0.4f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    tint = CyanAccent,
                                    modifier = Modifier.size(28.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = "مرحباً بك في Nexus AI",
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = "المساعد الذكي مدعوم ببروتوكول MCP للتفاعل مع حساباتك في Notion، Canva، Adobe، GitHub، وبحث الويب المباشر.",
                                color = TextSecondary,
                                fontSize = 13.sp,
                                textAlign = TextAlign.Center,
                                lineHeight = 20.sp
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // Quick Inspiration Chips for MCP Tools
                            Text(
                                text = "جرّب أحد أوامر الـ MCP السريعة:",
                                color = TextMuted,
                                fontSize = 11.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                val samples = listOf(
                                    "🌐 ابحث على الويب عن آخر أخبار الذكاء الاصطناعي",
                                    "🎨 ابحث في كانفا عن قوالب إنستغرام لرمضان",
                                    "📝 ابحث في نوشن عن ملاحظات الاجتماع",
                                    "🖌️ ابحث في أدوبي عن صور وخلفيات تقنية 3D",
                                    "🐙 ابحث في جيت هاب عن jetpack compose"
                                )
                                samples.forEach { sample ->
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(CharcoalSurface)
                                            .border(1.dp, CharcoalBorder, RoundedCornerShape(8.dp))
                                            .clickable {
                                                inputText = sample.substringAfter(" ")
                                            }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = sample,
                                            color = TextSecondary,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    } else {
                        LazyColumn(
                            state = listState,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(horizontal = 10.dp),
                            contentPadding = PaddingValues(top = 10.dp, bottom = 10.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(messages, key = { it.id }) { msg ->
                                DirectChatMessageItem(
                                    message = msg,
                                    onCopy = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("AI Message", msg.content)
                                        clipboard.setPrimaryClip(clip)
                                        Toast.makeText(context, "تم النسخ إلى الحافظة", Toast.LENGTH_SHORT).show()
                                    }
                                )
                            }

                            // Active MCP Tool Execution Indicator
                            if (activeToolExecuting != null) {
                                item {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(Color(0xFF10243E))
                                            .border(1.dp, CyanAccent.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                                            .padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(16.dp),
                                            color = CyanAccent,
                                            strokeWidth = 2.dp
                                        )
                                        Text(
                                            text = "⚡ جارٍ تنفيذ أداة بروتوكول MCP: $activeToolExecuting…",
                                            color = CyanAccent,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }

                            if (isGenerating && activeToolExecuting == null) {
                                item {
                                    TypingIndicator(
                                        modifier = Modifier
                                            .padding(start = 4.dp)
                                            .testTag("typing_indicator")
                                    )
                                }
                            }
                        }
                    }
                }

                // 2. INPUT BAR: Sits right below the messages, resting on bottom edge or keyboard cleanly
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(CharcoalSurface)
                        .border(1.dp, CharcoalBorder)
                ) {
                    if (!apiSettings.isConfigured) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF261D0F))
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = Color(0xFFF59E0B),
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = "أدخل مفتاح API في الإعدادات أو استخدم أوامر MCP المباشرة",
                                    color = Color(0xFFFDE68A),
                                    fontSize = 11.sp
                                )
                            }
                            TextButton(onClick = onNavigateToSettings) {
                                Text(text = "الإعدادات", color = CyanAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }

                    if (!isOnline) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF331618))
                                .padding(horizontal = 12.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(imageVector = Icons.Default.WifiOff, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(14.dp))
                            Text(text = "لا يوجد اتصال بالإنترنت", color = Color(0xFFFCA5A5), fontSize = 11.sp)
                        }
                    }

                    // Input Field Row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = inputText,
                            onValueChange = { inputText = it },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_input_field"),
                            placeholder = {
                                Text(
                                    text = "اسأل أي سؤال، أو استدع أداة (Notion، Canva، الويب)...",
                                    color = TextMuted,
                                    fontSize = 13.sp
                                )
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PurplePrimary,
                                unfocusedBorderColor = CharcoalBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedContainerColor = CharcoalDark,
                                unfocusedContainerColor = CharcoalDark,
                                cursorColor = PurplePrimary
                            ),
                            shape = RoundedCornerShape(18.dp),
                            maxLines = 4,
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default)
                        )

                        if (isGenerating) {
                            IconButton(
                                onClick = { viewModel.stopGeneration() },
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(ErrorRed)
                                    .testTag("chat_stop_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Stop,
                                    contentDescription = "إيقاف",
                                    tint = Color.White
                                )
                            }
                        } else {
                            IconButton(
                                onClick = {
                                    if (inputText.isNotBlank()) {
                                        val toSend = inputText
                                        inputText = ""
                                        viewModel.sendMessage(toSend)
                                    }
                                },
                                enabled = inputText.isNotBlank(),
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(if (inputText.isNotBlank()) PurplePrimary else CharcoalSurfaceVariant)
                                    .testTag("chat_send_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "إرسال",
                                    tint = if (inputText.isNotBlank()) Color.White else TextMuted
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // MCP Quick Bottom Sheet
    if (showMcpSheet) {
        ModalBottomSheet(
            onDismissRequest = { showMcpSheet = false },
            containerColor = CharcoalSurface,
            contentColor = TextPrimary
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Hub, contentDescription = null, tint = CyanAccent)
                        Text(
                            text = "مركز أدوات MCP المتصلة",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    TextButton(onClick = {
                        showMcpSheet = false
                        onNavigateToSettings()
                    }) {
                        Text("إدارة في الإعدادات", color = PurplePrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }

                Text(
                    text = "الأدوات النشطة حالياً يمكن للوكيل الذكي استدعاؤها أو يمكنك تجربتها بضغطة واحدة:",
                    color = TextSecondary,
                    fontSize = 12.sp
                )

                // Integrations Quick Status
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(McpIntegrationType.entries) { type ->
                        val config = mcpConfigs[type]
                        val isEnabled = config?.isEnabled == true
                        val hasToken = config?.token?.isNotBlank() == true || type == McpIntegrationType.WEB_SEARCH

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(CharcoalDark)
                                .border(1.dp, CharcoalBorder, RoundedCornerShape(10.dp))
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = type.displayNameArabic,
                                    color = TextPrimary,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = if (isEnabled) "✅ مفعّل | " + if (hasToken) "البيانات مكتملة" else "يحتاج إضافة Token" else "معطّل",
                                    color = if (isEnabled && hasToken) SuccessGreen else WarningAmber,
                                    fontSize = 11.sp
                                )
                            }

                            if (isEnabled) {
                                TextButton(
                                    onClick = {
                                        showMcpSheet = false
                                        val prompt = when (type) {
                                            McpIntegrationType.NOTION -> "ابحث في نوشن عن ملاحظات"
                                            McpIntegrationType.CANVA -> "ابحث في كانفا عن قوالب تصاميم حديثة"
                                            McpIntegrationType.ADOBE -> "ابحث في أدوبي عن صور رقمية وخلفيات"
                                            McpIntegrationType.GITHUB -> "ابحث في جيت هاب عن jetpack compose"
                                            McpIntegrationType.WEB_SEARCH -> "ابحث على الويب عن أخبار التقنية اليوم"
                                            McpIntegrationType.CUSTOM_MCP -> "استدعاء خادم MCP المخصص"
                                        }
                                        viewModel.sendMessage(prompt)
                                    }
                                ) {
                                    Text("تجربة سريعة", color = CyanAccent, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Delete conversation confirmation dialog
    conversationToDelete?.let { conv ->
        AlertDialog(
            onDismissRequest = { conversationToDelete = null },
            title = { Text(text = "حذف المحادثة", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text(text = "هل أنت متأكد من حذف محادثة \"${conv.title}\"؟", color = TextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteConversation(conv.id)
                        conversationToDelete = null
                    }
                ) {
                    Text(text = "حذف", color = ErrorRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { conversationToDelete = null }) {
                    Text(text = "إلغاء", color = TextSecondary)
                }
            },
            containerColor = CharcoalSurfaceVariant
        )
    }

    // Clear messages confirmation dialog
    if (showClearConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showClearConfirmDialog = false },
            title = { Text(text = "مسح المحادثة", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text(text = "هل أنت متأكد من مسح جميع رسائل هذه المحادثة؟", color = TextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearCurrentConversation()
                        showClearConfirmDialog = false
                    }
                ) {
                    Text(text = "مسح", color = ErrorRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showClearConfirmDialog = false }) {
                    Text(text = "إلغاء", color = TextSecondary)
                }
            },
            containerColor = CharcoalSurfaceVariant
        )
    }
}

@Composable
fun DirectChatMessageItem(
    message: MessageEntity,
    onCopy: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isUser = message.role == "user"
    val isMcpToolMessage = message.content.contains("### ⚡") || message.content.contains("أداة MCP")

    Row(
        modifier = modifier
            .fillMaxWidth()
            .testTag("message_bubble_${message.id}"),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top
    ) {
        if (!isUser) {
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(if (isMcpToolMessage) CyanAccent else PurplePrimary),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isMcpToolMessage) Icons.Default.Hub else Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = if (isMcpToolMessage) Color.Black else Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
        }

        // Column taking full width for AI, and constrained width for user
        Column(
            modifier = if (isUser) {
                Modifier
                    .widthIn(min = 40.dp, max = 310.dp)
                    .padding(start = 32.dp)
            } else {
                Modifier
                    .weight(1f, fill = true)
                    .padding(end = 12.dp)
            },
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
        ) {
            Box(
                modifier = Modifier
                    .clip(
                        RoundedCornerShape(
                            topStart = 14.dp,
                            topEnd = 14.dp,
                            bottomStart = if (isUser) 14.dp else 2.dp,
                            bottomEnd = if (isUser) 2.dp else 14.dp
                        )
                    )
                    .background(
                        if (isUser) {
                            PurpleDeep
                        } else if (message.isError) {
                            Color(0xFF2B1214)
                        } else if (isMcpToolMessage) {
                            Color(0xFF0F172A)
                        } else {
                            CharcoalSurface
                        }
                    )
                    .border(
                        1.dp,
                        if (isUser) {
                            PurplePrimary.copy(alpha = 0.4f)
                        } else if (message.isError) {
                            ErrorRed.copy(alpha = 0.5f)
                        } else if (isMcpToolMessage) {
                            CyanAccent.copy(alpha = 0.5f)
                        } else {
                            CharcoalBorder
                        },
                        RoundedCornerShape(
                            topStart = 14.dp,
                            topEnd = 14.dp,
                            bottomStart = if (isUser) 14.dp else 2.dp,
                            bottomEnd = if (isUser) 2.dp else 14.dp
                        )
                    )
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                if (isUser) {
                    Text(
                        text = message.content,
                        color = Color.White,
                        fontSize = 15.sp,
                        lineHeight = 22.sp
                    )
                } else {
                    MarkdownContent(
                        content = message.content,
                        textColor = if (message.isError) Color(0xFFFCA5A5) else TextPrimary
                    )
                }
            }

            // Message timestamp and copy action
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.padding(top = 2.dp, start = 4.dp, end = 4.dp)
            ) {
                Text(
                    text = DateFormatter.formatMessageTime(message.timestamp),
                    color = TextMuted,
                    fontSize = 11.sp
                )

                if (!isUser && !message.isError) {
                    IconButton(
                        onClick = onCopy,
                        modifier = Modifier
                            .size(20.dp)
                            .testTag("copy_message_${message.id}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = "نسخ",
                            tint = TextMuted,
                            modifier = Modifier.size(13.dp)
                        )
                    }
                }
            }
        }

        if (isUser) {
            Spacer(modifier = Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .size(30.dp)
                    .clip(CircleShape)
                    .background(CharcoalSurfaceVariant),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = PurplePrimary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
