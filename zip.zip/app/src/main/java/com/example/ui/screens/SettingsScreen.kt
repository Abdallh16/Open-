package com.example.ui.screens

import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.SwitchAccessShortcut
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.mcp.McpIntegrationType
import com.example.data.mcp.McpServiceConfig
import com.example.data.preferences.ApiProvider
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalDark
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceVariant
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PurpleDeep
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.SettingsSection
import com.example.ui.viewmodel.SettingsViewModel
import com.example.ui.viewmodel.TestConnectionState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentSection by viewModel.currentSection.collectAsState()
    val notification by viewModel.statusNotification.collectAsState()

    // Handle back button: returns to HUB if inside sub-screen, or navigates back to Chat
    BackHandler {
        if (!viewModel.navigateBack()) {
            onNavigateBack()
        }
    }

    LaunchedEffect(notification) {
        notification?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearNotification()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = when (currentSection) {
                                SettingsSection.HUB -> "إعدادات Nexus AI"
                                SettingsSection.MODELS_AND_PROVIDERS -> "النموذج ومزودو الخدمة"
                                SettingsSection.MCP_INTEGRATIONS -> "توصيل MCP والتطبيقات"
                                SettingsSection.DATA_MANAGEMENT -> "إدارة المحادثات والبيانات"
                            },
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                        if (currentSection == SettingsSection.HUB) {
                            Text(
                                text = "اختر القسم الذي ترغب في تعديله وتخصيصه",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (!viewModel.navigateBack()) {
                                onNavigateBack()
                            }
                        },
                        modifier = Modifier.testTag("settings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = TextPrimary
                        )
                    }
                },
                actions = {
                    if (currentSection == SettingsSection.MODELS_AND_PROVIDERS) {
                        IconButton(
                            onClick = { viewModel.saveSettings() },
                            modifier = Modifier.testTag("settings_save_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Save,
                                contentDescription = "حفظ",
                                tint = PurplePrimary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CharcoalDark
                )
            )
        },
        containerColor = CharcoalDark,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Optional Fast-Tab switcher when inside sub-screens
            if (currentSection != SettingsSection.HUB) {
                ScrollableTabRow(
                    selectedTabIndex = when (currentSection) {
                        SettingsSection.MODELS_AND_PROVIDERS -> 0
                        SettingsSection.MCP_INTEGRATIONS -> 1
                        SettingsSection.DATA_MANAGEMENT -> 2
                        else -> 0
                    },
                    containerColor = CharcoalSurface,
                    contentColor = PurplePrimary,
                    edgePadding = 12.dp
                ) {
                    Tab(
                        selected = currentSection == SettingsSection.MODELS_AND_PROVIDERS,
                        onClick = { viewModel.setSection(SettingsSection.MODELS_AND_PROVIDERS) },
                        text = { Text("النموذج والمزودين", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    Tab(
                        selected = currentSection == SettingsSection.MCP_INTEGRATIONS,
                        onClick = { viewModel.setSection(SettingsSection.MCP_INTEGRATIONS) },
                        text = { Text("توصيل MCP", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    Tab(
                        selected = currentSection == SettingsSection.DATA_MANAGEMENT,
                        onClick = { viewModel.setSection(SettingsSection.DATA_MANAGEMENT) },
                        text = { Text("البيانات والذاكرة", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                    )
                }
            }

            AnimatedContent(
                targetState = currentSection,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "settings_section_transition"
            ) { section ->
                when (section) {
                    SettingsSection.HUB -> SettingsHubMenu(
                        viewModel = viewModel,
                        onOpenSection = { viewModel.setSection(it) }
                    )

                    SettingsSection.MODELS_AND_PROVIDERS -> ModelsAndProvidersSection(
                        viewModel = viewModel,
                        onNavigateBackToHub = { viewModel.setSection(SettingsSection.HUB) }
                    )

                    SettingsSection.MCP_INTEGRATIONS -> McpIntegrationsSection(
                        viewModel = viewModel,
                        onNavigateBackToHub = { viewModel.setSection(SettingsSection.HUB) }
                    )

                    SettingsSection.DATA_MANAGEMENT -> DataManagementSection(
                        viewModel = viewModel,
                        onNavigateBackToHub = { viewModel.setSection(SettingsSection.HUB) }
                    )
                }
            }
        }
    }
}

// ==============================================================================
// 1. SETTINGS HUB MENU (Main Menu with Section Cards as requested by user)
// ==============================================================================

@Composable
private fun SettingsHubMenu(
    viewModel: SettingsViewModel,
    onOpenSection: (SettingsSection) -> Unit,
    modifier: Modifier = Modifier
) {
    val provider by viewModel.provider.collectAsState()
    val model by viewModel.model.collectAsState()
    val apiKey by viewModel.apiKey.collectAsState()
    val mcpConfigs by viewModel.mcpConfigs.collectAsState()
    val activeToolsCount = viewModel.getActiveMcpToolsCount()

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                CharcoalSurfaceVariant,
                                Color(0xFF1E1738)
                            )
                        )
                    )
                    .border(
                        1.dp,
                        Brush.horizontalGradient(listOf(PurplePrimary.copy(alpha = 0.6f), ElectricBlue.copy(alpha = 0.6f))),
                        RoundedCornerShape(18.dp)
                    )
                    .padding(18.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(PurplePrimary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Tune,
                            contentDescription = null,
                            tint = PurplePrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "مركز الإعدادات المخصص",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "اختر القسم لتعديل إعدادات النماذج ومزودي الـ API، أو إدارة بروتوكول MCP والربط بالتطبيقات الخارجية.",
                            color = TextSecondary,
                            fontSize = 12.sp,
                            lineHeight = 18.sp
                        )
                    }
                }
            }
        }

        // Section 1 Card: Models and Providers
        item {
            SettingsCategoryCard(
                icon = Icons.Default.Tune,
                iconTint = PurplePrimary,
                iconBg = PurplePrimary.copy(alpha = 0.15f),
                title = "النموذج ومزودو الخدمة (AI Models)",
                description = "تحديد مزود الخدمة (OpenAI, Groq, OpenRouter, Together, خادم محلي)، ضبط مفتاح API، جلب النماذج الحية، ومطالب النظام.",
                badgeText = if (apiKey.isNotBlank()) "${provider.displayNameArabic} • ${model.ifBlank { "مضبوط" }}" else "يحتاج تهيئة",
                badgeColor = if (apiKey.isNotBlank()) SuccessGreen else WarningAmber,
                onClick = { onOpenSection(SettingsSection.MODELS_AND_PROVIDERS) },
                testTag = "hub_card_models_providers"
            )
        }

        // Section 2 Card: MCP & External Integrations
        item {
            SettingsCategoryCard(
                icon = Icons.Default.Hub,
                iconTint = CyanAccent,
                iconBg = CyanAccent.copy(alpha = 0.15f),
                title = "توصيل بروتوكول MCP والتطبيقات الخارجية",
                description = "ربط حساباتك في Notion، Canva، Adobe، GitHub، وبحث الويب المباشر عبر أدوات MCP لتمكين الوكيل من تنفيذ مهام حقيقية.",
                badgeText = "$activeToolsCount أدوات MCP مفعّلة",
                badgeColor = if (activeToolsCount > 0) CyanAccent else TextMuted,
                onClick = { onOpenSection(SettingsSection.MCP_INTEGRATIONS) },
                testTag = "hub_card_mcp_integrations"
            )
        }

        // Section 3 Card: Data Management
        item {
            SettingsCategoryCard(
                icon = Icons.Default.Storage,
                iconTint = WarningAmber,
                iconBg = WarningAmber.copy(alpha = 0.15f),
                title = "إدارة المحادثات والبيانات المحلية",
                description = "مسح سجل المحادثات والرسائل المحفوظة، تفريغ الذاكرة المؤقتة، والحفاظ على خصوصية وسرية البيانات.",
                badgeText = "تخزين محلي مشفر",
                badgeColor = TextSecondary,
                onClick = { onOpenSection(SettingsSection.DATA_MANAGEMENT) },
                testTag = "hub_card_data_management"
            )
        }

        // System Diagnostic Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(CharcoalBorder))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = null,
                            tint = ElectricBlue,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "معلومات النظام ومحرك الذكاء الاصطناعي",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Text(
                        text = "• محرك الاستجابة: بروتوكول MCP v1.0 المتوافق مع معايير الذكاء الاصطناعي\n" +
                                "• دعم المحادثات: RTL كامل للغة العربية مع معالجة Markdown وأكواد برمجية\n" +
                                "• تخزين آمن محلياً على جهازك دون إرسال بيانات إضافية للخوادم الخارجية",
                        color = TextMuted,
                        fontSize = 11.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsCategoryCard(
    icon: ImageVector,
    iconTint: Color,
    iconBg: Color,
    title: String,
    description: String,
    badgeText: String,
    badgeColor: Color,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onClick() }
            .testTag(testTag),
        colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
        shape = RoundedCornerShape(16.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(CharcoalBorder))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(iconBg),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = iconTint,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = title,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = description,
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    // Badge Chip
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(badgeColor.copy(alpha = 0.15f))
                            .border(1.dp, badgeColor.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = badgeText,
                            color = badgeColor,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier
                    .size(20.dp)
                    .padding(start = 8.dp)
            )
        }
    }
}

// ==============================================================================
// 2. MODELS AND PROVIDERS SECTION (Moved from original monolithic screen)
// ==============================================================================

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ModelsAndProvidersSection(
    viewModel: SettingsViewModel,
    onNavigateBackToHub: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val provider by viewModel.provider.collectAsState()
    val baseUrl by viewModel.baseUrl.collectAsState()
    val apiKey by viewModel.apiKey.collectAsState()
    val model by viewModel.model.collectAsState()
    val systemPrompt by viewModel.systemPrompt.collectAsState()
    val temperature by viewModel.temperature.collectAsState()
    val availableModels by viewModel.availableModels.collectAsState()
    val isFetchingModels by viewModel.isFetchingModels.collectAsState()
    val testState by viewModel.testState.collectAsState()

    var isApiKeyVisible by remember { mutableStateOf(false) }
    var showModelsDropdown by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Provider Selection & Connection Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(CharcoalBorder))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "1. مزود الخدمة وعنوان الاتصال (Provider & Base URL)",
                        color = PurplePrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    // Provider Chips
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ApiProvider.entries.forEach { p ->
                            val selected = p == provider
                            FilterChip(
                                selected = selected,
                                onClick = { viewModel.selectProvider(p) },
                                label = {
                                    Text(
                                        text = p.displayNameArabic,
                                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PurplePrimary.copy(alpha = 0.25f),
                                    selectedLabelColor = PurplePrimary,
                                    containerColor = CharcoalSurfaceVariant,
                                    labelColor = TextSecondary
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = selected,
                                    borderColor = CharcoalBorder,
                                    selectedBorderColor = PurplePrimary
                                )
                            )
                        }
                    }

                    // Base URL
                    Text(
                        text = "عنوان الخادم (Base URL)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = baseUrl,
                        onValueChange = { viewModel.setBaseUrl(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("endpoint_input_field"),
                        placeholder = { Text("https://api.openai.com/v1", color = TextMuted, fontSize = 13.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = CharcoalBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CharcoalDark,
                            unfocusedContainerColor = CharcoalDark
                        ),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )

                    // API Key
                    Text(
                        text = "مفتاح API الخاص بك (Secret Key)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = { viewModel.setApiKey(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("api_key_input_field"),
                        placeholder = { Text("sk-...", color = TextMuted, fontSize = 13.sp) },
                        visualTransformation = if (isApiKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = clipboard.primaryClip
                                        if (clip != null && clip.itemCount > 0) {
                                            val pasted = clip.getItemAt(0).text?.toString().orEmpty()
                                            if (pasted.isNotBlank()) {
                                                viewModel.setApiKey(pasted)
                                                Toast.makeText(context, "تم لصق المفتاح", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentPaste,
                                        contentDescription = "لصق",
                                        tint = CyanAccent,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                IconButton(onClick = { isApiKeyVisible = !isApiKeyVisible }) {
                                    Icon(
                                        imageVector = if (isApiKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = null,
                                        tint = TextSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = CharcoalBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CharcoalDark,
                            unfocusedContainerColor = CharcoalDark
                        ),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                }
            }
        }

        // Model Selection & Live Fetching Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(CharcoalBorder))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "2. فحص النماذج واختيار النموذج المناسب",
                        color = ElectricBlue,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    // Fetch models button
                    Button(
                        onClick = {
                            viewModel.saveSettings()
                            viewModel.fetchModelsLive()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("fetch_models_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                        shape = RoundedCornerShape(10.dp),
                        enabled = !isFetchingModels
                    ) {
                        if (isFetchingModels) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.size(8.dp))
                            Text("جارٍ جلب النماذج…", color = Color.White, fontSize = 13.sp)
                        } else {
                            Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.size(8.dp))
                            Text("فحص النماذج المتوفرة واختبار الاتصال", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }

                    // Test Status Banner
                    when (val state = testState) {
                        is TestConnectionState.Success -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF0F2618))
                                    .border(1.dp, SuccessGreen, RoundedCornerShape(8.dp))
                                    .padding(10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen)
                                    Text(text = state.message, color = SuccessGreen, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                        is TestConnectionState.Error -> {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF291214))
                                    .border(1.dp, ErrorRed, RoundedCornerShape(8.dp))
                                    .padding(10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.Error, contentDescription = null, tint = ErrorRed)
                                    Text(text = state.message, color = Color(0xFFFCA5A5), fontSize = 12.sp)
                                }
                            }
                        }
                        else -> {}
                    }

                    // Selected Model Input / Dropdown Selector
                    Text(
                        text = "اسم النموذج المختار (Model ID)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp
                    )
                    Box(modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = model,
                            onValueChange = { viewModel.setModel(it) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("model_input_field"),
                            placeholder = { Text("مثال: gpt-4o-mini", color = TextMuted, fontSize = 13.sp) },
                            trailingIcon = {
                                if (availableModels.isNotEmpty()) {
                                    IconButton(onClick = { showModelsDropdown = true }) {
                                        Icon(
                                            imageVector = Icons.Default.ArrowDropDown,
                                            contentDescription = "قائمة النماذج",
                                            tint = CyanAccent,
                                            modifier = Modifier.size(28.dp)
                                        )
                                    }
                                }
                            },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PurplePrimary,
                                unfocusedBorderColor = CharcoalBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedContainerColor = CharcoalDark,
                                unfocusedContainerColor = CharcoalDark
                            ),
                            shape = RoundedCornerShape(10.dp),
                            singleLine = true
                        )

                        DropdownMenu(
                            expanded = showModelsDropdown,
                            onDismissRequest = { showModelsDropdown = false },
                            modifier = Modifier
                                .fillMaxWidth(0.85f)
                                .background(CharcoalSurfaceVariant)
                                .border(1.dp, CharcoalBorder)
                        ) {
                            availableModels.take(40).forEach { mName ->
                                DropdownMenuItem(
                                    text = {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = mName,
                                                color = if (mName == model) CyanAccent else TextPrimary,
                                                fontSize = 13.sp,
                                                fontWeight = if (mName == model) FontWeight.Bold else FontWeight.Normal
                                            )
                                            if (mName == model) {
                                                Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    },
                                    onClick = {
                                        viewModel.setModel(mName)
                                        showModelsDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    // Quick Chips
                    if (availableModels.isNotEmpty()) {
                        Text(
                            text = "اقتراحات سريعة (${availableModels.size} نموذج متوفر):",
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            availableModels.take(8).forEach { mName ->
                                val isSelected = mName == model
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) PurplePrimary.copy(alpha = 0.25f) else CharcoalSurfaceVariant)
                                        .border(1.dp, if (isSelected) PurplePrimary else CharcoalBorder, RoundedCornerShape(6.dp))
                                        .clickable { viewModel.setModel(mName) }
                                        .padding(horizontal = 8.dp, vertical = 5.dp)
                                ) {
                                    Text(
                                        text = mName,
                                        color = if (isSelected) PurplePrimary else TextSecondary,
                                        fontSize = 11.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // System Prompt & Creativity Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(CharcoalBorder))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "3. التوجيه المسبق ومستوى الإبداع",
                        color = CyanAccent,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )

                    Text(
                        text = "التوجيه المسبق (System Prompt)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium,
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = systemPrompt,
                        onValueChange = { viewModel.setSystemPrompt(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("system_prompt_input_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = CharcoalBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CharcoalDark,
                            unfocusedContainerColor = CharcoalDark
                        ),
                        shape = RoundedCornerShape(10.dp),
                        minLines = 2,
                        maxLines = 4
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "درجة الإبداع (Temperature):", color = TextPrimary, fontSize = 13.sp)
                        Text(text = String.format("%.2f", temperature), color = CyanAccent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Slider(
                        value = temperature,
                        onValueChange = { viewModel.setTemperature(it) },
                        valueRange = 0.0f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = PurplePrimary,
                            activeTrackColor = PurplePrimary,
                            inactiveTrackColor = CharcoalBorder
                        )
                    )
                }
            }
        }

        // Save & Return Actions
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        viewModel.saveSettings()
                        Toast.makeText(context, "تم حفظ الإعدادات بنجاح", Toast.LENGTH_SHORT).show()
                        onNavigateBackToHub()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("save_models_settings_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(imageVector = Icons.Default.Save, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.size(8.dp))
                    Text("حفظ التغييرات والعودة للقائمة", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

// ==============================================================================
// 3. MCP INTEGRATIONS SECTION (Requested New Tab/Screen for Notion, Canva, Adobe, etc.)
// ==============================================================================

@Composable
private fun McpIntegrationsSection(
    viewModel: SettingsViewModel,
    onNavigateBackToHub: () -> Unit,
    modifier: Modifier = Modifier
) {
    val mcpConfigs by viewModel.mcpConfigs.collectAsState()
    val testingType by viewModel.testingMcpType.collectAsState()
    val availableTools = viewModel.availableMcpTools

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // MCP Overview Hero Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        Brush.linearGradient(
                            listOf(
                                CharcoalSurfaceVariant,
                                Color(0xFF132238)
                            )
                        )
                    )
                    .border(
                        1.dp,
                        Brush.horizontalGradient(listOf(CyanAccent.copy(alpha = 0.6f), PurplePrimary.copy(alpha = 0.4f))),
                        RoundedCornerShape(16.dp)
                    )
                    .padding(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                            .background(CyanAccent.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Hub,
                                contentDescription = null,
                                tint = CyanAccent,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Text(
                            text = "بروتوكول سياق النموذج (Model Context Protocol)",
                            color = CyanAccent,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                    Text(
                        text = "يتيح MCP للوكيل الذكي الوصول المباشر لحساباتك في التطبيقات الخارجية مثل Notion, Canva, Adobe, GitHub واستدعاء أدواتها في محادثاتك لإنجاز أعمال حقيقية.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Integrations List
        items(McpIntegrationType.entries) { type ->
            val config = mcpConfigs[type] ?: McpServiceConfig(type = type)
            val isTesting = testingType == type
            val relatedTools = availableTools.filter { it.serviceType == type }

            McpIntegrationCard(
                config = config,
                tools = relatedTools,
                isTesting = isTesting,
                onToggleEnabled = { enabled ->
                    viewModel.toggleMcpIntegration(type, enabled)
                },
                onUpdateDetails = { token, endpoint, extraParam ->
                    viewModel.updateMcpDetails(type, token, endpoint, extraParam)
                },
                onTestConnection = {
                    viewModel.testMcpIntegration(type)
                }
            )
        }

        // Return button
        item {
            Button(
                onClick = onNavigateBackToHub,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CharcoalSurfaceVariant),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("العودة لقائمة الإعدادات", color = TextPrimary, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun McpIntegrationCard(
    config: McpServiceConfig,
    tools: List<com.example.data.mcp.McpToolDefinition>,
    isTesting: Boolean,
    onToggleEnabled: (Boolean) -> Unit,
    onUpdateDetails: (token: String, endpoint: String, extraParam: String) -> Unit,
    onTestConnection: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isExpanded by remember { mutableStateOf(config.isEnabled) }
    var currentToken by remember(config.token) { mutableStateOf(config.token) }
    var currentEndpoint by remember(config.endpoint) { mutableStateOf(config.endpoint) }
    var currentExtraParam by remember(config.extraParam) { mutableStateOf(config.extraParam) }
    var isTokenVisible by remember { mutableStateOf(false) }

    val icon: ImageVector = when (config.type) {
        McpIntegrationType.NOTION -> Icons.AutoMirrored.Filled.MenuBook
        McpIntegrationType.CANVA -> Icons.Default.Palette
        McpIntegrationType.ADOBE -> Icons.Default.AutoAwesome
        McpIntegrationType.GITHUB -> Icons.Default.AccountTree
        McpIntegrationType.WEB_SEARCH -> Icons.Default.Search
        McpIntegrationType.CUSTOM_MCP -> Icons.Default.Extension
    }

    val brandAccent: Color = when (config.type) {
        McpIntegrationType.NOTION -> Color(0xFFF3E8FF)
        McpIntegrationType.CANVA -> Color(0xFF00C4CC)
        McpIntegrationType.ADOBE -> Color(0xFFFF4B4B)
        McpIntegrationType.GITHUB -> Color(0xFFE2E8F0)
        McpIntegrationType.WEB_SEARCH -> CyanAccent
        McpIntegrationType.CUSTOM_MCP -> PurplePrimary
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = SolidColor(if (config.isEnabled) brandAccent.copy(alpha = 0.5f) else CharcoalBorder)
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header: Icon + Name + Category + Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(brandAccent.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = null,
                            tint = brandAccent,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = config.type.displayNameArabic,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = config.type.categoryArabic,
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                // Switch Toggle
                Switch(
                    checked = config.isEnabled,
                    onCheckedChange = { checked ->
                        onToggleEnabled(checked)
                        isExpanded = checked
                    },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = PurplePrimary,
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = CharcoalDark
                    )
                )
            }

            Text(
                text = config.type.descriptionArabic,
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )

            // Status message if tested
            if (config.lastStatusMessage != null) {
                val isSuccess = config.lastTestedSuccess == true
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSuccess) Color(0xFF0F2618) else Color(0xFF291214))
                        .border(1.dp, if (isSuccess) SuccessGreen else ErrorRed, RoundedCornerShape(8.dp))
                        .padding(8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = if (isSuccess) Icons.Default.CheckCircle else Icons.Default.Error,
                            contentDescription = null,
                            tint = if (isSuccess) SuccessGreen else ErrorRed,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = config.lastStatusMessage,
                            color = if (isSuccess) SuccessGreen else Color(0xFFFCA5A5),
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Expandable Configuration Form (when enabled or user clicks)
            if (config.isEnabled || isExpanded) {
                HorizontalDivider(color = CharcoalBorder, thickness = 1.dp)

                // Token Input (Except Web Search which is free)
                if (config.type != McpIntegrationType.WEB_SEARCH) {
                    Text(
                        text = "رمز الوصول (API Key / Token)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = currentToken,
                        onValueChange = {
                            currentToken = it
                            onUpdateDetails(it, currentEndpoint, currentExtraParam)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("mcp_token_${config.type.id}"),
                        placeholder = { Text(config.type.placeholderToken, color = TextMuted, fontSize = 12.sp) },
                        visualTransformation = if (isTokenVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = clipboard.primaryClip
                                        if (clip != null && clip.itemCount > 0) {
                                            val pasted = clip.getItemAt(0).text?.toString().orEmpty()
                                            if (pasted.isNotBlank()) {
                                                currentToken = pasted
                                                onUpdateDetails(pasted, currentEndpoint, currentExtraParam)
                                                Toast.makeText(context, "تم اللصق بنجاح", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentPaste,
                                        contentDescription = "لصق",
                                        tint = CyanAccent,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                IconButton(onClick = { isTokenVisible = !isTokenVisible }) {
                                    Icon(
                                        imageVector = if (isTokenVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                        contentDescription = null,
                                        tint = TextSecondary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = CharcoalBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CharcoalDark,
                            unfocusedContainerColor = CharcoalDark
                        ),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true
                    )
                }

                // Custom MCP Endpoint field
                if (config.type == McpIntegrationType.CUSTOM_MCP) {
                    Text(
                        text = "عنوان خادم MCP (Endpoint URL)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = currentEndpoint,
                        onValueChange = {
                            currentEndpoint = it
                            onUpdateDetails(currentToken, it, currentExtraParam)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("http://10.0.2.2:8000/mcp", color = TextMuted, fontSize = 12.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = CharcoalBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CharcoalDark,
                            unfocusedContainerColor = CharcoalDark
                        ),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true
                    )
                }

                // Extra Param for Notion / Adobe
                if (config.type == McpIntegrationType.NOTION) {
                    Text(
                        text = "معرف قاعدة بيانات Notion (Database ID - اختياري)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = currentExtraParam,
                        onValueChange = {
                            currentExtraParam = it
                            onUpdateDetails(currentToken, currentEndpoint, it)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("معرف قاعدة البيانات الافتراضية...", color = TextMuted, fontSize = 12.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = CharcoalBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CharcoalDark,
                            unfocusedContainerColor = CharcoalDark
                        ),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true
                    )
                }

                // Available Tools Pills
                if (tools.isNotEmpty()) {
                    Text(
                        text = "الأدوات المتاحة للوكيل الذكي (${tools.size} أدوات):",
                        color = TextMuted,
                        fontSize = 11.sp
                    )
                    tools.forEach { t ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(CharcoalDark)
                                .border(1.dp, CharcoalBorder, RoundedCornerShape(6.dp))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = t.nameArabic,
                                    color = TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "مثال: \"${t.exampleUsage}\"",
                                    color = CyanAccent,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }

                // Test Connection Button
                OutlinedButton(
                    onClick = onTestConnection,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(40.dp)
                        .testTag("test_mcp_${config.type.id}"),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = brandAccent),
                    border = ButtonDefaults.outlinedButtonBorder().copy(brush = SolidColor(brandAccent.copy(alpha = 0.5f))),
                    shape = RoundedCornerShape(8.dp),
                    enabled = !isTesting
                ) {
                    if (isTesting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(16.dp),
                            color = brandAccent,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("جارٍ فحص الاتصال…", color = brandAccent, fontSize = 12.sp)
                    } else {
                        Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = brandAccent, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("اختبار الاتصال المباشر (${config.type.displayNameArabic.take(15)})", color = brandAccent, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// ==============================================================================
// 4. DATA MANAGEMENT SECTION
// ==============================================================================

@Composable
private fun DataManagementSection(
    viewModel: SettingsViewModel,
    onNavigateBackToHub: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showDeleteConfirm by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(14.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(CharcoalBorder))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "الخصوصية وتخزين المحادثات",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "يتم حفظ المحادثات والأدوات المستدعاة محلياً على هاتفك في قاعدة بيانات Room المشفرة. لا يتم رفع سجل محادثاتك إلى أي خادم خارجي سوى نماذج الـ API التي تختارها أنت بنفسك.",
                        color = TextSecondary,
                        fontSize = 13.sp,
                        lineHeight = 19.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = { showDeleteConfirm = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("delete_all_conversations_button"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                        border = ButtonDefaults.outlinedButtonBorder().copy(brush = SolidColor(ErrorRed.copy(alpha = 0.5f))),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null, tint = ErrorRed)
                        Spacer(modifier = Modifier.size(8.dp))
                        Text("حذف جميع المحادثات وتفريغ السجل", color = ErrorRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        item {
            Button(
                onClick = onNavigateBackToHub,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = CharcoalSurfaceVariant),
                shape = RoundedCornerShape(10.dp)
            ) {
                Text("العودة لقائمة الإعدادات", color = TextPrimary, fontWeight = FontWeight.Bold)
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(text = "تأكيد مسح كافة المحادثات", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text(text = "سيتم مسح جميع الرسائل والمحادثات المخزنة محلياً نهائياً. لا يمكن التراجع عن هذا الإجراء.", color = TextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAllConversations {
                            Toast.makeText(context, "تم مسح كافة المحادثات بنجاح", Toast.LENGTH_SHORT).show()
                        }
                        showDeleteConfirm = false
                    }
                ) {
                    Text(text = "مسح الكل الآن", color = ErrorRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text(text = stringResource(R.string.cancel), color = TextSecondary)
                }
            },
            containerColor = CharcoalSurfaceVariant
        )
    }
}
