package com.example.analyzer

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LinkAnalyzerTest {

    private val analyzer = LinkAnalyzer()

    @Test
    fun testFormatBytes() {
        assertEquals("0 B", LinkAnalysisResult.formatBytes(0L))
        assertEquals("500 B", LinkAnalysisResult.formatBytes(500L))
        assertEquals("1.00 KB", LinkAnalysisResult.formatBytes(1024L))
        assertEquals("10.00 MB", LinkAnalysisResult.formatBytes(10 * 1024 * 1024L))
        assertEquals("1.50 GB", LinkAnalysisResult.formatBytes((1.5 * 1024 * 1024 * 1024).toLong()))
    }

    @Test
    fun testInvalidUrlRejection() = runBlocking {
        val result = analyzer.analyzeUrl("ftp://files.example.com/movie.mp4")
        assertFalse(result.isSuccess)
        assertTrue(result.errorReason?.contains("HTTP and HTTPS") == true)
    }

    @Test
    fun testMalformedUrlHandling() = runBlocking {
        val result = analyzer.analyzeUrl("not a url at all with spaces :///")
        assertFalse(result.isSuccess)
        assertTrue(result.errorReason != null)
    }
}
