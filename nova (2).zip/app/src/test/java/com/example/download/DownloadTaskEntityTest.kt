package com.example.download

import com.example.data.model.DownloadStatus
import com.example.data.model.DownloadTaskEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DownloadTaskEntityTest {

    @Test
    fun testProgressPercentCalculation() {
        val task = DownloadTaskEntity(
            id = "t1",
            url = "https://example.com/test.mp4",
            filename = "test.mp4",
            totalBytes = 200L,
            downloadedBytes = 50L,
            filePath = "/storage/test.mp4",
            tempFilePath = "/storage/t1.nova_tmp"
        )
        assertEquals(0.25f, task.progressPercent, 0.001f)
    }

    @Test
    fun testIndeterminateProgress() {
        val task = DownloadTaskEntity(
            id = "t2",
            url = "https://example.com/stream",
            filename = "stream.bin",
            totalBytes = -1L,
            downloadedBytes = 1000L,
            status = DownloadStatus.DOWNLOADING,
            filePath = "/storage/stream.bin",
            tempFilePath = "/storage/t2.nova_tmp"
        )
        assertTrue(task.isIndeterminate)
        assertEquals(0f, task.progressPercent, 0.001f)
    }

    @Test
    fun testStatusActiveAndTerminal() {
        assertTrue(DownloadStatus.QUEUED.isActive)
        assertTrue(DownloadStatus.CONNECTING.isActive)
        assertTrue(DownloadStatus.DOWNLOADING.isActive)
        assertFalse(DownloadStatus.PAUSED.isActive)

        assertTrue(DownloadStatus.COMPLETED.isTerminal)
        assertTrue(DownloadStatus.FAILED.isTerminal)
        assertTrue(DownloadStatus.CANCELLED.isTerminal)
        assertFalse(DownloadStatus.DOWNLOADING.isTerminal)
    }
}
