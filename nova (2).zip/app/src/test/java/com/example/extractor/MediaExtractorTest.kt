package com.example.extractor

import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class MediaExtractorTest {

    private val extractor = UniversalMediaExtractor()
    private val resolver = UrlResolver()

    @Test
    fun testLiveTikTokShortUrlResolutionAndExtraction() = runBlocking {
        val targetUrl = "https://vt.tiktok.com/ZSp1DAPuW/"
        val result = extractor.extractMedia(targetUrl)

        assertTrue(
            "Expected live TikTok extraction to succeed, but got: $result",
            result is ExtractionResult.Success
        )

        val success = result as ExtractionResult.Success
        val metadata = success.metadata

        println("Live Test Result: Video ID=${metadata.id}, Title='${metadata.title}', Author='${metadata.author}'")
        println("Discovered formats: ${metadata.formats.size}")

        // 1. Verify correct video ID
        assertEquals("7279419456323947782", metadata.id)

        // 2. Verify author and title
        assertTrue(metadata.author?.contains("grandson_ibrahim_al_fiqi", ignoreCase = true) == true)
        assertTrue(metadata.title.isNotBlank())

        // 3. Verify real formats were extracted (no fake placeholders)
        assertTrue("Expected at least one real video format", metadata.formats.isNotEmpty())

        val videoFormats = metadata.formats.filter { it.mediaType == ExtractedMediaType.VIDEO }
        assertTrue("Expected real video formats", videoFormats.isNotEmpty())
        for (f in videoFormats) {
            assertTrue("Video stream URL must be HTTPS", f.downloadUrl.startsWith("https://"))
            assertTrue("Video MIME type must be video/mp4", f.mimeType == "video/mp4")
            assertEquals("https://www.tiktok.com/", f.httpHeaders["Referer"])
        }

        // 4. Verify audio stream association
        val audioFormats = metadata.formats.filter { it.mediaType == ExtractedMediaType.AUDIO }
        assertTrue("Expected real audio format", audioFormats.isNotEmpty())
        for (a in audioFormats) {
            assertTrue("Audio stream URL must be HTTPS", a.downloadUrl.startsWith("https://"))
            assertEquals("https://www.tiktok.com/", a.httpHeaders["Referer"])
        }
    }

    @Test
    fun testHtmlPageWithNoMediaReturnsFailureWithoutFakeFormats() = runBlocking {
        // A generic HTML page that has no direct media streams
        val htmlUrl = "https://example.com"
        val result = extractor.extractMedia(htmlUrl)

        assertTrue(
            "Expected HTML page without media to fail extraction",
            result is ExtractionResult.Failure
        )
        val failure = result as ExtractionResult.Failure
        assertTrue(failure.errorMessage.contains("HTML webpage", ignoreCase = true))
    }

    @Test
    fun testInvalidUrlFailsGracefully() = runBlocking {
        val invalidUrl = "ftp://invalid-server.local/video.mp4"
        val result = extractor.extractMedia(invalidUrl)

        assertTrue(result is ExtractionResult.Failure)
        val failure = result as ExtractionResult.Failure
        assertTrue(failure.errorMessage.isNotBlank())
    }

    @Test
    fun testPrivateIpSsrfBlocker() = runBlocking {
        val privateUrl = "http://127.0.0.1:8080/secret.mp4"
        val resolution = resolver.resolveRedirects(privateUrl)

        assertFalse("Private IP must be blocked", resolution.isSuccess)
        assertTrue(resolution.error?.contains("blocked for security") == true)
    }

    @Test
    fun testFormatByteFormatting() {
        assertEquals("0 B", MediaFormat.formatBytes(0L))
        assertEquals("1.00 KB", MediaFormat.formatBytes(1024L))
        assertEquals("1.62 MB", MediaFormat.formatBytes(1694914L))
        assertEquals("1.50 GB", MediaFormat.formatBytes((1.5 * 1024 * 1024 * 1024).toLong()))
    }
}
