package com.example.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.dao.DownloadDao
import com.example.data.dao.SettingDao
import com.example.data.model.AppSettingEntity
import com.example.data.model.DownloadStatus
import com.example.data.model.DownloadTaskEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.IOException

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class NovaDatabaseTest {

    private lateinit var db: NovaDatabase
    private lateinit var downloadDao: DownloadDao
    private lateinit var settingDao: SettingDao

    @Before
    fun createDb() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, NovaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        downloadDao = db.downloadDao()
        settingDao = db.settingDao()
    }

    @After
    @Throws(IOException::class)
    fun closeDb() {
        db.close()
    }

    @Test
    fun insertAndRetrieveDownloadTask() = runBlocking {
        val task = DownloadTaskEntity(
            id = "test-1",
            url = "https://example.com/video.mp4",
            filename = "video.mp4",
            mimeType = "video/mp4",
            totalBytes = 10000L,
            downloadedBytes = 0L,
            status = DownloadStatus.QUEUED,
            filePath = "/storage/video.mp4",
            tempFilePath = "/storage/test-1.nova_tmp"
        )
        downloadDao.insertTask(task)

        val retrieved = downloadDao.getTaskById("test-1")
        assertNotNull(retrieved)
        assertEquals("video.mp4", retrieved?.filename)
        assertEquals(DownloadStatus.QUEUED, retrieved?.status)
        assertEquals("{}", retrieved?.customHeadersJson)
    }

    @Test
    fun insertAndRetrieveWithCustomHeaders() = runBlocking {
        val task = DownloadTaskEntity(
            id = "test-custom-headers",
            url = "https://v16-webapp-prime.tiktok.com/video/stream.mp4",
            filename = "tiktok.mp4",
            mimeType = "video/mp4",
            filePath = "/storage/tiktok.mp4",
            tempFilePath = "/storage/tiktok.nova_tmp",
            customHeadersJson = "{\"Referer\":\"https://www.tiktok.com/\",\"User-Agent\":\"TikTokMobile\"}"
        )
        downloadDao.insertTask(task)

        val retrieved = downloadDao.getTaskById("test-custom-headers")
        assertNotNull(retrieved)
        assertTrue(retrieved?.customHeadersJson?.contains("Referer") == true)
        assertTrue(retrieved?.customHeadersJson?.contains("https://www.tiktok.com/") == true)
    }

    @Test
    fun updateProgressAndStatusTransition() = runBlocking {
        val task = DownloadTaskEntity(
            id = "test-2",
            url = "https://example.com/audio.mp3",
            filename = "audio.mp3",
            mimeType = "audio/mpeg",
            totalBytes = 50000L,
            downloadedBytes = 0L,
            status = DownloadStatus.QUEUED,
            filePath = "/storage/audio.mp3",
            tempFilePath = "/storage/test-2.nova_tmp"
        )
        downloadDao.insertTask(task)

        // Progress update to downloading
        downloadDao.updateProgress(
            id = "test-2",
            downloaded = 25000L,
            total = 50000L,
            speed = 5000L,
            eta = 5L,
            status = DownloadStatus.DOWNLOADING
        )

        var updated = downloadDao.getTaskById("test-2")
        assertEquals(25000L, updated?.downloadedBytes)
        assertEquals(DownloadStatus.DOWNLOADING, updated?.status)
        assertEquals(0.5f, updated?.progressPercent ?: 0f, 0.01f)

        // Mark completed
        downloadDao.markCompleted("test-2", System.currentTimeMillis())
        updated = downloadDao.getTaskById("test-2")
        assertEquals(DownloadStatus.COMPLETED, updated?.status)
        assertEquals(50000L, updated?.downloadedBytes)
        assertNotNull(updated?.completedAt)
    }

    @Test
    fun retrieveInterruptedTasksForRecovery() = runBlocking {
        val activeTask = DownloadTaskEntity(
            id = "active-1",
            url = "https://example.com/file1.zip",
            filename = "file1.zip",
            status = DownloadStatus.DOWNLOADING,
            filePath = "/storage/file1.zip",
            tempFilePath = "/storage/active-1.nova_tmp"
        )
        val completedTask = DownloadTaskEntity(
            id = "comp-1",
            url = "https://example.com/file2.zip",
            filename = "file2.zip",
            status = DownloadStatus.COMPLETED,
            filePath = "/storage/file2.zip",
            tempFilePath = "/storage/comp-1.nova_tmp"
        )
        downloadDao.insertTask(activeTask)
        downloadDao.insertTask(completedTask)

        val interrupted = downloadDao.getInterruptedTasks()
        assertEquals(1, interrupted.size)
        assertEquals("active-1", interrupted[0].id)
    }

    @Test
    fun deleteCompletedTasks() = runBlocking {
        val task1 = DownloadTaskEntity(
            id = "c1",
            url = "https://example.com/1",
            filename = "1.mp4",
            status = DownloadStatus.COMPLETED,
            filePath = "/storage/1.mp4",
            tempFilePath = "/storage/c1.nova_tmp"
        )
        downloadDao.insertTask(task1)
        assertEquals(1, downloadDao.getCompletedDownloadsFlow().first().size)

        downloadDao.clearCompleted()
        assertEquals(0, downloadDao.getCompletedDownloadsFlow().first().size)
    }

    @Test
    fun settingsDaoPersistence() = runBlocking {
        settingDao.setSetting(AppSettingEntity("max_concurrent_downloads", "3"))
        val value = settingDao.getSetting("max_concurrent_downloads")
        assertEquals("3", value)
    }
}
