package com.example.analyzer

import android.webkit.MimeTypeMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class LinkAnalyzer(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
) {
    companion object {
        const val DEFAULT_USER_AGENT =
            "Mozilla/5.0 (Linux; Android 14; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36 NOVA/1.0"

        private val FILENAME_STAR_PATTERN =
            Pattern.compile("filename\\*=(?:UTF-8|utf-8)''([^;\\n]+)", Pattern.CASE_INSENSITIVE)
        private val FILENAME_PATTERN =
            Pattern.compile("filename=\"?([^\";\\n]+)\"?", Pattern.CASE_INSENSITIVE)
    }

    suspend fun analyzeUrl(rawUrl: String): LinkAnalysisResult = withContext(Dispatchers.IO) {
        val trimmed = rawUrl.trim()
        val parsedUri = try {
            val uri = URI(trimmed)
            if (uri.scheme == null) {
                URI("https://$trimmed")
            } else {
                uri
            }
        } catch (e: Exception) {
            return@withContext LinkAnalysisResult(
                originalUrl = rawUrl,
                resolvedUrl = rawUrl,
                filename = "unknown",
                mimeType = "unknown",
                contentLength = -1L,
                isResumable = false,
                isDirectMedia = false,
                isWebPage = false,
                httpStatusCode = 0,
                errorReason = "Invalid URL format: ${e.localizedMessage ?: "Malform syntax"}"
            )
        }

        val targetUrl = parsedUri.toString()
        if (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://")) {
            return@withContext LinkAnalysisResult(
                originalUrl = rawUrl,
                resolvedUrl = targetUrl,
                filename = "unsupported",
                mimeType = "unknown",
                contentLength = -1L,
                isResumable = false,
                isDirectMedia = false,
                isWebPage = false,
                httpStatusCode = 0,
                errorReason = "Only HTTP and HTTPS URLs are supported."
            )
        }

        // 1. Try HEAD request first for fast inspection
        var response: Response? = null
        var usedGet = false
        try {
            val headReq = Request.Builder()
                .url(targetUrl)
                .header("User-Agent", DEFAULT_USER_AGENT)
                .head()
                .build()

            response = client.newCall(headReq).execute()

            // Some servers return 405 Method Not Allowed or 403 Forbidden to HEAD
            if (!response.isSuccessful || response.code == 405 || response.code == 403) {
                response.close()
                // Try Range GET (0-0) to inspect real headers and probe resumability with minimal data
                val getReq = Request.Builder()
                    .url(targetUrl)
                    .header("User-Agent", DEFAULT_USER_AGENT)
                    .header("Range", "bytes=0-0")
                    .get()
                    .build()
                response = client.newCall(getReq).execute()
                usedGet = true
            }
        } catch (e: Exception) {
            response?.close()
            return@withContext LinkAnalysisResult(
                originalUrl = rawUrl,
                resolvedUrl = targetUrl,
                filename = extractFallbackFilename(targetUrl, null),
                mimeType = "unknown",
                contentLength = -1L,
                isResumable = false,
                isDirectMedia = false,
                isWebPage = false,
                httpStatusCode = 0,
                errorReason = "Connection failed: ${e.localizedMessage ?: e.javaClass.simpleName}"
            )
        }

        response.use { res ->
            val finalUrl = res.request.url.toString()
            val statusCode = res.code
            val headers = res.headers

            if (!res.isSuccessful && statusCode != 206) {
                val errorReason = when (statusCode) {
                    401, 403 -> "Access restricted (HTTP $statusCode). Server requires authentication or denied access."
                    404 -> "Resource not found (HTTP 404). Link may be expired or broken."
                    410 -> "Resource gone (HTTP 410)."
                    500, 502, 503 -> "Server error (HTTP $statusCode). Server is temporarily unavailable."
                    else -> "Server returned HTTP status $statusCode"
                }
                return@withContext LinkAnalysisResult(
                    originalUrl = rawUrl,
                    resolvedUrl = finalUrl,
                    filename = extractFallbackFilename(finalUrl, null),
                    mimeType = res.header("Content-Type") ?: "application/octet-stream",
                    contentLength = -1L,
                    isResumable = false,
                    isDirectMedia = false,
                    isWebPage = false,
                    httpStatusCode = statusCode,
                    errorReason = errorReason
                )
            }

            // Detect Content-Type
            val rawContentType = res.header("Content-Type") ?: "application/octet-stream"
            val mimeType = rawContentType.split(";").firstOrNull()?.trim()?.lowercase()
                ?: "application/octet-stream"

            // Detect Content-Length
            var contentLength = -1L
            val clHeader = res.header("Content-Length")
            if (clHeader != null) {
                contentLength = clHeader.toLongOrNull() ?: -1L
            }

            // If we used Range request and received 206 Partial Content, Content-Range contains total size:
            // "bytes 0-0/123456"
            val contentRangeHeader = res.header("Content-Range")
            if (contentRangeHeader != null) {
                val slashIdx = contentRangeHeader.lastIndexOf('/')
                if (slashIdx != -1 && slashIdx < contentRangeHeader.length - 1) {
                    val totalStr = contentRangeHeader.substring(slashIdx + 1).trim()
                    val parsedTotal = totalStr.toLongOrNull()
                    if (parsedTotal != null && parsedTotal > 0) {
                        contentLength = parsedTotal
                    }
                }
            }

            // Detect Resumability
            val acceptRanges = res.header("Accept-Ranges")
            val isResumable = (statusCode == 206) ||
                    (acceptRanges?.contains("bytes", ignoreCase = true) == true)

            // Extract Filename
            val disposition = res.header("Content-Disposition")
            val filename = extractFilename(finalUrl, disposition, mimeType)

            // Detect if direct media or HTML web page
            val isWebPage = mimeType.contains("text/html") || mimeType.contains("application/xhtml")
            val isDirectMedia = isMediaMimeType(mimeType, filename)

            val importantHeaders = mutableMapOf<String, String>()
            res.header("Content-Type")?.let { importantHeaders["Content-Type"] = it }
            res.header("Content-Length")?.let { importantHeaders["Content-Length"] = it }
            res.header("Accept-Ranges")?.let { importantHeaders["Accept-Ranges"] = it }
            res.header("Server")?.let { importantHeaders["Server"] = it }
            res.header("ETag")?.let { importantHeaders["ETag"] = it }

            var errorReason: String? = null
            if (isWebPage) {
                errorReason = "The provided URL is an HTML webpage, not a direct downloadable file or media stream."
            }

            return@withContext LinkAnalysisResult(
                originalUrl = rawUrl,
                resolvedUrl = finalUrl,
                filename = filename,
                mimeType = mimeType,
                contentLength = contentLength,
                isResumable = isResumable,
                isDirectMedia = isDirectMedia,
                isWebPage = isWebPage,
                httpStatusCode = statusCode,
                server = res.header("Server"),
                errorReason = errorReason,
                importantHeaders = importantHeaders
            )
        }
    }

    private fun extractFilename(url: String, contentDisposition: String?, mimeType: String): String {
        if (!contentDisposition.isNullOrBlank()) {
            // Check RFC 5987 / RFC 6266 filename*
            val starMatcher = FILENAME_STAR_PATTERN.matcher(contentDisposition)
            if (starMatcher.find()) {
                val rawEncoded = starMatcher.group(1)?.trim() ?: ""
                try {
                    val decoded = URLDecoder.decode(rawEncoded, StandardCharsets.UTF_8.name())
                    if (decoded.isNotBlank()) return cleanFilename(decoded)
                } catch (_: Exception) {}
            }

            // Check standard filename=
            val normalMatcher = FILENAME_PATTERN.matcher(contentDisposition)
            if (normalMatcher.find()) {
                val found = normalMatcher.group(1)?.trim() ?: ""
                if (found.isNotBlank()) return cleanFilename(found)
            }
        }

        return extractFallbackFilename(url, mimeType)
    }

    private fun extractFallbackFilename(url: String, mimeType: String?): String {
        try {
            val uri = URI(url)
            val path = uri.path
            if (!path.isNullOrBlank()) {
                val lastSegment = path.substringAfterLast('/')
                if (lastSegment.isNotBlank()) {
                    val decoded = URLDecoder.decode(lastSegment, StandardCharsets.UTF_8.name())
                    if (decoded.contains('.')) {
                        return cleanFilename(decoded)
                    } else if (mimeType != null) {
                        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType)
                        if (ext != null) {
                            return cleanFilename("$decoded.$ext")
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        val ext = mimeType?.let { MimeTypeMap.getSingleton().getExtensionFromMimeType(it) } ?: "bin"
        return "download_${System.currentTimeMillis()}.$ext"
    }

    private fun cleanFilename(name: String): String {
        // Strip path traversal and invalid filesystem characters
        val sanitized = name.replace(Regex("[/\\\\:*?\"<>|]"), "_").trim()
        return if (sanitized.isNotBlank()) sanitized else "download_${System.currentTimeMillis()}"
    }

    private fun isMediaMimeType(mimeType: String, filename: String): Boolean {
        if (mimeType.startsWith("video/") || mimeType.startsWith("audio/") ||
            mimeType.startsWith("image/") || mimeType == "application/pdf" ||
            mimeType == "application/zip" || mimeType == "application/octet-stream"
        ) {
            return true
        }

        val lowerName = filename.lowercase()
        val mediaExtensions = listOf(
            ".mp4", ".mkv", ".webm", ".avi", ".mov", ".flv", ".3gp",
            ".mp3", ".m4a", ".aac", ".flac", ".ogg", ".wav", ".opus",
            ".pdf", ".zip", ".tar", ".gz", ".apk", ".iso", ".dmg"
        )
        return mediaExtensions.any { lowerName.endsWith(it) }
    }
}
