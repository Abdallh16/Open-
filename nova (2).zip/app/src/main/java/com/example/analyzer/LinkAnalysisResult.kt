package com.example.analyzer

data class LinkAnalysisResult(
    val originalUrl: String,
    val resolvedUrl: String,
    val filename: String,
    val mimeType: String,
    val contentLength: Long,
    val isResumable: Boolean,
    val isDirectMedia: Boolean,
    val isWebPage: Boolean,
    val httpStatusCode: Int,
    val server: String? = null,
    val errorReason: String? = null,
    val importantHeaders: Map<String, String> = emptyMap()
) {
    val isSuccess: Boolean
        get() = errorReason == null && httpStatusCode in 200..299

    val formattedSize: String
        get() = if (contentLength > 0) {
            formatBytes(contentLength)
        } else {
            "Unknown size (stream/chunked)"
        }

    companion object {
        fun formatBytes(bytes: Long): String {
            if (bytes <= 0) return "0 B"
            val kb = bytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format("%.2f GB", gb)
                mb >= 1.0 -> String.format("%.2f MB", mb)
                kb >= 1.0 -> String.format("%.2f KB", kb)
                else -> "$bytes B"
            }
        }
    }
}
