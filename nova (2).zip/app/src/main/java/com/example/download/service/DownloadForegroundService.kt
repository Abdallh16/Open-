package com.example.download.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.MainActivity
import com.example.NovaApplication
import com.example.analyzer.LinkAnalysisResult
import com.example.data.model.DownloadStatus
import com.example.data.model.DownloadTaskEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class DownloadForegroundService : Service() {

    companion object {
        const val CHANNEL_ID = "nova_downloads_channel"
        const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.nova.action.START"
        const val ACTION_PAUSE = "com.example.nova.action.PAUSE"
        const val ACTION_RESUME = "com.example.nova.action.RESUME"
        const val ACTION_CANCEL = "com.example.nova.action.CANCEL"
        const val EXTRA_TASK_ID = "extra_task_id"

        fun start(context: Context) {
            val intent = Intent(context, DownloadForegroundService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var observerJob: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForegroundWithInitialNotification()
        observeActiveDownloads()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "NOVA Active Downloads",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows real-time download progress and controls"
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun startForegroundWithInitialNotification() {
        val notification = buildNotification(null, emptyList())
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceCompat.startForeground(
                this,
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun observeActiveDownloads() {
        observerJob?.cancel()
        val app = application as? NovaApplication ?: return
        observerJob = serviceScope.launch {
            app.database.downloadDao().getActiveDownloadsFlow().collectLatest { tasks ->
                val activeList = tasks.filter { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.CONNECTING }
                if (activeList.isEmpty() && tasks.isEmpty()) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                } else {
                    val primaryTask = activeList.firstOrNull() ?: tasks.firstOrNull()
                    val notification = buildNotification(primaryTask, tasks)
                    val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                    manager.notify(NOTIFICATION_ID, notification)
                }
            }
        }
    }

    private fun buildNotification(primaryTask: DownloadTaskEntity?, allActive: List<DownloadTaskEntity>): android.app.Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentIntent(contentPendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)

        if (primaryTask == null) {
            builder.setContentTitle("NOVA Download Manager")
                .setContentText("Download queue idle")
            return builder.build()
        }

        val downloadingCount = allActive.count { it.status == DownloadStatus.DOWNLOADING }
        val title = if (allActive.size > 1) {
            "Downloading ${primaryTask.filename} (+${allActive.size - 1} more)"
        } else {
            primaryTask.filename
        }

        val speedText = if (primaryTask.speedBytesPerSec > 0) {
            "${LinkAnalysisResult.formatBytes(primaryTask.speedBytesPerSec)}/s"
        } else {
            ""
        }

        val progressText = if (primaryTask.totalBytes > 0) {
            val currentStr = LinkAnalysisResult.formatBytes(primaryTask.downloadedBytes)
            val totalStr = LinkAnalysisResult.formatBytes(primaryTask.totalBytes)
            val percent = (primaryTask.progressPercent * 100).toInt()
            "$currentStr / $totalStr ($percent%) ${if (speedText.isNotBlank()) "• $speedText" else ""}"
        } else {
            val currentStr = LinkAnalysisResult.formatBytes(primaryTask.downloadedBytes)
            "$currentStr ${if (speedText.isNotBlank()) "• $speedText" else ""}"
        }

        builder.setContentTitle(title)
            .setContentText(progressText)

        if (primaryTask.totalBytes > 0) {
            val progressPercent = (primaryTask.progressPercent * 100).toInt()
            builder.setProgress(100, progressPercent, false)
        } else if (primaryTask.status == DownloadStatus.DOWNLOADING) {
            builder.setProgress(100, 0, true)
        } else {
            builder.setProgress(0, 0, false)
        }

        // Action: Pause / Resume
        if (primaryTask.status == DownloadStatus.DOWNLOADING) {
            val pauseIntent = Intent(this, DownloadForegroundService::class.java).apply {
                action = ACTION_PAUSE
                putExtra(EXTRA_TASK_ID, primaryTask.id)
            }
            val pausePendingIntent = PendingIntent.getService(
                this,
                1,
                pauseIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(android.R.drawable.ic_media_pause, "Pause", pausePendingIntent)
        } else if (primaryTask.status == DownloadStatus.PAUSED) {
            val resumeIntent = Intent(this, DownloadForegroundService::class.java).apply {
                action = ACTION_RESUME
                putExtra(EXTRA_TASK_ID, primaryTask.id)
            }
            val resumePendingIntent = PendingIntent.getService(
                this,
                2,
                resumeIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            builder.addAction(android.R.drawable.ic_media_play, "Resume", resumePendingIntent)
        }

        // Action: Cancel
        val cancelIntent = Intent(this, DownloadForegroundService::class.java).apply {
            action = ACTION_CANCEL
            putExtra(EXTRA_TASK_ID, primaryTask.id)
        }
        val cancelPendingIntent = PendingIntent.getService(
            this,
            3,
            cancelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        builder.addAction(android.R.drawable.ic_menu_close_clear_cancel, "Cancel", cancelPendingIntent)

        return builder.build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val app = application as? NovaApplication
        val engine = app?.downloadEngine

        when (intent?.action) {
            ACTION_PAUSE -> {
                val taskId = intent.getStringExtra(EXTRA_TASK_ID)
                if (taskId != null && engine != null) {
                    engine.pauseDownload(taskId)
                }
            }
            ACTION_RESUME -> {
                val taskId = intent.getStringExtra(EXTRA_TASK_ID)
                if (taskId != null && engine != null) {
                    engine.resumeDownload(taskId)
                }
            }
            ACTION_CANCEL -> {
                val taskId = intent.getStringExtra(EXTRA_TASK_ID)
                if (taskId != null && engine != null) {
                    engine.cancelDownload(taskId)
                }
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }
}
