package com.example.data.repository

import android.content.Context
import android.os.Environment
import com.example.data.dao.SettingDao
import com.example.data.model.AppSettingEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.io.File

data class UserSettings(
    val maxConcurrentDownloads: Int = 2,
    val retryLimit: Int = 3,
    val wifiOnly: Boolean = false,
    val customDownloadDir: String = ""
)

class SettingsRepository(
    private val context: Context,
    private val settingDao: SettingDao
) {
    companion object {
        const val KEY_MAX_CONCURRENT = "max_concurrent_downloads"
        const val KEY_RETRY_LIMIT = "retry_limit"
        const val KEY_WIFI_ONLY = "wifi_only"
        const val KEY_DOWNLOAD_DIR = "download_dir"
    }

    fun getDefaultDownloadDirectory(): File {
        val publicDownloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val novaFolder = File(publicDownloads, "NOVA")
        if (!novaFolder.exists()) {
            novaFolder.mkdirs()
        }
        if (novaFolder.canWrite()) {
            return novaFolder
        }
        // Fallback to app external files dir or internal files dir
        val appFolder = context.getExternalFilesDir("NOVA") ?: File(context.filesDir, "NOVA")
        if (!appFolder.exists()) {
            appFolder.mkdirs()
        }
        return appFolder
    }

    fun getTempDirectory(): File {
        val tempDir = File(context.cacheDir, "nova_temp")
        if (!tempDir.exists()) {
            tempDir.mkdirs()
        }
        return tempDir
    }

    val settingsFlow: Flow<UserSettings> = settingDao.getAllSettingsFlow().map { list ->
        val map = list.associate { it.key to it.value }
        UserSettings(
            maxConcurrentDownloads = map[KEY_MAX_CONCURRENT]?.toIntOrNull() ?: 2,
            retryLimit = map[KEY_RETRY_LIMIT]?.toIntOrNull() ?: 3,
            wifiOnly = map[KEY_WIFI_ONLY]?.toBooleanStrictOrNull() ?: false,
            customDownloadDir = map[KEY_DOWNLOAD_DIR] ?: getDefaultDownloadDirectory().absolutePath
        )
    }

    suspend fun setMaxConcurrentDownloads(count: Int) {
        val safeCount = count.coerceIn(1, 5)
        settingDao.setSetting(AppSettingEntity(KEY_MAX_CONCURRENT, safeCount.toString()))
    }

    suspend fun setRetryLimit(limit: Int) {
        val safeLimit = limit.coerceIn(0, 10)
        settingDao.setSetting(AppSettingEntity(KEY_RETRY_LIMIT, safeLimit.toString()))
    }

    suspend fun setWifiOnly(enabled: Boolean) {
        settingDao.setSetting(AppSettingEntity(KEY_WIFI_ONLY, enabled.toString()))
    }

    suspend fun setDownloadDirectory(path: String) {
        settingDao.setSetting(AppSettingEntity(KEY_DOWNLOAD_DIR, path))
    }
}
