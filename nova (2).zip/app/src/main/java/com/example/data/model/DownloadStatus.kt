package com.example.data.model

enum class DownloadStatus {
    QUEUED,
    CONNECTING,
    DOWNLOADING,
    PAUSED,
    COMPLETED,
    FAILED,
    CANCELLED;

    val isActive: Boolean
        get() = this == QUEUED || this == CONNECTING || this == DOWNLOADING

    val isTerminal: Boolean
        get() = this == COMPLETED || this == FAILED || this == CANCELLED
}
