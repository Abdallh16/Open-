package com.example.data

import androidx.room.TypeConverter
import com.example.data.model.DownloadStatus

class Converters {
    @TypeConverter
    fun fromStatus(status: DownloadStatus?): String? = status?.name

    @TypeConverter
    fun toStatus(value: String?): DownloadStatus? = value?.let {
        try {
            DownloadStatus.valueOf(it)
        } catch (e: Exception) {
            DownloadStatus.FAILED
        }
    }
}
