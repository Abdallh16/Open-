package com.example.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DownloadStatus
import com.example.data.model.DownloadTaskEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {
    @Query("SELECT * FROM download_tasks ORDER BY createdAt DESC")
    fun getAllDownloadsFlow(): Flow<List<DownloadTaskEntity>>

    @Query("SELECT * FROM download_tasks WHERE status IN ('QUEUED', 'CONNECTING', 'DOWNLOADING', 'PAUSED') ORDER BY createdAt DESC")
    fun getActiveDownloadsFlow(): Flow<List<DownloadTaskEntity>>

    @Query("SELECT * FROM download_tasks WHERE status = 'COMPLETED' ORDER BY completedAt DESC, createdAt DESC")
    fun getCompletedDownloadsFlow(): Flow<List<DownloadTaskEntity>>

    @Query("SELECT * FROM download_tasks WHERE id = :id LIMIT 1")
    suspend fun getTaskById(id: String): DownloadTaskEntity?

    @Query("SELECT * FROM download_tasks WHERE id = :id LIMIT 1")
    fun getTaskByIdFlow(id: String): Flow<DownloadTaskEntity?>

    @Query("SELECT * FROM download_tasks WHERE url = :url AND status != 'CANCELLED' LIMIT 1")
    suspend fun findTaskByUrl(url: String): DownloadTaskEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: DownloadTaskEntity)

    @Update
    suspend fun updateTask(task: DownloadTaskEntity)

    @Query("UPDATE download_tasks SET status = :status, errorReason = :errorReason WHERE id = :id")
    suspend fun updateStatus(id: String, status: DownloadStatus, errorReason: String? = null)

    @Query("""
        UPDATE download_tasks 
        SET downloadedBytes = :downloaded, 
            totalBytes = CASE WHEN :total > 0 THEN :total ELSE totalBytes END,
            speedBytesPerSec = :speed, 
            etaSeconds = :eta, 
            status = :status 
        WHERE id = :id
    """)
    suspend fun updateProgress(
        id: String,
        downloaded: Long,
        total: Long,
        speed: Long,
        eta: Long,
        status: DownloadStatus
    )

    @Query("UPDATE download_tasks SET status = 'COMPLETED', downloadedBytes = totalBytes, completedAt = :completedAt, speedBytesPerSec = 0, etaSeconds = 0, errorReason = null WHERE id = :id")
    suspend fun markCompleted(id: String, completedAt: Long = System.currentTimeMillis())

    @Query("SELECT * FROM download_tasks WHERE status IN ('QUEUED', 'CONNECTING', 'DOWNLOADING')")
    suspend fun getInterruptedTasks(): List<DownloadTaskEntity>

    @Delete
    suspend fun deleteTask(task: DownloadTaskEntity)

    @Query("DELETE FROM download_tasks WHERE id = :id")
    suspend fun deleteTaskById(id: String)

    @Query("DELETE FROM download_tasks WHERE status = 'COMPLETED'")
    suspend fun clearCompleted()

    @Query("DELETE FROM download_tasks")
    suspend fun clearAll()
}
