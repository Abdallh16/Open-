package com.example

import android.app.Application
import com.example.analyzer.LinkAnalyzer
import com.example.data.NovaDatabase
import com.example.data.repository.SettingsRepository
import com.example.download.engine.DownloadEngine

class NovaApplication : Application() {

    lateinit var database: NovaDatabase
        private set

    lateinit var settingsRepository: SettingsRepository
        private set

    lateinit var downloadEngine: DownloadEngine
        private set

    lateinit var linkAnalyzer: LinkAnalyzer
        private set

    lateinit var mediaExtractor: com.example.extractor.UniversalMediaExtractor
        private set

    override fun onCreate() {
        super.onCreate()
        database = NovaDatabase.getInstance(this)
        settingsRepository = SettingsRepository(this, database.settingDao())
        downloadEngine = DownloadEngine(this, database.downloadDao(), settingsRepository)
        linkAnalyzer = LinkAnalyzer()
        mediaExtractor = com.example.extractor.UniversalMediaExtractor()

        downloadEngine.initialize()
    }
}
