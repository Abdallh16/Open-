package com.example.extractor

import android.webkit.MimeTypeMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URI
import java.net.URLDecoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class DirectMediaExtractor(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
) {
    companion object {
        const val DESKTOP_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

        private val FILENAME_STAR_PATTERN =
            Pattern.compile("filename\\*=(?:UTF-8|utf-8)''([^;\\n]+)", Pattern.CASE_INSENSITIVE)
        private val FILENAME_PATTERN =
            Pattern.compile("filename=\"?([^\";\\n]+)\"?", Pattern.CASE_INSENSITIVE)
    }

    suspend fun extract(url: String): ExtractionResult = withContext(Dispatchers.IO) {
        val diagnosticLog = StringBuilder()
        diagnosticLog.appendLine("[DirectExtractor] Probing direct resource: $url")

        var response = try {
            val headReq = Request.Builder()
                .url(url)
                .header("User-Agent", DESKTOP_USER_AGENT)
                .head()
                .build()
            client.newCall(headReq).execute()
        } catch (e: Exception) {
            diagnosticLog.appendLine("[DirectExtractor] HEAD failed: ${e.message}")
            null
        }

        if (response == null || !response.isSuccessful || response.code == 405 || response.code == 403) {
            response?.close()
            try {
                val getReq = Request.Builder()
                    .url(url)
                    .header("User-Agent", DESKTOP_USER_AGENT)
                    .header("Range", "bytes=0-0")
                    .get()
                    .build()
                response = client.newCall(getReq).execute()
            } catch (e: Exception) {
                diagnosticLog.appendLine("[DirectExtractor] Range GET failed: ${e.message}")
                return@withContext ExtractionResult.Failure(
                    errorMessage = "Cannot connect to server: ${e.localizedMessage ?: e.javaClass.simpleName}",
                    diagnosticLog = diagnosticLog.toString(),
                    canonicalUrl = url
                )
            }
        }

        response.use { res ->
            diagnosticLog.appendLine("[DirectExtractor] Status: ${res.code}")
            if (!res.isSuccessful && res.code != 206) {
                return@withContext ExtractionResult.Failure(
                    errorMessage = "Server returned HTTP status ${res.code}",
                    diagnosticLog = diagnosticLog.toString(),
                    canonicalUrl = res.request.url.toString()
                )
            }

            val finalUrl = res.request.url.toString()
            val rawContentType = res.header("Content-Type") ?: "application/octet-stream"
            val mimeType = rawContentType.split(";").firstOrNull()?.trim()?.lowercase() ?: "application/octet-stream"

            val isWebPage = mimeType.contains("text/html") || mimeType.contains("application/xhtml")
            if (isWebPage) {
                diagnosticLog.appendLine("[DirectExtractor] Resource is an HTML webpage, not a direct media stream.")
                return@withContext ExtractionResult.Failure(
                    errorMessage = "The provided link is an HTML webpage. No downloadable media stream or supported source adapter was detected for this URL.",
                    diagnosticLog = diagnosticLog.toString(),
                    canonicalUrl = finalUrl
                )
            }

            var contentLength = -1L
            res.header("Content-Length")?.toLongOrNull()?.let { contentLength = it }
            val contentRange = res.header("Content-Range")
            if (contentRange != null) {
                val slash = contentRange.lastIndexOf('/')
                if (slash != -1 && slash < contentRange.length - 1) {
                    contentRange.substring(slash + 1).trim().toLongOrNull()?.let { contentLength = it }
                }
            }

            val isResumable = res.code == 206 || res.header("Accept-Ranges")?.contains("bytes", ignoreCase = true) == true
            val disposition = res.header("Content-Disposition")
            val filename = extractFilename(finalUrl, disposition, mimeType)

            val mediaType = when {
                mimeType.startsWith("video/") -> ExtractedMediaType.VIDEO
                mimeType.startsWith("audio/") -> ExtractedMediaType.AUDIO
                mimeType == "application/pdf" -> ExtractedMediaType.DOCUMENT
                mimeType == "application/zip" -> ExtractedMediaType.ARCHIVE
                else -> ExtractedMediaType.GENERIC
            }

            val format = MediaFormat(
                formatId = "direct_media_original",
                label = "Direct File (${MediaFormat.formatBytes(contentLength)})",
                quality = "Original",
                mediaType = mediaType,
                mimeType = mimeType,
                filesize = contentLength,
                downloadUrl = finalUrl,
                httpHeaders = emptyMap(),
                isResumable = isResumable
            )

            diagnosticLog.appendLine("[DirectExtractor] Discovered direct format: $filename, size: $contentLength")

            return@withContext ExtractionResult.Success(
                metadata = MediaMetadata(
                    id = filename,
                    sourceUrl = url,
                    canonicalUrl = finalUrl,
                    extractorName = "DirectMedia",
                    title = filename,
                    formats = listOf(format),
                    diagnosticLog = diagnosticLog.toString()
                )
            )
        }
    }

    private fun extractFilename(url: String, contentDisposition: String?, mimeType: String): String {
        if (!contentDisposition.isNullOrBlank()) {
            val starMatcher = FILENAME_STAR_PATTERN.matcher(contentDisposition)
            if (starMatcher.find()) {
                val rawEncoded = starMatcher.group(1)?.trim() ?: ""
                try {
                    val decoded = URLDecoder.decode(rawEncoded, StandardCharsets.UTF_8.name())
                    if (decoded.isNotBlank()) return cleanFilename(decoded)
                } catch (_: Exception) {}
            }

            val normalMatcher = FILENAME_PATTERN.matcher(contentDisposition)
            if (normalMatcher.find()) {
                val found = normalMatcher.group(1)?.trim() ?: ""
                if (found.isNotBlank()) return cleanFilename(found)
            }
        }

        return try {
            val uri = URI(url)
            val path = uri.path
            if (!path.isNullOrBlank()) {
                val lastSegment = path.substringAfterLast('/')
                if (lastSegment.isNotBlank() && lastSegment.contains('.')) {
                    cleanFilename(URLDecoder.decode(lastSegment, StandardCharsets.UTF_8.name()))
                } else {
                    val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType) ?: "bin"
                    "download_${System.currentTimeMillis()}.$ext"
                }
            } else {
                "download_${System.currentTimeMillis()}.bin"
            }
        } catch (_: Exception) {
            "download_${System.currentTimeMillis()}.bin"
        }
    }

    private fun cleanFilename(name: String): String {
        return name.replace(Regex("[/\\\\:*?\"<>|]"), "_").trim()
    }
}
