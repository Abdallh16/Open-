package com.example.extractor

enum class ExtractedMediaType {
    VIDEO,
    AUDIO,
    DOCUMENT,
    ARCHIVE,
    GENERIC
}

data class MediaFormat(
    val formatId: String,
    val label: String,
    val quality: String,
    val mediaType: ExtractedMediaType,
    val mimeType: String,
    val filesize: Long = -1L,
    val downloadUrl: String,
    val httpHeaders: Map<String, String> = emptyMap(),
    val isResumable: Boolean = true,
    val codec: String? = null
) {
    val formattedSize: String
        get() = if (filesize > 0) formatBytes(filesize) else "Unknown Size"

    companion object {
        fun formatBytes(bytes: Long): String {
            if (bytes <= 0) return "0 B"
            val kb = bytes / 1024.0
            val mb = kb / 1024.0
            val gb = mb / 1024.0
            return when {
                gb >= 1.0 -> String.format("%.2f GB", gb)
                mb >= 1.0 -> String.format("%.2f MB", mb)
                kb >= 1.0 -> String.format("%.2f KB", kb)
                else -> "$bytes B"
            }
        }
    }
}

data class MediaMetadata(
    val id: String,
    val sourceUrl: String,
    val canonicalUrl: String,
    val extractorName: String,
    val title: String,
    val author: String? = null,
    val thumbnailUrl: String? = null,
    val durationSeconds: Int = 0,
    val formats: List<MediaFormat>,
    val diagnosticLog: String = ""
)

sealed class ExtractionResult {
    data class Success(val metadata: MediaMetadata) : ExtractionResult()
    data class Failure(
        val errorMessage: String,
        val diagnosticLog: String,
        val canonicalUrl: String? = null
    ) : ExtractionResult()
}
