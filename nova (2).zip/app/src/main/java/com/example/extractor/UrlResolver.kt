package com.example.extractor

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.net.InetAddress
import java.net.URI
import java.util.concurrent.TimeUnit

class UrlResolver(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .followRedirects(false) // We handle redirects manually for safety and hop tracking
        .followSslRedirects(false)
        .build()
) {
    companion object {
        private const val TAG = "UrlResolver"
        private const val MAX_HOPS = 10
        const val DESKTOP_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    }

    data class ResolutionResult(
        val originalUrl: String,
        val finalUrl: String,
        val hops: List<String>,
        val lastStatusCode: Int,
        val isSuccess: Boolean,
        val error: String? = null
    )

    suspend fun resolveRedirects(startUrl: String): ResolutionResult = withContext(Dispatchers.IO) {
        val hops = mutableListOf<String>()
        var currentUrl = startUrl.trim()
        hops.add(currentUrl)

        var hopCount = 0
        var lastStatus = 0

        while (hopCount < MAX_HOPS) {
            val uri = try {
                URI(currentUrl)
            } catch (e: Exception) {
                return@withContext ResolutionResult(
                    originalUrl = startUrl,
                    finalUrl = currentUrl,
                    hops = hops,
                    lastStatusCode = 0,
                    isSuccess = false,
                    error = "Invalid URL syntax: ${e.message}"
                )
            }

            val scheme = uri.scheme?.lowercase()
            if (scheme != "http" && scheme != "https") {
                return@withContext ResolutionResult(
                    originalUrl = startUrl,
                    finalUrl = currentUrl,
                    hops = hops,
                    lastStatusCode = 0,
                    isSuccess = false,
                    error = "Unsupported protocol scheme: $scheme"
                )
            }

            val host = uri.host
            if (host.isNullOrBlank() || isPrivateOrBlockedHost(host)) {
                return@withContext ResolutionResult(
                    originalUrl = startUrl,
                    finalUrl = currentUrl,
                    hops = hops,
                    lastStatusCode = 0,
                    isSuccess = false,
                    error = "Access to local or private network destination '$host' is blocked for security."
                )
            }

            var response: Response? = null
            try {
                val req = Request.Builder()
                    .url(currentUrl)
                    .header("User-Agent", DESKTOP_USER_AGENT)
                    .head()
                    .build()

                response = client.newCall(req).execute()

                // If HEAD returns 405 Method Not Allowed or 403 Forbidden, retry with GET
                if (response.code == 405 || response.code == 403) {
                    response.close()
                    val getReq = Request.Builder()
                        .url(currentUrl)
                        .header("User-Agent", DESKTOP_USER_AGENT)
                        .header("Range", "bytes=0-0")
                        .get()
                        .build()
                    response = client.newCall(getReq).execute()
                }

                lastStatus = response.code
                val isRedirect = lastStatus in 300..308
                if (isRedirect) {
                    val locationHeader = response.header("Location")
                    response.close()

                    if (locationHeader.isNullOrBlank()) {
                        return@withContext ResolutionResult(
                            originalUrl = startUrl,
                            finalUrl = currentUrl,
                            hops = hops,
                            lastStatusCode = lastStatus,
                            isSuccess = true
                        )
                    }

                    // Resolve relative redirect location against current URL
                    val nextUrl = try {
                        uri.resolve(locationHeader).toString()
                    } catch (_: Exception) {
                        locationHeader
                    }

                    if (hops.contains(nextUrl)) {
                        return@withContext ResolutionResult(
                            originalUrl = startUrl,
                            finalUrl = nextUrl,
                            hops = hops,
                            lastStatusCode = lastStatus,
                            isSuccess = false,
                            error = "Circular redirect detected"
                        )
                    }

                    currentUrl = nextUrl
                    hops.add(currentUrl)
                    hopCount++
                } else {
                    response.close()
                    return@withContext ResolutionResult(
                        originalUrl = startUrl,
                        finalUrl = currentUrl,
                        hops = hops,
                        lastStatusCode = lastStatus,
                        isSuccess = response.isSuccessful || lastStatus == 206
                    )
                }
            } catch (e: Exception) {
                response?.close()
                Log.w(TAG, "Error resolving URL $currentUrl: ${e.message}")
                return@withContext ResolutionResult(
                    originalUrl = startUrl,
                    finalUrl = currentUrl,
                    hops = hops,
                    lastStatusCode = lastStatus,
                    isSuccess = false,
                    error = "Connection failed during redirect resolution: ${e.localizedMessage ?: e.javaClass.simpleName}"
                )
            }
        }

        return@withContext ResolutionResult(
            originalUrl = startUrl,
            finalUrl = currentUrl,
            hops = hops,
            lastStatusCode = lastStatus,
            isSuccess = true,
            error = if (hopCount >= MAX_HOPS) "Maximum redirect limit ($MAX_HOPS) reached" else null
        )
    }

    private fun isPrivateOrBlockedHost(host: String): Boolean {
        val lower = host.lowercase()
        if (lower == "localhost" || lower.endsWith(".local") || lower == "127.0.0.1" || lower == "::1") {
            return true
        }
        return try {
            val addr = InetAddress.getByName(host)
            addr.isLoopbackAddress || addr.isSiteLocalAddress || addr.isLinkLocalAddress || addr.isAnyLocalAddress
        } catch (_: Exception) {
            false
        }
    }
}
