package com.example.extractor

import android.util.Log

class UniversalMediaExtractor(
    private val tikTokExtractor: TikTokMediaExtractor = TikTokMediaExtractor(),
    private val directExtractor: DirectMediaExtractor = DirectMediaExtractor()
) {
    companion object {
        private const val TAG = "UniversalExtractor"
    }

    suspend fun extractMedia(rawUrl: String): ExtractionResult {
        val trimmed = rawUrl.trim()
        if (trimmed.isBlank()) {
            return ExtractionResult.Failure(
                errorMessage = "URL cannot be empty",
                diagnosticLog = "Empty input supplied"
            )
        }

        Log.d(TAG, "Routing URL for extraction: $trimmed")

        return if (tikTokExtractor.canHandle(trimmed)) {
            Log.d(TAG, "Routing to TikTokMediaExtractor")
            tikTokExtractor.extract(trimmed)
        } else {
            Log.d(TAG, "Routing to DirectMediaExtractor")
            directExtractor.extract(trimmed)
        }
    }
}
