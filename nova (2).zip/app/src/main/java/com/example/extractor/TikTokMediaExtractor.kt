package com.example.extractor

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URI
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

class TikTokMediaExtractor(
    private val urlResolver: UrlResolver = UrlResolver(),
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .cookieJar(InMemoryCookieJar())
        .build()
) {
    companion object {
        private const val TAG = "TikTokExtractor"
        const val DESKTOP_USER_AGENT =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

        private val TIKTOK_HOST_PATTERN =
            Pattern.compile("^(?:www\\.|m\\.|vt\\.|vm\\.)?tiktok(?:v)?\\.com$", Pattern.CASE_INSENSITIVE)
        private val VIDEO_ID_PATTERN =
            Pattern.compile("(?:video|v)/(\\d+)", Pattern.CASE_INSENSITIVE)
        private val UNIVERSAL_DATA_PATTERN =
            Pattern.compile("<script id=\"__UNIVERSAL_DATA_FOR_REHYDRATION__\"[^>]*>(.*?)</script>", Pattern.DOTALL)
        private val SIGI_STATE_PATTERN =
            Pattern.compile("<script id=\"(?:SIGI_STATE|sigi-persisted-data)\"[^>]*>(.*?)</script>", Pattern.DOTALL)
    }

    fun canHandle(url: String): Boolean {
        return try {
            val host = URI(url.trim()).host ?: return false
            TIKTOK_HOST_PATTERN.matcher(host).matches()
        } catch (_: Exception) {
            false
        }
    }

    suspend fun extract(rawUrl: String): ExtractionResult = withContext(Dispatchers.IO) {
        val diagnosticLog = StringBuilder()
        diagnosticLog.appendLine("[TikTokExtractor] Initializing extraction for: $rawUrl")

        // 1. Resolve redirects (especially for vt.tiktok.com and vm.tiktok.com)
        val resolution = urlResolver.resolveRedirects(rawUrl)
        diagnosticLog.appendLine("[TikTokExtractor] Redirection resolved to: ${resolution.finalUrl}")
        diagnosticLog.appendLine("[TikTokExtractor] Hops: ${resolution.hops.joinToString(" -> ")}")

        val canonicalUrl = resolution.finalUrl

        // 2. Extract video ID
        val idMatcher = VIDEO_ID_PATTERN.matcher(canonicalUrl)
        val videoId = if (idMatcher.find()) {
            idMatcher.group(1) ?: ""
        } else {
            ""
        }
        diagnosticLog.appendLine("[TikTokExtractor] Extracted video ID: '$videoId'")

        // 3. Fetch canonical webpage HTML with Desktop User-Agent
        val req = Request.Builder()
            .url(canonicalUrl)
            .header("User-Agent", DESKTOP_USER_AGENT)
            .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
            .header("Accept-Language", "en-US,en;q=0.9,ar;q=0.8")
            .header("Sec-Fetch-Mode", "navigate")
            .build()

        val html = try {
            client.newCall(req).execute().use { res ->
                diagnosticLog.appendLine("[TikTokExtractor] Page HTTP response code: ${res.code}")
                if (!res.isSuccessful) {
                    return@withContext ExtractionResult.Failure(
                        errorMessage = "TikTok server returned HTTP ${res.code}",
                        diagnosticLog = diagnosticLog.toString(),
                        canonicalUrl = canonicalUrl
                    )
                }
                res.body?.string() ?: ""
            }
        } catch (e: Exception) {
            diagnosticLog.appendLine("[TikTokExtractor] Network error: ${e.message}")
            return@withContext ExtractionResult.Failure(
                errorMessage = "Failed to connect to TikTok: ${e.localizedMessage ?: e.javaClass.simpleName}",
                diagnosticLog = diagnosticLog.toString(),
                canonicalUrl = canonicalUrl
            )
        }

        // 4. Parse __UNIVERSAL_DATA_FOR_REHYDRATION__ or SIGI_STATE
        var itemStruct: JSONObject? = null

        val universalMatcher = UNIVERSAL_DATA_PATTERN.matcher(html)
        if (universalMatcher.find()) {
            val jsonStr = universalMatcher.group(1)
            diagnosticLog.appendLine("[TikTokExtractor] Found __UNIVERSAL_DATA_FOR_REHYDRATION__ JSON block")
            try {
                val rootJson = JSONObject(jsonStr)
                val defaultScope = rootJson.optJSONObject("__DEFAULT_SCOPE__")
                val videoDetail = defaultScope?.optJSONObject("webapp.video-detail")
                val itemInfo = videoDetail?.optJSONObject("itemInfo")
                itemStruct = itemInfo?.optJSONObject("itemStruct")

                val statusCode = videoDetail?.optInt("statusCode", 0) ?: 0
                val statusMsg = videoDetail?.optString("statusMsg", "") ?: ""
                if (statusCode != 0) {
                    diagnosticLog.appendLine("[TikTokExtractor] Platform returned statusCode: $statusCode ($statusMsg)")
                    if (statusCode == 10216 || statusCode == 10222) {
                        return@withContext ExtractionResult.Failure(
                            errorMessage = "This TikTok video is private or account restricted.",
                            diagnosticLog = diagnosticLog.toString(),
                            canonicalUrl = canonicalUrl
                        )
                    } else if (statusCode == 10204) {
                        return@withContext ExtractionResult.Failure(
                            errorMessage = "Your IP address is blocked by TikTok from accessing this video.",
                            diagnosticLog = diagnosticLog.toString(),
                            canonicalUrl = canonicalUrl
                        )
                    }
                }
            } catch (e: Exception) {
                diagnosticLog.appendLine("[TikTokExtractor] Error parsing universal JSON: ${e.message}")
            }
        }

        if (itemStruct == null) {
            val sigiMatcher = SIGI_STATE_PATTERN.matcher(html)
            if (sigiMatcher.find()) {
                val jsonStr = sigiMatcher.group(1)
                diagnosticLog.appendLine("[TikTokExtractor] Found SIGI_STATE JSON block")
                try {
                    val rootJson = JSONObject(jsonStr)
                    val itemModule = rootJson.optJSONObject("ItemModule")
                    if (itemModule != null && videoId.isNotEmpty()) {
                        itemStruct = itemModule.optJSONObject(videoId)
                    }
                } catch (e: Exception) {
                    diagnosticLog.appendLine("[TikTokExtractor] Error parsing SIGI_STATE JSON: ${e.message}")
                }
            }
        }

        if (itemStruct == null) {
            diagnosticLog.appendLine("[TikTokExtractor] Failed: no itemStruct found in page HTML.")
            return@withContext ExtractionResult.Failure(
                errorMessage = "Unable to locate video data in TikTok response. Video may be deleted or region-restricted.",
                diagnosticLog = diagnosticLog.toString(),
                canonicalUrl = canonicalUrl
            )
        }

        // 5. Extract Real Video Metadata
        val realId = itemStruct.optString("id", videoId).ifBlank { videoId }
        val desc = itemStruct.optString("desc", "").trim()
        val authorObj = itemStruct.optJSONObject("author")
        val authorUsername = authorObj?.optString("uniqueId") ?: authorObj?.optString("nickname") ?: "tiktok_creator"
        val videoObj = itemStruct.optJSONObject("video")
        val durationSeconds = videoObj?.optInt("duration", 0) ?: 0
        val coverUrl = videoObj?.optString("cover") ?: videoObj?.optString("originCover")

        val title = if (desc.isNotBlank()) desc else "TikTok by @$authorUsername ($realId)"
        diagnosticLog.appendLine("[TikTokExtractor] Discovered Title: '$title'")
        diagnosticLog.appendLine("[TikTokExtractor] Discovered Author: '@$authorUsername'")

        // 6. Extract REAL available formats
        val discoveredFormats = mutableListOf<MediaFormat>()
        val httpHeaders = mapOf(
            "User-Agent" to DESKTOP_USER_AGENT,
            "Referer" to "https://www.tiktok.com/"
        )

        val bitrateArray = videoObj?.optJSONArray("bitrateInfo")
        if (bitrateArray != null && bitrateArray.length() > 0) {
            for (i in 0 until bitrateArray.length()) {
                val b = bitrateArray.optJSONObject(i) ?: continue
                val gearName = b.optString("GearName", "")
                val playAddr = b.optJSONObject("PlayAddr") ?: continue
                val dataSize = playAddr.optLong("DataSize", -1L)
                val urlList = playAddr.optJSONArray("UrlList") ?: continue

                var chosenUrl = ""
                for (uIdx in 0 until urlList.length()) {
                    val candidate = urlList.optString(uIdx, "")
                    if (candidate.isNotBlank()) {
                        chosenUrl = candidate
                        break
                    }
                }

                if (chosenUrl.isNotBlank()) {
                    val qualityLabel = parseGearName(gearName)
                    discoveredFormats.add(
                        MediaFormat(
                            formatId = "tiktok_video_${gearName}_$i",
                            label = "$qualityLabel (Video MP4)",
                            quality = qualityLabel,
                            mediaType = ExtractedMediaType.VIDEO,
                            mimeType = "video/mp4",
                            filesize = dataSize,
                            downloadUrl = chosenUrl,
                            httpHeaders = httpHeaders,
                            isResumable = true,
                            codec = b.optString("QualityType", "h264")
                        )
                    )
                }
            }
        }

        // If no bitrateInfo was provided, check playAddr or downloadAddr
        if (discoveredFormats.isEmpty()) {
            val playAddr = videoObj?.optString("playAddr", "") ?: ""
            val downloadAddr = videoObj?.optString("downloadAddr", "") ?: ""
            val directStreamUrl = playAddr.ifBlank { downloadAddr }

            if (directStreamUrl.isNotBlank()) {
                val definition = videoObj?.optString("definition", "Original") ?: "Original"
                discoveredFormats.add(
                    MediaFormat(
                        formatId = "tiktok_direct_stream",
                        label = "$definition Video (Direct Stream)",
                        quality = definition,
                        mediaType = ExtractedMediaType.VIDEO,
                        mimeType = "video/mp4",
                        filesize = videoObj?.optLong("size", -1L) ?: -1L,
                        downloadUrl = directStreamUrl,
                        httpHeaders = httpHeaders,
                        isResumable = true
                    )
                )
            }
        }

        // 7. Extract REAL Audio Stream from music
        val musicObj = itemStruct.optJSONObject("music")
        if (musicObj != null) {
            val musicUrl = musicObj.optString("playUrl", "")
            if (musicUrl.isNotBlank()) {
                val musicTitle = musicObj.optString("title", "Original Sound")
                val musicAuthor = musicObj.optString("authorName", "")
                val label = if (musicAuthor.isNotBlank()) {
                    "Original Audio • $musicTitle ($musicAuthor)"
                } else {
                    "Original Audio • $musicTitle"
                }

                discoveredFormats.add(
                    MediaFormat(
                        formatId = "tiktok_audio_music",
                        label = label,
                        quality = "Original Audio",
                        mediaType = ExtractedMediaType.AUDIO,
                        mimeType = "audio/mp4",
                        filesize = -1L,
                        downloadUrl = musicUrl,
                        httpHeaders = httpHeaders,
                        isResumable = true
                    )
                )
                diagnosticLog.appendLine("[TikTokExtractor] Discovered Audio: '$label'")
            }
        }

        diagnosticLog.appendLine("[TikTokExtractor] Successfully discovered ${discoveredFormats.size} real formats.")

        if (discoveredFormats.isEmpty()) {
            return@withContext ExtractionResult.Failure(
                errorMessage = "No playable media streams found for this video.",
                diagnosticLog = diagnosticLog.toString(),
                canonicalUrl = canonicalUrl
            )
        }

        return@withContext ExtractionResult.Success(
            metadata = MediaMetadata(
                id = realId,
                sourceUrl = rawUrl,
                canonicalUrl = canonicalUrl,
                extractorName = "TikTok",
                title = title,
                author = authorUsername,
                thumbnailUrl = coverUrl,
                durationSeconds = durationSeconds,
                formats = discoveredFormats,
                diagnosticLog = diagnosticLog.toString()
            )
        )
    }

    private fun parseGearName(gear: String): String {
        val lower = gear.lowercase()
        return when {
            lower.contains("1080") -> "1080p Full HD"
            lower.contains("720") -> "720p HD"
            lower.contains("540") -> "540p"
            lower.contains("480") -> "480p"
            lower.contains("360") -> "360p"
            else -> gear.replace('_', ' ').trim()
        }
    }
}

class InMemoryCookieJar : CookieJar {
    private val cookieStore = mutableListOf<Cookie>()

    override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
        synchronized(cookieStore) {
            cookieStore.removeAll { old -> cookies.any { newC -> newC.name == old.name && newC.domain == old.domain } }
            cookieStore.addAll(cookies)
        }
    }

    override fun loadForRequest(url: HttpUrl): List<Cookie> {
        synchronized(cookieStore) {
            val now = System.currentTimeMillis()
            return cookieStore.filter { it.expiresAt > now && it.matches(url) }
        }
    }
}
