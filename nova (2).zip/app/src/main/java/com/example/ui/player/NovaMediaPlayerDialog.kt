package com.example.ui.player

import android.content.Context
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.VolumeDown
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.DownloadTaskEntity
import kotlinx.coroutines.delay
import java.io.File
import java.util.Locale

@Composable
fun NovaMediaPlayerDialog(
    playlist: List<DownloadTaskEntity>,
    initialIndex: Int,
    onDismiss: () -> Unit
) {
    var currentIndex by remember { mutableIntStateOf(initialIndex.coerceIn(0, (playlist.size - 1).coerceAtLeast(0))) }
    val currentTask = playlist.getOrNull(currentIndex) ?: return

    val context = LocalContext.current
    var isPlaying by remember { mutableStateOf(false) }
    var currentPositionMs by remember { mutableIntStateOf(0) }
    var durationMs by remember { mutableIntStateOf(0) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }
    var volume by remember { mutableFloatStateOf(1.0f) }
    var showSpeedMenu by remember { mutableStateOf(false) }
    var playerError by remember { mutableStateOf<String?>(null) }

    val isVideo = currentTask.mimeType.startsWith("video/") ||
            currentTask.filename.endsWith(".mp4", true) ||
            currentTask.filename.endsWith(".mkv", true) ||
            currentTask.filename.endsWith(".webm", true)

    val mediaPlayer = remember { MediaPlayer() }
    var surfaceHolder by remember { mutableStateOf<SurfaceHolder?>(null) }

    fun loadMedia(file: File) {
        try {
            playerError = null
            mediaPlayer.reset()
            mediaPlayer.setDataSource(context, Uri.fromFile(file))
            if (surfaceHolder != null && isVideo) {
                mediaPlayer.setDisplay(surfaceHolder)
            }
            mediaPlayer.prepareAsync()
            mediaPlayer.setOnPreparedListener { mp ->
                durationMs = mp.duration
                mp.start()
                isPlaying = true
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                    try {
                        mp.playbackParams = PlaybackParams().apply { speed = playbackSpeed }
                    } catch (_: Exception) {}
                }
            }
            mediaPlayer.setOnCompletionListener {
                isPlaying = false
                currentPositionMs = durationMs
                // Auto play next if available
                if (currentIndex < playlist.size - 1) {
                    currentIndex++
                }
            }
            mediaPlayer.setOnErrorListener { _, what, extra ->
                playerError = "Playback error ($what, $extra). File codec may not be supported by Android hardware."
                isPlaying = false
                true
            }
        } catch (e: Exception) {
            playerError = "Failed to load file: ${e.message}"
            isPlaying = false
        }
    }

    // Load file whenever index changes
    LaunchedEffect(currentIndex) {
        val file = File(playlist[currentIndex].filePath)
        if (file.exists()) {
            loadMedia(file)
        } else {
            playerError = "File not found on storage."
        }
    }

    // Tracking loop for progress bar
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            try {
                if (mediaPlayer.isPlaying) {
                    currentPositionMs = mediaPlayer.currentPosition
                }
            } catch (_: Exception) {}
            delay(400)
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            try {
                if (mediaPlayer.isPlaying) {
                    mediaPlayer.stop()
                }
                mediaPlayer.release()
            } catch (_: Exception) {}
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black),
            color = Color.Black
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentTask.filename,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${currentIndex + 1} of ${playlist.size} • ${if (isVideo) "Video" else "Audio"}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.LightGray
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.testTag("close_player_button")) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                // Middle area: Video View or Audio Visualizer
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    if (playerError != null) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(24.dp)
                        ) {
                            Text(
                                text = "Unable to play media",
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = playerError ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White
                            )
                        }
                    } else if (isVideo) {
                        AndroidView(
                            factory = { ctx ->
                                SurfaceView(ctx).apply {
                                    holder.addCallback(object : SurfaceHolder.Callback {
                                        override fun surfaceCreated(holder: SurfaceHolder) {
                                            surfaceHolder = holder
                                            try {
                                                mediaPlayer.setDisplay(holder)
                                            } catch (_: Exception) {}
                                        }

                                        override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

                                        override fun surfaceDestroyed(holder: SurfaceHolder) {
                                            surfaceHolder = null
                                            try {
                                                mediaPlayer.setDisplay(null)
                                            } catch (_: Exception) {}
                                        }
                                    })
                                }
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(16f / 9f)
                                .clip(RoundedCornerShape(12.dp))
                        )
                    } else {
                        // Audio visual representation
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.size(100.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = Icons.Default.Audiotrack,
                                        contentDescription = "Audio Playback",
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(54.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(18.dp))
                            Text(
                                text = currentTask.filename,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "High-Fidelity Offline Audio",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.LightGray
                            )
                        }
                    }
                }

                // Controls area
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                ) {
                    // Time and seekbar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = formatDuration(currentPositionMs),
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White
                        )
                        Text(
                            text = formatDuration(durationMs),
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White
                        )
                    }

                    Slider(
                        value = if (durationMs > 0) (currentPositionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f,
                        onValueChange = { frac ->
                            if (durationMs > 0) {
                                val target = (frac * durationMs).toInt()
                                currentPositionMs = target
                                try {
                                    mediaPlayer.seekTo(target)
                                } catch (_: Exception) {}
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("player_seekbar")
                    )

                    // Control buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Previous file
                        IconButton(
                            onClick = {
                                if (currentIndex > 0) currentIndex--
                            },
                            enabled = currentIndex > 0
                        ) {
                            Icon(Icons.Default.SkipPrevious, contentDescription = "Previous", tint = if (currentIndex > 0) Color.White else Color.DarkGray)
                        }

                        // Replay 10s
                        IconButton(onClick = {
                            val target = (currentPositionMs - 10000).coerceAtLeast(0)
                            currentPositionMs = target
                            try { mediaPlayer.seekTo(target) } catch (_: Exception) {}
                        }) {
                            Icon(Icons.Default.Replay10, contentDescription = "Back 10s", tint = Color.White)
                        }

                        // Play / Pause
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(56.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    try {
                                        if (mediaPlayer.isPlaying) {
                                            mediaPlayer.pause()
                                            isPlaying = false
                                        } else {
                                            mediaPlayer.start()
                                            isPlaying = true
                                        }
                                    } catch (_: Exception) {}
                                },
                                modifier = Modifier.testTag("player_play_pause")
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (isPlaying) "Pause" else "Play",
                                    tint = MaterialTheme.colorScheme.onPrimary,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                        }

                        // Forward 10s
                        IconButton(onClick = {
                            val target = (currentPositionMs + 10000).coerceAtMost(durationMs)
                            currentPositionMs = target
                            try { mediaPlayer.seekTo(target) } catch (_: Exception) {}
                        }) {
                            Icon(Icons.Default.Forward10, contentDescription = "Forward 10s", tint = Color.White)
                        }

                        // Next file
                        IconButton(
                            onClick = {
                                if (currentIndex < playlist.size - 1) currentIndex++
                            },
                            enabled = currentIndex < playlist.size - 1
                        ) {
                            Icon(Icons.Default.SkipNext, contentDescription = "Next", tint = if (currentIndex < playlist.size - 1) Color.White else Color.DarkGray)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Secondary controls: speed and volume
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Speed selector
                        Box {
                            FilledTonalButton(
                                onClick = { showSpeedMenu = true },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Speed, contentDescription = "Speed", modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("${playbackSpeed}x")
                            }

                            DropdownMenu(
                                expanded = showSpeedMenu,
                                onDismissRequest = { showSpeedMenu = false }
                            ) {
                                listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { spd ->
                                    DropdownMenuItem(
                                        text = { Text("${spd}x") },
                                        onClick = {
                                            playbackSpeed = spd
                                            showSpeedMenu = false
                                            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
                                                try {
                                                    mediaPlayer.playbackParams = PlaybackParams().apply { speed = spd }
                                                } catch (_: Exception) {}
                                            }
                                        }
                                    )
                                }
                            }
                        }

                        // Volume slider
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.width(180.dp)
                        ) {
                            Icon(
                                if (volume > 0f) Icons.Default.VolumeUp else Icons.Default.VolumeDown,
                                contentDescription = "Volume",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Slider(
                                value = volume,
                                onValueChange = { v ->
                                    volume = v
                                    try {
                                        mediaPlayer.setVolume(v, v)
                                    } catch (_: Exception) {}
                                },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun formatDuration(millis: Int): String {
    val totalSeconds = (millis / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format(Locale.getDefault(), "%02d:%02d", minutes, seconds)
}
