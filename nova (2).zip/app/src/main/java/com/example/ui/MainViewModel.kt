package com.example.ui

import android.app.Application
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.NovaApplication
import com.example.data.model.DownloadStatus
import com.example.data.model.DownloadTaskEntity
import com.example.data.repository.UserSettings
import com.example.download.service.DownloadForegroundService
import com.example.extractor.ExtractedMediaType
import com.example.extractor.ExtractionResult
import com.example.extractor.MediaFormat
import com.example.extractor.MediaMetadata
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

enum class NovaTab {
    ANALYZER,
    QUEUE,
    BROWSER,
    LIBRARY,
    SETTINGS
}

sealed class AnalysisUiState {
    object Idle : AnalysisUiState()
    object Loading : AnalysisUiState()
    data class Success(
        val metadata: MediaMetadata,
        val selectedFormat: MediaFormat,
        val customFilename: String
    ) : AnalysisUiState()
    data class Error(
        val message: String,
        val url: String,
        val diagnosticLog: String = ""
    ) : AnalysisUiState()
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as NovaApplication
    private val database = app.database
    private val downloadDao = database.downloadDao()
    private val settingsRepository = app.settingsRepository
    private val downloadEngine = app.downloadEngine
    private val mediaExtractor = app.mediaExtractor

    private val _currentTab = MutableStateFlow(NovaTab.ANALYZER)
    val currentTab: StateFlow<NovaTab> = _currentTab.asStateFlow()

    private val _urlInput = MutableStateFlow("")
    val urlInput: StateFlow<String> = _urlInput.asStateFlow()

    private val _analysisState = MutableStateFlow<AnalysisUiState>(AnalysisUiState.Idle)
    val analysisState: StateFlow<AnalysisUiState> = _analysisState.asStateFlow()

    private val _browserTargetUrl = MutableStateFlow("https://duckduckgo.com")
    val browserTargetUrl: StateFlow<String> = _browserTargetUrl.asStateFlow()

    private val _snackbarEvent = MutableSharedFlow<String>()
    val snackbarEvent: SharedFlow<String> = _snackbarEvent.asSharedFlow()

    val activeDownloads: StateFlow<List<DownloadTaskEntity>> = downloadDao.getActiveDownloadsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val completedDownloads: StateFlow<List<DownloadTaskEntity>> = downloadDao.getCompletedDownloadsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userSettings: StateFlow<UserSettings> = settingsRepository.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserSettings())

    fun selectTab(tab: NovaTab) {
        _currentTab.value = tab
    }

    fun setUrlInput(url: String) {
        _urlInput.value = url
    }

    fun openInBrowser(url: String) {
        if (url.isNotBlank()) {
            _browserTargetUrl.value = url
            _currentTab.value = NovaTab.BROWSER
        }
    }

    fun pasteFromClipboard(context: Context) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        if (clipboard.hasPrimaryClip() &&
            clipboard.primaryClipDescription?.hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN) == true
        ) {
            val item = clipboard.primaryClip?.getItemAt(0)
            val text = item?.text?.toString()?.trim() ?: ""
            if (text.isNotBlank()) {
                _urlInput.value = text
                analyzeUrl(text)
            } else {
                emitSnackbar("Clipboard is empty")
            }
        } else {
            emitSnackbar("No text found in clipboard")
        }
    }

    fun handleSharedUrl(sharedText: String) {
        val urlRegex = Regex("""https?://[^\s]+""")
        val match = urlRegex.find(sharedText)
        val extractedUrl = match?.value ?: sharedText.trim()
        if (extractedUrl.isNotBlank()) {
            _urlInput.value = extractedUrl
            _currentTab.value = NovaTab.ANALYZER
            analyzeUrl(extractedUrl)
        }
    }

    fun analyzeUrl(url: String = _urlInput.value) {
        val trimmed = url.trim()
        if (trimmed.isBlank()) {
            emitSnackbar("Please enter a valid URL")
            return
        }

        viewModelScope.launch {
            // Clear stale results immediately when submitting a new URL
            _analysisState.value = AnalysisUiState.Loading

            val result = mediaExtractor.extractMedia(trimmed)
            when (result) {
                is ExtractionResult.Success -> {
                    val metadata = result.metadata
                    // Pick highest quality video format by default or first available
                    val defaultFormat = metadata.formats.firstOrNull { it.mediaType == ExtractedMediaType.VIDEO }
                        ?: metadata.formats.first()

                    val ext = if (defaultFormat.mediaType == ExtractedMediaType.AUDIO) "mp3" else "mp4"
                    val safeTitle = metadata.title.take(60)
                        .replace(Regex("[/\\\\:*?\"<>|]"), "_")
                        .replace(Regex("\\s+"), " ")
                        .trim()

                    val defaultName = if (safeTitle.isNotBlank()) {
                        "${safeTitle}_${defaultFormat.quality}.$ext"
                    } else {
                        "${metadata.extractorName}_${metadata.id}_${defaultFormat.quality}.$ext"
                    }

                    _analysisState.value = AnalysisUiState.Success(
                        metadata = metadata,
                        selectedFormat = defaultFormat,
                        customFilename = defaultName
                    )
                }
                is ExtractionResult.Failure -> {
                    _analysisState.value = AnalysisUiState.Error(
                        message = result.errorMessage,
                        url = trimmed,
                        diagnosticLog = result.diagnosticLog
                    )
                }
            }
        }
    }

    fun selectFormat(format: MediaFormat) {
        val current = _analysisState.value
        if (current is AnalysisUiState.Success) {
            val ext = if (format.mediaType == ExtractedMediaType.AUDIO) "mp3" else "mp4"
            val dotIdx = current.customFilename.lastIndexOf('.')
            val baseName = if (dotIdx != -1) current.customFilename.substring(0, dotIdx) else current.customFilename
            val updatedFilename = "$baseName.$ext"

            _analysisState.value = current.copy(
                selectedFormat = format,
                customFilename = updatedFilename
            )
        }
    }

    fun updateCustomFilename(newName: String) {
        val current = _analysisState.value
        if (current is AnalysisUiState.Success) {
            _analysisState.value = current.copy(customFilename = newName)
        }
    }

    fun startDownload(context: Context) {
        val state = _analysisState.value
        if (state !is AnalysisUiState.Success) return

        val metadata = state.metadata
        val format = state.selectedFormat
        val filename = state.customFilename.ifBlank {
            val ext = if (format.mediaType == ExtractedMediaType.AUDIO) "mp3" else "mp4"
            "${metadata.id}_${format.quality}.$ext"
        }

        viewModelScope.launch {
            try {
                downloadEngine.enqueueDownload(
                    url = format.downloadUrl,
                    filename = filename,
                    mimeType = format.mimeType,
                    totalBytes = format.filesize,
                    isResumable = format.isResumable,
                    customHeaders = format.httpHeaders
                )
                DownloadForegroundService.start(context)
                _analysisState.value = AnalysisUiState.Idle
                _urlInput.value = ""
                _currentTab.value = NovaTab.QUEUE
                emitSnackbar("Download started: $filename")
            } catch (e: Exception) {
                emitSnackbar("Failed to start download: ${e.localizedMessage}")
            }
        }
    }

    fun pauseDownload(taskId: String) {
        downloadEngine.pauseDownload(taskId)
    }

    fun resumeDownload(taskId: String, context: Context) {
        downloadEngine.resumeDownload(taskId)
        DownloadForegroundService.start(context)
    }

    fun cancelDownload(taskId: String) {
        downloadEngine.cancelDownload(taskId)
    }

    fun retryDownload(taskId: String, context: Context) {
        downloadEngine.retryDownload(taskId)
        DownloadForegroundService.start(context)
    }

    fun deleteDownload(taskId: String, deleteFromDisk: Boolean) {
        downloadEngine.deleteDownload(taskId, deleteFromDisk)
    }

    fun openFile(context: Context, task: DownloadTaskEntity) {
        val file = File(task.filePath)
        if (!file.exists()) {
            Toast.makeText(context, "File does not exist on storage", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, task.mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Open with"))
        } catch (e: Exception) {
            Toast.makeText(context, "No app available to open this file", Toast.LENGTH_SHORT).show()
        }
    }

    fun shareFile(context: Context, task: DownloadTaskEntity) {
        val file = File(task.filePath)
        if (!file.exists()) {
            Toast.makeText(context, "File does not exist on storage", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = task.mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "Share file"))
        } catch (e: Exception) {
            Toast.makeText(context, "Failed to share file: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun updateMaxConcurrent(count: Int) {
        viewModelScope.launch {
            settingsRepository.setMaxConcurrentDownloads(count)
            downloadEngine.processQueue()
        }
    }

    fun updateRetryLimit(limit: Int) {
        viewModelScope.launch {
            settingsRepository.setRetryLimit(limit)
        }
    }

    fun updateWifiOnly(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setWifiOnly(enabled)
        }
    }

    fun clearCompletedLibrary() {
        viewModelScope.launch {
            downloadDao.clearCompleted()
            emitSnackbar("Completed history cleared")
        }
    }

    fun clearTemporaryFiles() {
        viewModelScope.launch {
            try {
                val tempDir = settingsRepository.getTempDirectory()
                val files = tempDir.listFiles() ?: emptyArray()
                var deleted = 0
                for (f in files) {
                    if (f.delete()) deleted++
                }
                emitSnackbar("Cleaned $deleted temporary files")
            } catch (e: Exception) {
                emitSnackbar("Error clearing temp files: ${e.message}")
            }
        }
    }

    private fun emitSnackbar(msg: String) {
        viewModelScope.launch {
            _snackbarEvent.emit(msg)
        }
    }
}
