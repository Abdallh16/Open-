package com.example.ui.screens

import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.MainViewModel
import com.example.ui.NovaTab
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val targetUrlFromModel by viewModel.browserTargetUrl.collectAsState()

    val defaultHome = "https://duckduckgo.com"
    var currentUrl by remember { mutableStateOf(defaultHome) }
    var addressInput by remember { mutableStateOf(defaultHome) }
    var pageTitle by remember { mutableStateOf("NOVA Browser") }
    var isLoading by remember { mutableStateOf(false) }
    var pageProgress by remember { mutableFloatStateOf(0f) }
    var canGoBack by remember { mutableStateOf(false) }
    var canGoForward by remember { mutableStateOf(false) }

    var webViewInstance by remember { mutableStateOf<WebView?>(null) }
    var detectedMediaUrl by remember { mutableStateOf<String?>(null) }
    var rendererKey by remember { mutableIntStateOf(0) }
    var lastCrashedUrl by remember { mutableStateOf<String?>(null) }

    fun navigateTo(rawInput: String) {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return

        val targetUrl = when {
            trimmed.startsWith("http://") || trimmed.startsWith("https://") -> trimmed
            trimmed.contains(".") && !trimmed.contains(" ") -> "https://$trimmed"
            else -> {
                val query = URLEncoder.encode(trimmed, StandardCharsets.UTF_8.name())
                "https://duckduckgo.com/?q=$query"
            }
        }
        addressInput = targetUrl
        webViewInstance?.loadUrl(targetUrl)
        keyboardController?.hide()
    }

    // Load URL passed from viewModel if different from current
    LaunchedEffect(targetUrlFromModel) {
        if (targetUrlFromModel.isNotBlank() && targetUrlFromModel != currentUrl) {
            navigateTo(targetUrlFromModel)
        }
    }

    // Intercept back button to navigate back in webview if possible
    BackHandler(enabled = canGoBack) {
        webViewInstance?.goBack()
    }

    Column(modifier = modifier.fillMaxSize()) {
        // Browser Navigation Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 3.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { webViewInstance?.goBack() },
                        enabled = canGoBack,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = if (canGoBack) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                        )
                    }

                    IconButton(
                        onClick = { webViewInstance?.goForward() },
                        enabled = canGoForward,
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = "Forward",
                            tint = if (canGoForward) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.outline
                        )
                    }

                    IconButton(
                        onClick = { webViewInstance?.reload() },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = "Reload")
                    }

                    IconButton(
                        onClick = { navigateTo(defaultHome) },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Home, contentDescription = "Home")
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    OutlinedTextField(
                        value = addressInput,
                        onValueChange = { addressInput = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("browser_address_field"),
                        singleLine = true,
                        shape = RoundedCornerShape(24.dp),
                        leadingIcon = {
                            Icon(
                                Icons.Default.Search,
                                contentDescription = "Search",
                                modifier = Modifier.size(18.dp)
                            )
                        },
                        trailingIcon = {
                            if (addressInput.isNotEmpty()) {
                                IconButton(onClick = { addressInput = "" }) {
                                    Icon(
                                        Icons.Default.Clear,
                                        contentDescription = "Clear",
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        },
                        keyboardOptions = KeyboardOptions(
                            keyboardType = KeyboardType.Uri,
                            imeAction = ImeAction.Go
                        ),
                        keyboardActions = KeyboardActions(
                            onGo = { navigateTo(addressInput) }
                        )
                    )
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Actions bar: "Send to Analyzer", "Copy", "Share"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledTonalButton(
                        onClick = {
                            viewModel.setUrlInput(currentUrl)
                            viewModel.analyzeUrl(currentUrl)
                            viewModel.selectTab(NovaTab.ANALYZER)
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.testTag("browser_analyze_btn")
                    ) {
                        Icon(Icons.Default.Download, contentDescription = "Download", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Extract From Current Page", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }

                    Row {
                        IconButton(onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("URL", currentUrl))
                            Toast.makeText(context, "URL copied", Toast.LENGTH_SHORT).show()
                        }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy URL", modifier = Modifier.size(20.dp))
                        }

                        IconButton(onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, currentUrl)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share URL"))
                        }) {
                            Icon(Icons.Default.Share, contentDescription = "Share URL", modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }

            if (isLoading) {
                LinearProgressIndicator(
                    progress = { pageProgress },
                    modifier = Modifier.fillMaxWidth(),
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }

        // Detected Media Banner
        if (detectedMediaUrl != null) {
            val mediaUrl = detectedMediaUrl!!
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = "Video",
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Media Available to Download",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = mediaUrl,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                maxLines = 1
                            )
                        }
                    }

                    Button(onClick = {
                        viewModel.setUrlInput(mediaUrl)
                        viewModel.analyzeUrl(mediaUrl)
                        viewModel.selectTab(NovaTab.ANALYZER)
                        detectedMediaUrl = null
                    }) {
                        Text("Extract")
                    }
                }
            }
        }

        // Android WebView
        Box(modifier = Modifier.fillMaxSize()) {
            key(rendererKey) {
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            val wv = this
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                            try {
                                CookieManager.getInstance().apply {
                                    setAcceptCookie(true)
                                    setAcceptThirdPartyCookies(wv, true)
                                }
                            } catch (_: Exception) {}

                            settings.apply {
                                javaScriptEnabled = true
                                domStorageEnabled = true
                                loadWithOverviewMode = true
                                useWideViewPort = true
                                builtInZoomControls = true
                                displayZoomControls = false
                                cacheMode = WebSettings.LOAD_DEFAULT
                                mediaPlaybackRequiresUserGesture = true
                                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                                safeBrowsingEnabled = false
                                userAgentString = "Mozilla/5.0 (Linux; Android 14; Mobile; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                            }

                            webViewClient = object : WebViewClient() {
                                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                                    isLoading = true
                                    url?.let {
                                        currentUrl = it
                                        addressInput = it
                                        checkIfMedia(it)
                                    }
                                    canGoBack = view?.canGoBack() == true
                                    canGoForward = view?.canGoForward() == true
                                }

                                override fun onPageFinished(view: WebView?, url: String?) {
                                    isLoading = false
                                    url?.let {
                                        currentUrl = it
                                        addressInput = it
                                        pageTitle = view?.title ?: it
                                        checkIfMedia(it)
                                    }
                                    canGoBack = view?.canGoBack() == true
                                    canGoForward = view?.canGoForward() == true
                                }

                                override fun shouldOverrideUrlLoading(
                                    view: WebView?,
                                    request: WebResourceRequest?
                                ): Boolean {
                                    val uri = request?.url ?: return false
                                    val scheme = uri.scheme?.lowercase() ?: ""
                                    val urlStr = uri.toString()

                                    // Block app-intent redirects (snssdk1233:, tiktok:, market:, intent:) to keep user on video page
                                    if (scheme != "http" && scheme != "https") {
                                        return true
                                    }

                                    if (checkIfMedia(urlStr)) {
                                        detectedMediaUrl = urlStr
                                    }
                                    return false
                                }

                                override fun onRenderProcessGone(
                                    view: WebView?,
                                    detail: RenderProcessGoneDetail?
                                ): Boolean {
                                    val didCrash = detail?.didCrash() == true
                                    android.util.Log.w(
                                        "BrowserScreen",
                                        "WebView renderer process terminated (didCrash=$didCrash). Recovering WebView instance."
                                    )

                                    try {
                                        (view?.parent as? ViewGroup)?.removeView(view)
                                        view?.destroy()
                                    } catch (_: Exception) {}

                                    webViewInstance = null
                                    isLoading = false

                                    if (currentUrl != defaultHome) {
                                        lastCrashedUrl = currentUrl
                                        currentUrl = defaultHome
                                        addressInput = defaultHome
                                        Toast.makeText(context, "Page renderer terminated. Resetting to home.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Browser recovered from renderer crash", Toast.LENGTH_SHORT).show()
                                    }

                                    rendererKey++
                                    // Returning true prevents aw_browser_terminator from killing the host Android app
                                    return true
                                }

                                private fun checkIfMedia(url: String): Boolean {
                                    val lower = url.lowercase()
                                    val isDirect = lower.endsWith(".mp4") || lower.endsWith(".mp3") ||
                                            lower.endsWith(".m4a") || lower.endsWith(".mkv") ||
                                            lower.endsWith(".webm") || lower.endsWith(".pdf") ||
                                            lower.endsWith(".zip") || lower.endsWith(".apk")
                                    val isVideoPage = (lower.contains("tiktok.com") && lower.contains("/video/")) ||
                                            lower.contains("vt.tiktok.com")
                                    if (isDirect || isVideoPage) {
                                        detectedMediaUrl = url
                                        return true
                                    }
                                    return false
                                }
                            }

                            webChromeClient = object : WebChromeClient() {
                                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                                    pageProgress = newProgress / 100f
                                }

                                override fun onReceivedTitle(view: WebView?, title: String?) {
                                    if (!title.isNullOrBlank()) {
                                        pageTitle = title
                                    }
                                }
                            }

                            webViewInstance = this
                            val urlToLoad = if (rendererKey > 0) currentUrl else targetUrlFromModel.ifBlank { defaultHome }
                            loadUrl(urlToLoad)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
            }

            DisposableEffect(rendererKey) {
                onDispose {
                    try {
                        webViewInstance?.stopLoading()
                        webViewInstance?.destroy()
                    } catch (_: Exception) {}
                    webViewInstance = null
                }
            }
        }
    }
}
