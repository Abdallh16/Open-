package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NOVA Brand Colors
val NovaCyan = Color(0xFF00E5FF)
val NovaCyanDark = Color(0xFF00B0FF)
val NovaBlue = Color(0xFF2979FF)
val NovaNavy = Color(0xFF0D1B2A)
val NovaSurfaceDark = Color(0xFF132238)
val NovaCardDark = Color(0xFF1B2D46)
val NovaBackgroundDark = Color(0xFF09111D)

val NovaGreen = Color(0xFF00E676)
val NovaRed = Color(0xFFFF5252)
val NovaOrange = Color(0xFFFFAB40)

val DarkPrimary = NovaCyan
val DarkOnPrimary = Color(0xFF00363D)
val DarkPrimaryContainer = Color(0xFF004F58)
val DarkOnPrimaryContainer = Color(0xFF9DF5FF)

val DarkBackground = NovaBackgroundDark
val DarkSurface = NovaSurfaceDark
val DarkSurfaceVariant = NovaCardDark
val DarkOnBackground = Color(0xFFE2E8F0)
val DarkOnSurface = Color(0xFFE2E8F0)
val DarkOutline = Color(0xFF334E68)

val LightPrimary = Color(0xFF006877)
val LightOnPrimary = Color.White
val LightPrimaryContainer = Color(0xFFA1EFFF)
val LightOnPrimaryContainer = Color(0xFF001F25)

val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightOnBackground = Color(0xFF0F172A)
val LightOnSurface = Color(0xFF0F172A)
val LightOutline = Color(0xFF94A3B8)
