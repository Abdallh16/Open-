# NOVA — Private Android Media Downloader & Queue Manager

NOVA is a privacy-first, ad-free, high-performance Android media downloader and queue manager built with modern Android standards: Kotlin, Jetpack Compose (Material 3), Room Database, OkHttp, and Android Foreground Services.

Unlike typical downloaders loaded with aggressive advertisements, telemetry tracking, and bloated fake buttons, NOVA focuses strictly on **real extraction, reliability, transparency, and user privacy**.

---

## 🚀 Key Features

### 1. Real Media Extraction Engine
- **Dedicated TikTok Extractor (`TikTokMediaExtractor`)**:
  - Resolves shortened URLs (`vt.tiktok.com`, `vm.tiktok.com`) following redirect chains safely.
  - Extracts the canonical video identifier and retrieves real video details from embedded web data.
  - Discovers all actual available stream resolutions (e.g. 1080p Full HD, 720p HD, 540p, 480p) from real `bitrateInfo`.
  - Discovers and associates the actual original audio stream from `music.playUrl`.
  - Enforces authenticated CDN dispatch headers (`Referer: https://www.tiktok.com/`) to prevent HTTP 403 Forbidden.
- **Direct Media Extractor (`DirectMediaExtractor`)**:
  - Probes direct HTTP/HTTPS URLs (MP4, WebM, MP3, M4A, PDF, ZIP, etc.).
  - Extracts real content size and verifies HTTP Range resume capability.
- **Strict Zero-Fake-Formats Policy**:
  - All mock, placeholder, sample, or invented download formats have been completely eliminated.
  - The format selection screen renders only real, validated media streams extracted from the exact requested URL.
  - If extraction fails (e.g., deleted video, private account, or blocked access), a diagnostic error is presented and no download formats are displayed.

### 2. Universal Download Engine
- **Multi-Task Queue Manager**: Concurrent worker pool respecting user-configured concurrency limits (1 to 5 simultaneous downloads).
- **HTTP Range Resumable Downloads**: Checks existing partial files (`.nova_tmp`). If Range requests are supported and the server returns HTTP 206, it streams and appends remaining bytes. If 200 OK is returned, it safely resets and downloads from byte 0.
- **Accurate Real-Time Telemetry**:
  - Sliding delta byte window calculates exact download speed (e.g., `1.8 MB/s`).
  - Remaining time estimation (ETA) based on active speed and remaining bytes.
  - Byte-accurate progress percentages.
- **Atomic File Management**: Downloads stream into temporary files and are renamed/moved to the destination folder only upon verified completion.
- **Storage Protection**: Queries device storage space via `StatFs` before commencing downloads, preventing corrupted transfers due to full storage.
- **Network Interruption Recovery**: Configurable automatic retry limit (0 to 5) with exponential backoff on `IOException`.
- **Full Task Controls**: Pause, Resume, Cancel, and Retry with immediate thread-safe cancellation and state persistence.

### 3. Built-in Media Player (`NovaMediaPlayerDialog`)
- **Internal Video & Audio Playback**: Plays downloaded files locally without third-party applications.
- **Full Player Controls**:
  - Play, Pause, Seekbar with live position and total track duration.
  - 10-second skip forward (`+10s`) and rewind (`-10s`) buttons.
  - Variable playback speed controls: `0.5x`, `0.75x`, `1.0x`, `1.25x`, `1.5x`, and `2.0x`.
  - Volume slider.
  - Playlist navigation (`Previous` and `Next`) through library files.

### 4. Built-in Lightweight Browser (`BrowserScreen`)
- **Private Web Navigation**: Integrated Android WebView featuring back, forward, reload, and home buttons.
- **Search Engine Integration**: Type any URL or search term; automatically queries via DuckDuckGo without tracking cookies or remote telemetry.
- **Mobile Chrome UA**: Uses standard Mobile Chrome User-Agent without `Version/4.0` to prevent web apps from forcing external app store redirects.
- **Deep Link Protection**: Blocks app-scheme redirects (`snssdk:`, `tiktok:`, `market:`) to preserve in-browser video playback.
- **Direct Media Detection Banner**: Automatically offers to extract and download media whenever navigating to video pages or direct files.

### 5. Android Foreground Service & Background Downloads
- **Foreground Service**: Registered as `foregroundServiceType="dataSync"` for Android 14+ compatibility.
- **Persistent Progress Notification**: Shows active filename, transfer speed, progress bar (percentage or indeterminate), and ETA.
- **Interactive Notification Actions**: Direct notification action buttons to Pause, Resume, or Cancel tasks without opening the application.
- **Restart Recovery**: Interrupted active downloads from unexpected process termination are safely recorded and restored to `PAUSED` state on next launch.

### 6. File Management & Media Library
- **Completed Downloads**: Organized view of all finished files.
- **Media Type Filtering**: Filter by All, Video, Audio, or Documents/Archives.
- **Instant Search**: Real-time filename search.
- **Storage Metrics**: Total disk space utilized by downloaded media files.
- **Android Intent Sharing & Opening**: Integrates with Android `FileProvider` (`content://`) to safely open downloaded files in default media players or share them to other apps.
- **File Deletion**: Safely removes records and deletes the physical files from storage.

### 7. Privacy & Zero-Tracking Guarantee
- **No Advertisements**: Zero ad SDKs, banners, interstitials, or tracking tokens.
- **No Cloud Account Required**: Operates 100% locally on your device.
- **Zero Remote Telemetry**: Does not contact developer servers. HTTP/HTTPS connections are dispatched exclusively to the download targets requested by the user.
- **Storage & Cache Maintenance**: One-click cleanup to flush temporary `.nova_tmp` partial files and clear completed history.
- **Arabic & English Localization**: Full support for English and Arabic with Right-to-Left (RTL) layout.

---

## 🏛️ Architecture & Tech Stack

```
com.example
├── NovaApplication.kt              // App entry & singleton initialization
├── MainActivity.kt                 // Edge-to-edge Compose activity & Share Intent handler
├── extractor/
│   ├── MediaFormat.kt              // Real format and metadata models
│   ├── UrlResolver.kt              // Safe HTTP redirect resolution & SSRF protection
│   ├── TikTokMediaExtractor.kt     // TikTok video & audio extraction pipeline
│   ├── DirectMediaExtractor.kt     // Direct HTTP/HTTPS media probe
│   └── UniversalMediaExtractor.kt  // Extractor orchestrator
├── data/
│   ├── NovaDatabase.kt             // Room Database (SQLite)
│   ├── Converters.kt               // Room type converters
│   ├── model/
│   │   ├── DownloadTaskEntity.kt   // Persistent task entity with customHeadersJson
│   │   ├── DownloadStatus.kt       // State machine enum
│   │   └── AppSettingEntity.kt     // Settings key-value entity
│   ├── dao/
│   │   ├── DownloadDao.kt          // Reactive Flow DAO
│   │   └── SettingDao.kt           // Settings DAO
│   └── repository/
│       └── SettingsRepository.kt   // Config preferences abstraction
├── download/
│   ├── engine/
│   │   └── DownloadEngine.kt       // Queue, Range streaming, speed, ETA, and custom headers
│   └── service/
│       └── DownloadForegroundService.kt // Persistent Android notification & actions
└── ui/
    ├── MainViewModel.kt            // StateFlow coordination & real extraction flow
    ├── player/
    │   └── NovaMediaPlayerDialog.kt // Internal video & audio player
    ├── theme/                      // Nova dark/light high-contrast theme
    └── screens/
        ├── MainScaffold.kt         // NavigationBar & Notification permissions
        ├── AnalyzerScreen.kt       // Real extraction & format selection UI
        ├── QueueScreen.kt          // Active downloads & progress
        ├── BrowserScreen.kt        // Private WebView with media detection
        ├── LibraryScreen.kt        // Completed files, internal player & sharing
        └── SettingsScreen.kt       // Preferences & privacy report
```

---

## 🧪 Automated Testing

All tests are implemented using JUnit 4 and Robolectric:

- **`MediaExtractorTest`**:
  - Live extraction on `https://vt.tiktok.com/ZSp1DAPuW/`: verifies redirection to canonical URL, video ID `7279419456323947782`, author `@grandson_ibrahim_al_fiqi`, discovery of all 7 real formats (1080p, 720p, 540p, 480p, and original audio), and Referer headers.
  - HTML page rejection: verifies generic HTML pages return extraction failure without inventing formats.
  - Invalid protocol rejection: verifies unsupported protocols fail gracefully.
  - Private IP blocking: verifies SSRF protection against `127.0.0.1` and internal networks.
  - Byte formatting math verification.
- **`NovaDatabaseTest`**:
  - In-memory Room database initialization.
  - Inserting tasks, querying active vs completed queues.
  - State machine transitions (`QUEUED` -> `DOWNLOADING` -> `COMPLETED`).
  - Interrupted task detection and restoration.
  - SettingDao persistence.
- **`DownloadTaskEntityTest`**:
  - Progress percentage calculations.
  - Indeterminate stream handling (`totalBytes = -1`).
  - Status flags (`isActive`, `isTerminal`).

To execute tests:
```bash
gradle :app:testDebugUnitTest
```

---

## 🛠️ Build & Installation

### Requirements
- Android SDK 36 (targetSdk 36, minSdk 24)
- JDK 17
- Gradle 9.x

### Build Debug APK
```bash
gradle :app:assembleDebug
```
The resulting APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`
