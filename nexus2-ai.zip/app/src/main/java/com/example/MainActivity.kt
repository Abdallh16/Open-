package com.example

import android.os.Bundle
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.ui.NexusApp
import com.example.ui.theme.NexusTheme
import com.example.data.mcp.McpOAuthManager

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleOAuthIntent(intent)
        enableEdgeToEdge()
        setContent {
            NexusTheme(darkTheme = true) {
                NexusApp()
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleOAuthIntent(intent)
    }

    private fun handleOAuthIntent(intent: Intent?) {
        val uri = intent?.data ?: return
        if (uri.scheme == "nexusai" && uri.host == "oauth" && uri.path == "/callback") {
            McpOAuthManager.callbacks.tryEmit(uri)
        }
    }
}
