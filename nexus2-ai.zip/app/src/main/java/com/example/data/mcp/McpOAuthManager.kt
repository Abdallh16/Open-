package com.example.data.mcp

import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.flow.MutableSharedFlow
import java.security.SecureRandom

/** Shared OAuth callback bridge between the Android activity and the MCP view model. */
object McpOAuthManager {
    const val REDIRECT_URI = "nexusai://oauth/callback"
    val callbacks = MutableSharedFlow<Uri>(replay = 1, extraBufferCapacity = 1)

    data class PendingAuthorization(
        val endpoint: String,
        val clientId: String,
        val tokenEndpoint: String,
        val redirectUri: String,
        val state: String,
        val codeVerifier: String,
        val scope: String
    )

    @Volatile
    var pending: PendingAuthorization? = null

    fun randomUrlSafe(bytes: Int = 32): String {
        val value = ByteArray(bytes)
        SecureRandom().nextBytes(value)
        return Base64.encodeToString(value, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }
}

data class McpOAuthTokens(
    val accessToken: String,
    val refreshToken: String = "",
    val expiresIn: Long? = null
)
