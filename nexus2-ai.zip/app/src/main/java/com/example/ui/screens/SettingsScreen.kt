package com.example.ui.screens

import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LinkOff
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.mcp.McpIntegrationType
import com.example.data.mcp.McpServiceConfig
import com.example.data.mcp.OAuthStatus
import com.example.data.preferences.ApiProvider
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalDark
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CharcoalSurfaceVariant
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.ui.viewmodel.SettingsSection
import com.example.ui.viewmodel.SettingsViewModel
import com.example.ui.viewmodel.TestConnectionState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onNavigateBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentSection by viewModel.currentSection.collectAsState()
    val notification by viewModel.statusNotification.collectAsState()

    BackHandler {
        if (!viewModel.navigateBack()) {
            onNavigateBack()
        }
    }

    LaunchedEffect(notification) {
        notification?.let {
            Toast.makeText(context, it, Toast.LENGTH_SHORT).show()
            viewModel.clearNotification()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = when (currentSection) {
                                SettingsSection.HUB -> "إعدادات النظام والوكيل"
                                SettingsSection.MODELS_AND_PROVIDERS -> "محرك الذكاء الاصطناعي والمزودين"
                                SettingsSection.MCP_INTEGRATIONS -> "توصيل الحسابات وبروتوكول MCP"
                                SettingsSection.DATA_MANAGEMENT -> "الذاكرة والتخزين المحلي"
                            },
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Text(
                            text = when (currentSection) {
                                SettingsSection.HUB -> "لوحة التحكم والتكامل الاحترافية"
                                SettingsSection.MODELS_AND_PROVIDERS -> "تهيئة المفاتيح، الـ Endpoints، واختبار النماذج"
                                SettingsSection.MCP_INTEGRATIONS -> "المصادقة الرسمية عبر المتصفح والتحقق الفعلي"
                                SettingsSection.DATA_MANAGEMENT -> "إدارة قاعدة بيانات Room وسجل الرسائل"
                            },
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (!viewModel.navigateBack()) {
                                onNavigateBack()
                            }
                        },
                        modifier = Modifier.testTag("settings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = TextPrimary
                        )
                    }
                },
                actions = {
                    if (currentSection == SettingsSection.MODELS_AND_PROVIDERS) {
                        IconButton(
                            onClick = { viewModel.saveSettings() },
                            modifier = Modifier.testTag("settings_save_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Save,
                                contentDescription = "حفظ",
                                tint = PurplePrimary
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CharcoalDark)
            )
        },
        containerColor = CharcoalDark,
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (currentSection != SettingsSection.HUB) {
                ScrollableTabRow(
                    selectedTabIndex = when (currentSection) {
                        SettingsSection.MODELS_AND_PROVIDERS -> 0
                        SettingsSection.MCP_INTEGRATIONS -> 1
                        SettingsSection.DATA_MANAGEMENT -> 2
                        else -> 0
                    },
                    containerColor = CharcoalSurface,
                    contentColor = PurplePrimary,
                    edgePadding = 12.dp
                ) {
                    Tab(
                        selected = currentSection == SettingsSection.MODELS_AND_PROVIDERS,
                        onClick = { viewModel.setSection(SettingsSection.MODELS_AND_PROVIDERS) },
                        text = { Text("المزودين والنماذج", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    Tab(
                        selected = currentSection == SettingsSection.MCP_INTEGRATIONS,
                        onClick = { viewModel.setSection(SettingsSection.MCP_INTEGRATIONS) },
                        text = { Text("توصيل الحسابات (OAuth & MCP)", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                    )
                    Tab(
                        selected = currentSection == SettingsSection.DATA_MANAGEMENT,
                        onClick = { viewModel.setSection(SettingsSection.DATA_MANAGEMENT) },
                        text = { Text("البيانات والذاكرة", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
                    )
                }
            }

            AnimatedContent(
                targetState = currentSection,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "settings_section_transition"
            ) { section ->
                when (section) {
                    SettingsSection.HUB -> ProfessionalSettingsHub(
                        viewModel = viewModel,
                        onOpenSection = { viewModel.setSection(it) }
                    )

                    SettingsSection.MODELS_AND_PROVIDERS -> ProfessionalModelsSection(
                        viewModel = viewModel,
                        onNavigateBackToHub = { viewModel.setSection(SettingsSection.HUB) }
                    )

                    SettingsSection.MCP_INTEGRATIONS -> ProfessionalOAuthMcpSection(
                        viewModel = viewModel,
                        onNavigateBackToHub = { viewModel.setSection(SettingsSection.HUB) }
                    )

                    SettingsSection.DATA_MANAGEMENT -> ProfessionalDataSection(
                        viewModel = viewModel,
                        onNavigateBackToHub = { viewModel.setSection(SettingsSection.HUB) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ProfessionalSettingsHub(
    viewModel: SettingsViewModel,
    onOpenSection: (SettingsSection) -> Unit,
    modifier: Modifier = Modifier
) {
    val provider by viewModel.provider.collectAsState()
    val model by viewModel.model.collectAsState()
    val apiKey by viewModel.apiKey.collectAsState()
    val activeToolsCount = viewModel.getActiveMcpToolsCount()

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ProfessionalMenuRow(
                icon = Icons.Default.Tune,
                title = "محرك الذكاء الاصطناعي (AI Models & Providers)",
                subtitle = "مزود الخدمة، عنوان Base URL، مفاتيح التشغيل، جلب النماذج الحية، ومعايير النظام",
                statusPillText = if (apiKey.isNotBlank()) "${provider.displayNameArabic} | ${model.ifBlank { "جاهز" }}" else "غير مهيأ",
                isStatusActive = apiKey.isNotBlank(),
                onClick = { onOpenSection(SettingsSection.MODELS_AND_PROVIDERS) },
                testTag = "hub_card_models_providers"
            )
        }

        item {
            ProfessionalMenuRow(
                icon = Icons.Default.Hub,
                title = "توصيل الحسابات وبروتوكول MCP (OAuth 2.0)",
                subtitle = "المصادقة في المتصفح وتفويض Notion و Canva و Adobe و GitHub واكتشاف خوادم MCP",
                statusPillText = "$activeToolsCount خدمات مفوضة",
                isStatusActive = activeToolsCount > 0,
                onClick = { onOpenSection(SettingsSection.MCP_INTEGRATIONS) },
                testTag = "hub_card_mcp_integrations"
            )
        }

        item {
            ProfessionalMenuRow(
                icon = Icons.Default.Storage,
                title = "الذاكرة والتخزين المحلي (Database & Privacy)",
                subtitle = "إدارة قاعدة بيانات Room المحلية وتفريغ سجل المحادثات وضمان خصوصية العميل",
                statusPillText = "تخزين مشفر محلياً",
                isStatusActive = false,
                onClick = { onOpenSection(SettingsSection.DATA_MANAGEMENT) },
                testTag = "hub_card_data_management"
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(CharcoalBorder))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "المواصفات التقنية للنظام",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "• المصادقة: فتح صفحة تسجيل الدخول الرسمية بالمتصفح والتحقق الفعلي عبر API\n" +
                                "• بروتوكول MCP: بروتوكول سياق النموذج القياسي عبر JSON-RPC 2.0 و SSE مع فحص استجابة حقيقي\n" +
                                "• محرك الشبكة: OkHttpClient مدمج لدعم طلبات cURL والاتصال الحي بالإنترنت",
                        color = TextMuted,
                        fontSize = 11.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun ProfessionalMenuRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    statusPillText: String,
    isStatusActive: Boolean,
    onClick: () -> Unit,
    testTag: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .testTag(testTag),
        colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
        shape = RoundedCornerShape(14.dp),
        border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(CharcoalBorder))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(CharcoalSurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isStatusActive) CyanAccent else PurplePrimary,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = title,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = subtitle,
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isStatusActive) SuccessGreen.copy(alpha = 0.15f) else CharcoalSurfaceVariant)
                            .border(1.dp, if (isStatusActive) SuccessGreen.copy(alpha = 0.4f) else CharcoalBorder, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = statusPillText,
                            color = if (isStatusActive) SuccessGreen else TextMuted,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = TextMuted,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun ProfessionalModelsSection(
    viewModel: SettingsViewModel,
    onNavigateBackToHub: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val provider by viewModel.provider.collectAsState()
    val baseUrl by viewModel.baseUrl.collectAsState()
    val apiKey by viewModel.apiKey.collectAsState()
    val model by viewModel.model.collectAsState()
    val systemPrompt by viewModel.systemPrompt.collectAsState()
    val temperature by viewModel.temperature.collectAsState()
    val availableModels by viewModel.availableModels.collectAsState()
    val isFetchingModels by viewModel.isFetchingModels.collectAsState()
    val testState by viewModel.testState.collectAsState()

    var isApiKeyVisible by remember { mutableStateOf(false) }
    var showModelsDropdown by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(CharcoalBorder))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "مزود الخدمة (API Provider)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        ApiProvider.entries.forEach { p ->
                            val selected = p == provider
                            FilterChip(
                                selected = selected,
                                onClick = { viewModel.selectProvider(p) },
                                label = { Text(p.displayNameArabic, fontSize = 12.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = PurplePrimary.copy(alpha = 0.25f),
                                    selectedLabelColor = PurplePrimary,
                                    containerColor = CharcoalDark,
                                    labelColor = TextSecondary
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = selected,
                                    borderColor = CharcoalBorder,
                                    selectedBorderColor = PurplePrimary
                                )
                            )
                        }
                    }

                    Text(
                        text = "عنوان الخادم (Base URL)",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = baseUrl,
                        onValueChange = { viewModel.setBaseUrl(it) },
                        modifier = Modifier.fillMaxWidth().testTag("endpoint_input_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = CharcoalBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CharcoalDark,
                            unfocusedContainerColor = CharcoalDark
                        ),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true
                    )

                    Text(
                        text = "مفتاح API (Secret Key)",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = { viewModel.setApiKey(it) },
                        modifier = Modifier.fillMaxWidth().testTag("api_key_input_field"),
                        placeholder = { Text("sk-...", color = TextMuted, fontSize = 12.sp) },
                        visualTransformation = if (isApiKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = clipboard.primaryClip
                                        if (clip != null && clip.itemCount > 0) {
                                            val pasted = clip.getItemAt(0).text?.toString().orEmpty()
                                            if (pasted.isNotBlank()) {
                                                viewModel.setApiKey(pasted)
                                                Toast.makeText(context, "تم اللصق", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                ) {
                                    Icon(imageVector = Icons.Default.ContentPaste, contentDescription = "لصق", tint = CyanAccent, modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { isApiKeyVisible = !isApiKeyVisible }) {
                                    Icon(imageVector = if (isApiKeyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = null, tint = TextMuted, modifier = Modifier.size(18.dp))
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = CharcoalBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CharcoalDark,
                            unfocusedContainerColor = CharcoalDark
                        ),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true
                    )
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(CharcoalBorder))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "النموذج المحدد (Model ID)",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.weight(1f)) {
                            OutlinedTextField(
                                value = model,
                                onValueChange = { viewModel.setModel(it) },
                                modifier = Modifier.fillMaxWidth().testTag("model_input_field"),
                                trailingIcon = {
                                    if (availableModels.isNotEmpty()) {
                                        IconButton(onClick = { showModelsDropdown = true }) {
                                            Icon(imageVector = Icons.Default.ArrowDropDown, contentDescription = null, tint = CyanAccent)
                                        }
                                    }
                                },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = PurplePrimary,
                                    unfocusedBorderColor = CharcoalBorder,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary,
                                    focusedContainerColor = CharcoalDark,
                                    unfocusedContainerColor = CharcoalDark
                                ),
                                shape = RoundedCornerShape(8.dp),
                                singleLine = true
                            )

                            DropdownMenu(
                                expanded = showModelsDropdown,
                                onDismissRequest = { showModelsDropdown = false },
                                modifier = Modifier.fillMaxWidth(0.8f).background(CharcoalSurfaceVariant)
                            ) {
                                availableModels.take(30).forEach { mName ->
                                    DropdownMenuItem(
                                        text = { Text(mName, color = TextPrimary, fontSize = 12.sp) },
                                        onClick = {
                                            viewModel.setModel(mName)
                                            showModelsDropdown = false
                                        }
                                    )
                                }
                            }
                        }

                        Button(
                            onClick = {
                                viewModel.saveSettings()
                                viewModel.fetchModelsLive()
                            },
                            modifier = Modifier.height(52.dp).testTag("fetch_models_button"),
                            colors = ButtonDefaults.buttonColors(containerColor = CharcoalSurfaceVariant),
                            shape = RoundedCornerShape(8.dp),
                            enabled = !isFetchingModels
                        ) {
                            if (isFetchingModels) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = CyanAccent, strokeWidth = 2.dp)
                            } else {
                                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                            }
                        }
                    }

                    when (val state = testState) {
                        is TestConnectionState.Success -> {
                            Box(
                                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Color(0xFF0F2618)).padding(8.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(16.dp))
                                    Text(text = state.message, color = SuccessGreen, fontSize = 11.sp)
                                }
                            }
                        }
                        is TestConnectionState.Error -> {
                            Box(
                                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Color(0xFF291214)).padding(8.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Icon(imageVector = Icons.Default.Error, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(16.dp))
                                    Text(text = state.message, color = Color(0xFFFCA5A5), fontSize = 11.sp)
                                }
                            }
                        }
                        else -> {}
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(CharcoalBorder))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(text = "التوجيه المسبق (System Prompt)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    OutlinedTextField(
                        value = systemPrompt,
                        onValueChange = { viewModel.setSystemPrompt(it) },
                        modifier = Modifier.fillMaxWidth().testTag("system_prompt_input_field"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = CharcoalBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CharcoalDark,
                            unfocusedContainerColor = CharcoalDark
                        ),
                        shape = RoundedCornerShape(8.dp),
                        minLines = 2,
                        maxLines = 4
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("مستوى الإبداع (Temperature):", color = TextSecondary, fontSize = 12.sp)
                        Text(String.format("%.2f", temperature), color = CyanAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Slider(
                        value = temperature,
                        onValueChange = { viewModel.setTemperature(it) },
                        valueRange = 0.0f..1.5f,
                        colors = SliderDefaults.colors(thumbColor = PurplePrimary, activeTrackColor = PurplePrimary, inactiveTrackColor = CharcoalBorder)
                    )
                }
            }
        }

        item {
            Button(
                onClick = {
                    viewModel.saveSettings()
                    Toast.makeText(context, "تم حفظ الإعدادات", Toast.LENGTH_SHORT).show()
                    onNavigateBackToHub()
                },
                modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_models_settings_button"),
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(imageVector = Icons.Default.Save, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.size(8.dp))
                Text("حفظ التغييرات", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun ProfessionalOAuthMcpSection(
    viewModel: SettingsViewModel,
    onNavigateBackToHub: () -> Unit,
    modifier: Modifier = Modifier
) {
    val mcpConfigs by viewModel.mcpConfigs.collectAsState()
    val verifyingType by viewModel.verifyingMcpType.collectAsState()
    var selectedOAuthDialogType by remember { mutableStateOf<McpIntegrationType?>(null) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(CharcoalBorder))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(18.dp))
                        Text(
                            text = "المصادقة الرسمية وربط الحسابات (OAuth 2.0 & MCP)",
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Text(
                        text = "يفتح التطبيق صفحة المصادقة الرسمية للخدمة في المتصفح الخارجي لتسجيل الدخول، ثم يتحقق فعلياً من صلاحية الرمز والاتصال عبر طلبات HTTP المباشرة قبل تأكيد الربط.",
                        color = TextMuted,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        items(McpIntegrationType.entries) { type ->
            val config = mcpConfigs[type] ?: McpServiceConfig(type = type)
            val isVerifying = verifyingType == type

            ProfessionalOAuthServiceCard(
                config = config,
                isVerifying = isVerifying,
                onConnectClick = {
                    selectedOAuthDialogType = type
                },
                onDisconnectClick = {
                    viewModel.disconnectOAuthAccount(type)
                }
            )
        }
    }

    selectedOAuthDialogType?.let { type ->
        RealOAuthDialog(
            type = type,
            isVerifying = verifyingType == type,
            onDismiss = { selectedOAuthDialogType = null },
            onOpenBrowser = {
                viewModel.openOAuthInBrowser(type)
            },
            onStartMcpOAuth = { endpoint ->
                viewModel.startMcpOAuth(endpoint) { success, _ -> if (success) selectedOAuthDialogType = null }
            },
            onVerifyAndConnect = { token, customEndpoint ->
                if (type == McpIntegrationType.CUSTOM_MCP) {
                    viewModel.startMcpOAuth(customEndpoint) { success, _ -> if (success) selectedOAuthDialogType = null }
                } else {
                    viewModel.verifyAndConnectOAuth(type, token, customEndpoint) { success, _ ->
                        if (success) selectedOAuthDialogType = null
                    }
                }
            }
        )
    }
}

@Composable
private fun ProfessionalOAuthServiceCard(
    config: McpServiceConfig,
    isVerifying: Boolean,
    onConnectClick: () -> Unit,
    onDisconnectClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isConnected = config.oauthStatus == OAuthStatus.CONNECTED

    val icon: ImageVector = when (config.type) {
        McpIntegrationType.NOTION -> Icons.AutoMirrored.Filled.MenuBook
        McpIntegrationType.CANVA -> Icons.Default.Palette
        McpIntegrationType.ADOBE -> Icons.Default.AutoAwesome
        McpIntegrationType.GITHUB -> Icons.Default.AccountTree
        McpIntegrationType.WEB_SEARCH -> Icons.Default.Language
        McpIntegrationType.CUSTOM_MCP -> Icons.Default.Extension
    }

    Card(
        modifier = modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
        shape = RoundedCornerShape(12.dp),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = SolidColor(if (isConnected) CyanAccent.copy(alpha = 0.5f) else CharcoalBorder)
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(CharcoalSurfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = icon, contentDescription = null, tint = if (isConnected) CyanAccent else TextSecondary, modifier = Modifier.size(20.dp))
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = config.type.displayNameArabic,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = config.type.serviceProviderArabic,
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isConnected) SuccessGreen.copy(alpha = 0.15f) else CharcoalSurfaceVariant)
                        .border(1.dp, if (isConnected) SuccessGreen.copy(alpha = 0.4f) else CharcoalBorder, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (isConnected) "متصل ومفوض" else "غير مرتبط",
                        color = if (isConnected) SuccessGreen else TextMuted,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Text(
                text = config.type.descriptionArabic,
                color = TextSecondary,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            Text(
                text = "الصلاحيات (Scopes): ${config.scopes.joinToString(" • ")}",
                color = TextMuted,
                fontSize = 10.sp
            )

            if (isConnected && config.accountName.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(CharcoalDark)
                        .border(1.dp, CharcoalBorder, RoundedCornerShape(6.dp))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الحساب المتصل: ${config.accountName}",
                            color = CyanAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = SuccessGreen, modifier = Modifier.size(14.dp))
                    }
                }
            }

            HorizontalDivider(color = CharcoalBorder, thickness = 0.5.dp)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (config.type == McpIntegrationType.WEB_SEARCH) {
                    Text(
                        text = "محرك الويب و cURL متصل بالإنترنت ومفعل تلقائياً",
                        color = SuccessGreen,
                        fontSize = 11.sp
                    )
                } else if (isConnected) {
                    OutlinedButton(
                        onClick = onDisconnectClick,
                        modifier = Modifier.height(36.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                        border = ButtonDefaults.outlinedButtonBorder().copy(brush = SolidColor(ErrorRed.copy(alpha = 0.4f))),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.LinkOff, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("إلغاء الربط (Disconnect)", color = ErrorRed, fontSize = 11.sp)
                    }
                } else {
                    Button(
                        onClick = onConnectClick,
                        modifier = Modifier.height(36.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                        shape = RoundedCornerShape(8.dp),
                        enabled = !isVerifying
                    ) {
                        Icon(imageVector = Icons.Default.Link, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text(
                            text = if (config.type == McpIntegrationType.CUSTOM_MCP) "فحص واتصال خادم MCP" else "تسجيل الدخول وربط الحساب",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun RealOAuthDialog(
    type: McpIntegrationType,
    isVerifying: Boolean,
    onDismiss: () -> Unit,
    onOpenBrowser: () -> Unit,
    onStartMcpOAuth: (String) -> Unit,
    onVerifyAndConnect: (token: String, customEndpoint: String) -> Unit
) {
    val context = LocalContext.current
    var tokenInput by remember { mutableStateOf("") }
    var endpointInput by remember { mutableStateOf(if (type == McpIntegrationType.CUSTOM_MCP) "http://10.0.2.2:8000/mcp" else "") }
    var browserOpened by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = CyanAccent)
                Text(
                    text = "مصادقة ${type.displayNameArabic}",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (type != McpIntegrationType.CUSTOM_MCP) {
                    // STEP 1: Launch real OAuth in browser
                    Text(
                        text = "الخطوة 1: تسجيل الدخول والمصادقة في المتصفح",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    Button(
                        onClick = {
                            onOpenBrowser()
                            browserOpened = true
                            Toast.makeText(context, "جارٍ فتح صفحة تسجيل الدخول في المتصفح...", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth().height(40.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CharcoalSurfaceVariant),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.OpenInNew, contentDescription = null, tint = CyanAccent, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("فتح صفحة المصادقة في المتصفح ↗", color = CyanAccent, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    }

                    if (browserOpened) {
                        Text(
                            text = "✓ تم توجيهك إلى صفحة تسجيل الدخول الرسمية. بعد إتمام الموافقة، انسخ رمز الوصول أو المفتاح وضعه بالأسفل:",
                            color = SuccessGreen,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }

                    // STEP 2: Paste and verify token
                    Text(
                        text = "الخطوة 2: تأكيد رمز الوصول والتحقق الفعلي",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    OutlinedTextField(
                        value = tokenInput,
                        onValueChange = { tokenInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("رمز المصادقة (Token / Secret)...", color = TextMuted, fontSize = 11.sp) },
                        trailingIcon = {
                            IconButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = clipboard.primaryClip
                                    if (clip != null && clip.itemCount > 0) {
                                        val pasted = clip.getItemAt(0).text?.toString().orEmpty()
                                        if (pasted.isNotBlank()) {
                                            tokenInput = pasted
                                            Toast.makeText(context, "تم اللصق", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                            ) {
                                Icon(imageVector = Icons.Default.ContentPaste, contentDescription = "لصق", tint = CyanAccent, modifier = Modifier.size(18.dp))
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = CharcoalBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CharcoalDark,
                            unfocusedContainerColor = CharcoalDark
                        ),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true
                    )
                } else {
                    // Custom MCP Endpoint input
                    Text(
                        text = "عنوان خادم MCP المحلي أو السحابي:",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = endpointInput,
                        onValueChange = { endpointInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("http://10.0.2.2:8000/mcp", color = TextMuted, fontSize = 11.sp) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PurplePrimary,
                            unfocusedBorderColor = CharcoalBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedContainerColor = CharcoalDark,
                            unfocusedContainerColor = CharcoalDark
                        ),
                        shape = RoundedCornerShape(8.dp),
                        singleLine = true
                    )
                    Text(
                        text = "سيكتشف التطبيق OAuth metadata تلقائياً، ثم يفتح تسجيل الدخول الآمن في المتصفح ويعود إلى التطبيق عبر PKCE. لا تحتاج إلى نسخ أي مفتاح.",
                        color = TextMuted,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (type == McpIntegrationType.CUSTOM_MCP) onStartMcpOAuth(endpointInput)
                    else onVerifyAndConnect(tokenInput, endpointInput)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PurplePrimary),
                enabled = !isVerifying
            ) {
                if (isVerifying) {
                    CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color.White, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.size(6.dp))
                    Text("جارٍ التحقق الفعلي عبر الإنترنت…", color = Color.White, fontSize = 11.sp)
                } else {
                    Text(if (type == McpIntegrationType.CUSTOM_MCP) "تسجيل الدخول عبر OAuth والاتصال" else "التحقق والاتصال الفعلي (Verify & Connect)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss, enabled = !isVerifying) {
                Text("إلغاء", color = TextSecondary, fontSize = 12.sp)
            }
        },
        containerColor = CharcoalSurfaceVariant
    )
}

@Composable
private fun ProfessionalDataSection(
    viewModel: SettingsViewModel,
    onNavigateBackToHub: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showDeleteConfirm by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = CharcoalSurface),
                shape = RoundedCornerShape(12.dp),
                border = CardDefaults.outlinedCardBorder().copy(brush = SolidColor(CharcoalBorder))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "الخصوصية والتخزين المحلي المباشر",
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "تُخزن جميع المحادثات ونتائج استدعاء الأدوات محلياً على جهازك في قاعدة بيانات SQLite عبر مكتبة Room. لا يتم مشاركة سجل المحادثات أو أسرار OAuth مع أي خوادم خارجية.",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedButton(
                        onClick = { showDeleteConfirm = true },
                        modifier = Modifier.fillMaxWidth().height(44.dp).testTag("delete_all_conversations_button"),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                        border = ButtonDefaults.outlinedButtonBorder().copy(brush = SolidColor(ErrorRed.copy(alpha = 0.5f))),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.size(6.dp))
                        Text("مسح سجل المحادثات بالكامل", color = ErrorRed, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text(text = "تأكيد مسح كافة المحادثات", color = TextPrimary, fontWeight = FontWeight.Bold) },
            text = { Text(text = "سيتم مسح جميع الرسائل والمحادثات المخزنة محلياً نهائياً. لا يمكن التراجع عن هذا الإجراء.", color = TextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.clearAllConversations {
                            Toast.makeText(context, "تم مسح كافة المحادثات بنجاح", Toast.LENGTH_SHORT).show()
                        }
                        showDeleteConfirm = false
                    }
                ) {
                    Text(text = "مسح الكل الآن", color = ErrorRed, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text(text = stringResource(R.string.cancel), color = TextSecondary)
                }
            },
            containerColor = CharcoalSurfaceVariant
        )
    }
}
