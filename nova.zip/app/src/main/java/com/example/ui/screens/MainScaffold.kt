package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Link
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.core.content.ContextCompat
import com.example.data.model.DownloadStatus
import com.example.ui.MainViewModel
import com.example.ui.NovaTab
import kotlinx.coroutines.flow.collectLatest

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScaffold(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentTab by viewModel.currentTab.collectAsState()
    val activeDownloads by viewModel.activeDownloads.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    // Request notification permission on Android 13+
    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val hasPermission = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasPermission) {
                notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    LaunchedEffect(Unit) {
        viewModel.snackbarEvent.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    // Predictive back / BackHandler: if not on Analyzer tab, back returns to Analyzer
    BackHandler(enabled = currentTab != NovaTab.ANALYZER) {
        viewModel.selectTab(NovaTab.ANALYZER)
    }

    val activeCount = activeDownloads.count { it.status == DownloadStatus.DOWNLOADING || it.status == DownloadStatus.CONNECTING || it.status == DownloadStatus.QUEUED }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = when (currentTab) {
                            NovaTab.ANALYZER -> "NOVA • Link Analyzer"
                            NovaTab.QUEUE -> "Active Queue"
                            NovaTab.LIBRARY -> "Media Library"
                            NovaTab.SETTINGS -> "Settings"
                        },
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors()
            )
        },
        bottomBar = {
            NavigationBar(modifier = Modifier.testTag("bottom_nav_bar")) {
                NavigationBarItem(
                    selected = currentTab == NovaTab.ANALYZER,
                    onClick = { viewModel.selectTab(NovaTab.ANALYZER) },
                    icon = {
                        Icon(
                            if (currentTab == NovaTab.ANALYZER) Icons.Filled.Link else Icons.Outlined.Link,
                            contentDescription = "Analyzer"
                        )
                    },
                    label = { Text("Analyzer") },
                    modifier = Modifier.testTag("tab_analyzer")
                )

                NavigationBarItem(
                    selected = currentTab == NovaTab.QUEUE,
                    onClick = { viewModel.selectTab(NovaTab.QUEUE) },
                    icon = {
                        BadgedBox(
                            badge = {
                                if (activeCount > 0) {
                                    Badge { Text("$activeCount") }
                                }
                            }
                        ) {
                            Icon(
                                if (currentTab == NovaTab.QUEUE) Icons.Filled.Download else Icons.Outlined.Download,
                                contentDescription = "Queue"
                            )
                        }
                    },
                    label = { Text("Queue") },
                    modifier = Modifier.testTag("tab_queue")
                )

                NavigationBarItem(
                    selected = currentTab == NovaTab.LIBRARY,
                    onClick = { viewModel.selectTab(NovaTab.LIBRARY) },
                    icon = {
                        Icon(
                            if (currentTab == NovaTab.LIBRARY) Icons.Filled.Folder else Icons.Outlined.Folder,
                            contentDescription = "Library"
                        )
                    },
                    label = { Text("Library") },
                    modifier = Modifier.testTag("tab_library")
                )

                NavigationBarItem(
                    selected = currentTab == NovaTab.SETTINGS,
                    onClick = { viewModel.selectTab(NovaTab.SETTINGS) },
                    icon = {
                        Icon(
                            if (currentTab == NovaTab.SETTINGS) Icons.Filled.Settings else Icons.Outlined.Settings,
                            contentDescription = "Settings"
                        )
                    },
                    label = { Text("Settings") },
                    modifier = Modifier.testTag("tab_settings")
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                NovaTab.ANALYZER -> AnalyzerScreen(viewModel = viewModel)
                NovaTab.QUEUE -> QueueScreen(viewModel = viewModel)
                NovaTab.LIBRARY -> LibraryScreen(viewModel = viewModel)
                NovaTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
            }
        }
    }
}
