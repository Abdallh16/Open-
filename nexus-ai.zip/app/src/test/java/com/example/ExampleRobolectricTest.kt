package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.preferences.ApiProvider
import com.example.ui.components.MarkdownBlock
import com.example.ui.components.parseMarkdown
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Nexus AI", appName)
  }

  @Test
  fun `test markdown parser handles headings and code blocks`() {
    val md = """
      # عنوان رئيسي
      هذا نص باللغة العربية.
      ```kotlin
      val greeting = "مرحبا"
      ```
      - نقطة 1
      - نقطة 2
    """.trimIndent()

    val blocks = parseMarkdown(md)
    assertTrue(blocks.any { it is MarkdownBlock.Heading && it.text == "عنوان رئيسي" })
    assertTrue(blocks.any { it is MarkdownBlock.CodeBlock && it.language == "kotlin" })
    assertTrue(blocks.any { it is MarkdownBlock.BulletItem && it.text == "نقطة 1" })
  }

  @Test
  fun `test api provider presets have valid base urls`() {
    assertTrue(ApiProvider.OPENAI.defaultBaseUrl.startsWith("https://"))
    assertTrue(ApiProvider.GROQ.defaultBaseUrl.startsWith("https://"))
    assertTrue(ApiProvider.OPENROUTER.defaultBaseUrl.startsWith("https://"))
  }
}
