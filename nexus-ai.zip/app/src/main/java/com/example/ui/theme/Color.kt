package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Deep charcoal & dark mode backgrounds
val CharcoalDark = Color(0xFF090A0F)        // Deepest canvas
val CharcoalSurface = Color(0xFF10131B)     // Cards & containers
val CharcoalSurfaceVariant = Color(0xFF181C28) // Elevated surfaces
val CharcoalBorder = Color(0xFF262D40)      // Subtle card borders
val CharcoalBorderFocused = Color(0xFF3E4866)

// Electric accents & brand gradients
val PurplePrimary = Color(0xFF8B5CF6)       // Violet/Purple primary
val PurpleDeep = Color(0xFF6D28D9)          // Darker purple
val PurpleGlow = Color(0xFF9333EA)
val ElectricBlue = Color(0xFF3B82F6)        // Vibrant Electric Blue
val ElectricBlueLight = Color(0xFF60A5FA)
val CyanAccent = Color(0xFF06B6D4)          // Futuristic Cyan

// Functional / States
val SuccessGreen = Color(0xFF10B981)
val SuccessGreenDark = Color(0xFF065F46)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRed = Color(0xFFEF4444)
val ErrorRedSurface = Color(0xFF2E1216)

// Text & Content
val TextPrimary = Color(0xFFF1F5F9)         // Crisp white-gray for read
val TextSecondary = Color(0xFF94A3B8)       // Slate gray for captions
val TextMuted = Color(0xFF64748B)           // Muted text
val CodeBackground = Color(0xFF0B0E14)      // Monospace code blocks
