package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.ConnectionTestResult
import com.example.data.api.NexusApiClient
import com.example.data.local.NexusDatabase
import com.example.data.preferences.ApiPreferences
import com.example.data.preferences.ApiProvider
import com.example.data.preferences.ApiSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class TestConnectionState {
    object Idle : TestConnectionState()
    object Testing : TestConnectionState()
    data class Success(val latencyMs: Long, val message: String) : TestConnectionState()
    data class Error(val message: String) : TestConnectionState()
}

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val apiPreferences = ApiPreferences.getInstance(application)
    private val db = NexusDatabase.getInstance(application)
    private val apiClient = NexusApiClient()

    private val _provider = MutableStateFlow(ApiProvider.OPENAI)
    val provider: StateFlow<ApiProvider> = _provider.asStateFlow()

    private val _baseUrl = MutableStateFlow("")
    val baseUrl: StateFlow<String> = _baseUrl.asStateFlow()

    private val _apiKey = MutableStateFlow("")
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    private val _model = MutableStateFlow("")
    val model: StateFlow<String> = _model.asStateFlow()

    private val _systemPrompt = MutableStateFlow("")
    val systemPrompt: StateFlow<String> = _systemPrompt.asStateFlow()

    private val _temperature = MutableStateFlow(0.7f)
    val temperature: StateFlow<Float> = _temperature.asStateFlow()

    private val _testState = MutableStateFlow<TestConnectionState>(TestConnectionState.Idle)
    val testState: StateFlow<TestConnectionState> = _testState.asStateFlow()

    private val _saveStatusMessage = MutableStateFlow<String?>(null)
    val saveStatusMessage: StateFlow<String?> = _saveStatusMessage.asStateFlow()

    init {
        loadSettings()
    }

    private fun loadSettings() {
        val s = apiPreferences.getSettings()
        _provider.value = s.provider
        _baseUrl.value = s.baseUrl
        _apiKey.value = s.apiKey
        _model.value = s.model
        _systemPrompt.value = s.systemPrompt
        _temperature.value = s.temperature
    }

    fun selectProvider(newProvider: ApiProvider) {
        _provider.value = newProvider
        _baseUrl.value = newProvider.defaultBaseUrl
        _model.value = newProvider.defaultModel
        _testState.value = TestConnectionState.Idle
    }

    fun setBaseUrl(url: String) {
        _baseUrl.value = url
        _testState.value = TestConnectionState.Idle
    }

    fun setApiKey(key: String) {
        _apiKey.value = key
        _testState.value = TestConnectionState.Idle
    }

    fun setModel(m: String) {
        _model.value = m
        _testState.value = TestConnectionState.Idle
    }

    fun setSystemPrompt(prompt: String) {
        _systemPrompt.value = prompt
    }

    fun setTemperature(temp: Float) {
        _temperature.value = temp
    }

    fun saveSettings() {
        val newSettings = ApiSettings(
            provider = _provider.value,
            baseUrl = _baseUrl.value.trim(),
            apiKey = _apiKey.value.trim(),
            model = _model.value.trim(),
            systemPrompt = _systemPrompt.value.trim(),
            temperature = _temperature.value
        )
        apiPreferences.updateSettings(newSettings)
        _saveStatusMessage.value = "تم حفظ الإعدادات بنجاح"
    }

    fun clearStatusMessage() {
        _saveStatusMessage.value = null
    }

    fun testConnection() {
        val currentUrl = _baseUrl.value.trim()
        val currentKey = _apiKey.value.trim()
        val currentModel = _model.value.trim()

        if (currentUrl.isBlank()) {
            _testState.value = TestConnectionState.Error("يرجى إدخال عنوان خادم الـ API (Base URL)")
            return
        }

        if (currentModel.isBlank()) {
            _testState.value = TestConnectionState.Error("يرجى تحديد اسم النموذج (Model Name)")
            return
        }

        _testState.value = TestConnectionState.Testing

        viewModelScope.launch {
            val result: ConnectionTestResult = apiClient.testConnection(
                baseUrl = currentUrl,
                apiKey = currentKey,
                model = currentModel
            )

            if (result.isSuccess) {
                _testState.value = TestConnectionState.Success(result.latencyMs, result.message)
            } else {
                _testState.value = TestConnectionState.Error(result.message)
            }
        }
    }

    fun clearAllConversations(onDone: () -> Unit) {
        viewModelScope.launch {
            db.conversationDao().deleteAllConversations()
            onDone()
        }
    }
}
