package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.automirrored.outlined.Chat
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.R
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.CharcoalBorder
import com.example.ui.theme.CharcoalDark
import com.example.ui.theme.CharcoalSurface
import com.example.ui.theme.CyanAccent
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.PurplePrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.ChatViewModel
import com.example.ui.viewmodel.HomeViewModel
import com.example.ui.viewmodel.SettingsViewModel
import java.net.URLDecoder
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class Screen(val route: String, val titleRes: Int) {
    object Home : Screen("home", R.string.nav_home)
    object Chat : Screen("chat/{conversationId}?initialPrompt={initialPrompt}", R.string.nav_chat) {
        fun createRoute(conversationId: Long = -1L, initialPrompt: String? = null): String {
            val encodedPrompt = initialPrompt?.let {
                URLEncoder.encode(it, StandardCharsets.UTF_8.toString())
            } ?: ""
            return "chat/$conversationId?initialPrompt=$encodedPrompt"
        }
    }
    object Settings : Screen("settings", R.string.nav_settings)
}

@Composable
fun NexusApp() {
    // Enforce full Arabic RTL Layout Direction
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        val navController = rememberNavController()
        val navBackStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = navBackStackEntry?.destination?.route

        val homeViewModel: HomeViewModel = viewModel()
        val chatViewModel: ChatViewModel = viewModel()
        val settingsViewModel: SettingsViewModel = viewModel()

        val showBottomBar = currentRoute == Screen.Home.route || currentRoute == Screen.Settings.route

        Scaffold(
            bottomBar = {
                if (showBottomBar) {
                    NavigationBar(
                        containerColor = CharcoalSurface,
                        contentColor = TextPrimary,
                        tonalElevation = 0.dp,
                        modifier = Modifier
                            .border(1.dp, CharcoalBorder)
                            .testTag("nexus_bottom_navigation")
                    ) {
                        // Home
                        val isHomeSelected = currentRoute == Screen.Home.route
                        NavigationBarItem(
                            selected = isHomeSelected,
                            onClick = {
                                navController.navigate(Screen.Home.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isHomeSelected) Icons.Default.Home else Icons.Outlined.Home,
                                    contentDescription = stringResource(R.string.nav_home)
                                )
                            },
                            label = {
                                Text(
                                    text = stringResource(R.string.nav_home),
                                    fontSize = 11.sp,
                                    fontWeight = if (isHomeSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PurplePrimary,
                                selectedTextColor = PurplePrimary,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary,
                                indicatorColor = PurplePrimary.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.testTag("nav_home_item")
                        )

                        // Chat
                        val isChatSelected = currentRoute?.startsWith("chat") == true
                        NavigationBarItem(
                            selected = isChatSelected,
                            onClick = {
                                navController.navigate(Screen.Chat.createRoute(-1L, null)) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isChatSelected) Icons.AutoMirrored.Filled.Chat else Icons.AutoMirrored.Outlined.Chat,
                                    contentDescription = stringResource(R.string.nav_chat)
                                )
                            },
                            label = {
                                Text(
                                    text = stringResource(R.string.nav_chat),
                                    fontSize = 11.sp,
                                    fontWeight = if (isChatSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PurplePrimary,
                                selectedTextColor = PurplePrimary,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary,
                                indicatorColor = PurplePrimary.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.testTag("nav_chat_item")
                        )

                        // Settings
                        val isSettingsSelected = currentRoute == Screen.Settings.route
                        NavigationBarItem(
                            selected = isSettingsSelected,
                            onClick = {
                                navController.navigate(Screen.Settings.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = if (isSettingsSelected) Icons.Default.Settings else Icons.Outlined.Settings,
                                    contentDescription = stringResource(R.string.nav_settings)
                                )
                            },
                            label = {
                                Text(
                                    text = stringResource(R.string.nav_settings),
                                    fontSize = 11.sp,
                                    fontWeight = if (isSettingsSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PurplePrimary,
                                selectedTextColor = PurplePrimary,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary,
                                indicatorColor = PurplePrimary.copy(alpha = 0.15f)
                            ),
                            modifier = Modifier.testTag("nav_settings_item")
                        )
                    }
                }
            },
            containerColor = CharcoalDark
        ) { innerPadding ->
            NavHost(
                navController = navController,
                startDestination = Screen.Home.route,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                composable(Screen.Home.route) {
                    HomeScreen(
                        viewModel = homeViewModel,
                        onNavigateToChat = { convId, initialPrompt ->
                            navController.navigate(Screen.Chat.createRoute(convId, initialPrompt))
                        },
                        onNavigateToSettings = {
                            navController.navigate(Screen.Settings.route)
                        }
                    )
                }

                composable(
                    route = Screen.Chat.route,
                    arguments = listOf(
                        navArgument("conversationId") {
                            type = NavType.LongType
                            defaultValue = -1L
                        },
                        navArgument("initialPrompt") {
                            type = NavType.StringType
                            defaultValue = ""
                            nullable = true
                        }
                    )
                ) { backStackEntry ->
                    val conversationId = backStackEntry.arguments?.getLong("conversationId") ?: -1L
                    val rawPrompt = backStackEntry.arguments?.getString("initialPrompt").orEmpty()
                    val decodedPrompt = if (rawPrompt.isNotBlank()) {
                        try {
                            URLDecoder.decode(rawPrompt, StandardCharsets.UTF_8.toString())
                        } catch (_: Exception) {
                            rawPrompt
                        }
                    } else {
                        null
                    }

                    ChatScreen(
                        viewModel = chatViewModel,
                        conversationId = conversationId,
                        initialPrompt = decodedPrompt,
                        onNavigateBack = {
                            navController.popBackStack()
                        },
                        onNavigateToSettings = {
                            navController.navigate(Screen.Settings.route)
                        }
                    )
                }

                composable(Screen.Settings.route) {
                    SettingsScreen(
                        viewModel = settingsViewModel,
                        onNavigateBack = {
                            navController.popBackStack()
                        }
                    )
                }
            }
        }
    }
}
