package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ConversationEntity
import com.example.data.local.NexusDatabase
import com.example.data.preferences.ApiPreferences
import com.example.data.preferences.ApiSettings
import com.example.util.NetworkMonitor
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val db = NexusDatabase.getInstance(application)
    private val conversationDao = db.conversationDao()
    private val apiPreferences = ApiPreferences.getInstance(application)
    private val networkMonitor = NetworkMonitor(application)

    val apiSettings: StateFlow<ApiSettings> = apiPreferences.settingsFlow

    val recentConversations: StateFlow<List<ConversationEntity>> =
        conversationDao.getRecentConversations(20)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    fun deleteConversation(id: Long) {
        viewModelScope.launch {
            conversationDao.deleteConversationById(id)
        }
    }

    suspend fun createNewConversation(initialTitle: String = "محادثة جديدة"): Long {
        val currentSettings = apiPreferences.getSettings()
        val newConv = ConversationEntity(
            title = initialTitle,
            modelUsed = currentSettings.model
        )
        return conversationDao.insertConversation(newConv)
    }
}
