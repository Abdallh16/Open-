package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.ApiMessage
import com.example.data.api.NexusApiClient
import com.example.data.local.ConversationEntity
import com.example.data.local.MessageEntity
import com.example.data.local.NexusDatabase
import com.example.data.preferences.ApiPreferences
import com.example.data.preferences.ApiSettings
import com.example.util.NetworkMonitor
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val db = NexusDatabase.getInstance(application)
    private val conversationDao = db.conversationDao()
    private val messageDao = db.messageDao()
    private val apiPreferences = ApiPreferences.getInstance(application)
    private val apiClient = NexusApiClient()
    private val networkMonitor = NetworkMonitor(application)

    val apiSettings: StateFlow<ApiSettings> = apiPreferences.settingsFlow
    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    private val _currentConversationId = MutableStateFlow<Long>(-1L)
    val currentConversationId: StateFlow<Long> = _currentConversationId.asStateFlow()

    private val _currentConversation = MutableStateFlow<ConversationEntity?>(null)
    val currentConversation: StateFlow<ConversationEntity?> = _currentConversation.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private var activeRequestJob: Job? = null

    val messages: StateFlow<List<MessageEntity>> = _currentConversationId
        .flatMapLatest { id ->
            if (id > 0) {
                messageDao.getMessagesForConversation(id)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setConversationId(id: Long) {
        if (_currentConversationId.value != id) {
            _currentConversationId.value = id
            _errorMessage.value = null
            loadConversation(id)
        }
    }

    private fun loadConversation(id: Long) {
        if (id <= 0) {
            _currentConversation.value = null
            return
        }
        viewModelScope.launch {
            _currentConversation.value = conversationDao.getConversationById(id)
        }
    }

    fun startNewConversation() {
        activeRequestJob?.cancel()
        _isGenerating.value = false
        _errorMessage.value = null
        _currentConversationId.value = -1L
        _currentConversation.value = null
    }

    fun sendMessage(userText: String, prefillConversationTitle: String? = null) {
        val trimmed = userText.trim()
        if (trimmed.isEmpty() || _isGenerating.value) return

        val settings = apiPreferences.getSettings()
        if (!settings.isConfigured) {
            _errorMessage.value = "يرجى إضافة مفتاح API وعنوان الخادم في صفحة الإعدادات للبدء."
            return
        }

        if (!networkMonitor.isCurrentlyConnected()) {
            _errorMessage.value = "لا يوجد اتصال بالإنترنت، يرجى التحقق من الشبكة وإعادة المحاولة."
            return
        }

        _errorMessage.value = null
        _isGenerating.value = true

        activeRequestJob = viewModelScope.launch {
            var convId = _currentConversationId.value

            // If new conversation, create entity first
            if (convId <= 0) {
                val title = prefillConversationTitle ?: deriveTitle(trimmed)
                val newConv = ConversationEntity(
                    title = title,
                    modelUsed = settings.model,
                    createdAt = System.currentTimeMillis(),
                    updatedAt = System.currentTimeMillis()
                )
                convId = conversationDao.insertConversation(newConv)
                _currentConversationId.value = convId
                _currentConversation.value = newConv.copy(id = convId)
            } else {
                // Update conversation timestamp
                val existing = _currentConversation.value
                if (existing != null) {
                    conversationDao.updateConversation(
                        existing.copy(updatedAt = System.currentTimeMillis(), modelUsed = settings.model)
                    )
                }
            }

            // Save user message to database
            val userMsg = MessageEntity(
                conversationId = convId,
                role = "user",
                content = trimmed,
                timestamp = System.currentTimeMillis()
            )
            messageDao.insertMessage(userMsg)

            // Gather context messages for API
            val history = messages.value.map {
                ApiMessage(role = it.role, content = it.content)
            } + ApiMessage(role = "user", content = trimmed)

            // Make real network API call
            val result = apiClient.sendChatMessage(
                baseUrl = settings.baseUrl,
                apiKey = settings.apiKey,
                model = settings.model,
                messages = history,
                systemPrompt = settings.systemPrompt,
                temperature = settings.temperature
            )

            result.onSuccess { aiReply ->
                val assistantMsg = MessageEntity(
                    conversationId = convId,
                    role = "assistant",
                    content = aiReply,
                    timestamp = System.currentTimeMillis(),
                    isError = false
                )
                messageDao.insertMessage(assistantMsg)
                _isGenerating.value = false
            }.onFailure { error ->
                val errorText = error.localizedMessage ?: "حدث خطأ أثناء معالجة الطلب."
                val errorMsg = MessageEntity(
                    conversationId = convId,
                    role = "assistant",
                    content = "⚠️ $errorText",
                    timestamp = System.currentTimeMillis(),
                    isError = true
                )
                messageDao.insertMessage(errorMsg)
                _errorMessage.value = errorText
                _isGenerating.value = false
            }
        }
    }

    fun clearCurrentConversation() {
        val convId = _currentConversationId.value
        if (convId > 0) {
            viewModelScope.launch {
                messageDao.deleteMessagesForConversation(convId)
            }
        }
    }

    fun stopGeneration() {
        activeRequestJob?.cancel()
        _isGenerating.value = false
    }

    private fun deriveTitle(firstMessage: String): String {
        val clean = firstMessage.lines().firstOrNull()?.trim().orEmpty()
        return if (clean.length > 35) {
            clean.take(35) + "…"
        } else if (clean.isEmpty()) {
            "محادثة جديدة"
        } else {
            clean
        }
    }
}
