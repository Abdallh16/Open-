package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.ApiMessage
import com.example.data.api.NexusApiClient
import com.example.data.local.ConversationEntity
import com.example.data.local.MessageEntity
import com.example.data.local.NexusDatabase
import com.example.data.preferences.ApiPreferences
import com.example.data.preferences.ApiSettings
import com.example.util.NetworkMonitor
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val db = NexusDatabase.getInstance(application)
    private val conversationDao = db.conversationDao()
    private val messageDao = db.messageDao()
    private val apiPreferences = ApiPreferences.getInstance(application)
    private val apiClient = NexusApiClient()
    private val networkMonitor = NetworkMonitor(application)

    val apiSettings: StateFlow<ApiSettings> = apiPreferences.settingsFlow
    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val allConversations: StateFlow<List<ConversationEntity>> = conversationDao.getAllConversations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _currentConversationId = MutableStateFlow<Long>(-1L)
    val currentConversationId: StateFlow<Long> = _currentConversationId.asStateFlow()

    private val _currentConversation = MutableStateFlow<ConversationEntity?>(null)
    val currentConversation: StateFlow<ConversationEntity?> = _currentConversation.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Immediate reactive state for messages - ensures UI updates in 0ms!
    private val _messagesList = MutableStateFlow<List<MessageEntity>>(emptyList())
    val messages: StateFlow<List<MessageEntity>> = _messagesList.asStateFlow()

    private var activeRequestJob: Job? = null
    private var messagesObservationJob: Job? = null

    init {
        // Load latest conversation once at startup if available
        viewModelScope.launch {
            val latest = conversationDao.getLatestConversation()
            if (latest != null && _currentConversationId.value == -1L) {
                selectConversation(latest.id)
            }
        }
    }

    fun selectConversation(id: Long) {
        activeRequestJob?.cancel()
        _isGenerating.value = false
        _errorMessage.value = null
        _currentConversationId.value = id

        messagesObservationJob?.cancel()
        messagesObservationJob = viewModelScope.launch {
            _currentConversation.value = conversationDao.getConversationById(id)
            messageDao.getMessagesForConversation(id).collect { roomMessages ->
                _messagesList.value = roomMessages
            }
        }
    }

    fun startNewConversation() {
        activeRequestJob?.cancel()
        messagesObservationJob?.cancel()
        _isGenerating.value = false
        _errorMessage.value = null
        _currentConversationId.value = -1L
        _currentConversation.value = null
        _messagesList.value = emptyList()
    }

    fun deleteConversation(id: Long) {
        viewModelScope.launch {
            conversationDao.deleteConversationById(id)
            if (_currentConversationId.value == id) {
                startNewConversation()
            }
        }
    }

    fun sendMessage(userText: String) {
        val trimmed = userText.trim()
        if (trimmed.isEmpty() || _isGenerating.value) return

        val now = System.currentTimeMillis()
        val tempId = now

        // 1. IMMEDIATELY append user message to local state so it appears in UI with 0ms delay!
        val userMsg = MessageEntity(
            id = tempId,
            conversationId = _currentConversationId.value.coerceAtLeast(0),
            role = "user",
            content = trimmed,
            timestamp = now
        )
        _messagesList.value = _messagesList.value + userMsg

        val settings = apiPreferences.getSettings()

        // 2. Check if API key is missing: Show message directly in chat instead of dropping the input!
        if (!settings.isConfigured) {
            val assistantHelpMsg = MessageEntity(
                id = now + 1,
                conversationId = _currentConversationId.value.coerceAtLeast(0),
                role = "assistant",
                content = "⚠️ لم يتم ضبط مفتاح API بعد.\nيرجى فتح **الإعدادات** (عبر أيقونة الترس في القائمة الجانبية ☰) وإدخال مفتاح الـ API وعنوان الخادم لتفعيل الردود الذكية.",
                timestamp = now + 1,
                isError = true
            )
            _messagesList.value = _messagesList.value + assistantHelpMsg

            // Persist both if conversation exists or create one
            viewModelScope.launch {
                ensureConversationAndSaveMessages(trimmed, userMsg, assistantHelpMsg, settings)
            }
            return
        }

        // 3. If configured, make network request
        _isGenerating.value = true
        _errorMessage.value = null

        activeRequestJob = viewModelScope.launch {
            var convId = _currentConversationId.value

            // Create or update conversation in DB
            if (convId <= 0) {
                val title = deriveTitle(trimmed)
                val newConv = ConversationEntity(
                    title = title,
                    modelUsed = settings.model,
                    createdAt = now,
                    updatedAt = now
                )
                convId = conversationDao.insertConversation(newConv)
                _currentConversationId.value = convId
                _currentConversation.value = newConv.copy(id = convId)

                // Start observing DB for this conversation
                observeConversation(convId)
            } else {
                val existing = _currentConversation.value
                if (existing != null) {
                    conversationDao.updateConversation(
                        existing.copy(updatedAt = now, modelUsed = settings.model)
                    )
                }
            }

            // Save user message to database
            val dbUserMsg = userMsg.copy(id = 0, conversationId = convId)
            messageDao.insertMessage(dbUserMsg)

            // Gather conversation context
            val history = _messagesList.value.filter { !it.isError }.map {
                ApiMessage(role = it.role, content = it.content)
            }

            // Execute real network API call
            val result = apiClient.sendChatMessage(
                baseUrl = settings.baseUrl,
                apiKey = settings.apiKey,
                model = settings.model,
                messages = history,
                systemPrompt = settings.systemPrompt,
                temperature = settings.temperature
            )

            result.onSuccess { reply ->
                val assistantMsg = MessageEntity(
                    id = System.currentTimeMillis(),
                    conversationId = convId,
                    role = "assistant",
                    content = reply,
                    timestamp = System.currentTimeMillis(),
                    isError = false
                )
                _messagesList.value = _messagesList.value + assistantMsg
                messageDao.insertMessage(assistantMsg.copy(id = 0))
                _isGenerating.value = false
            }.onFailure { err ->
                val errText = err.localizedMessage ?: "حدث خطأ أثناء معالجة الطلب."
                val errorMsg = MessageEntity(
                    id = System.currentTimeMillis(),
                    conversationId = convId,
                    role = "assistant",
                    content = "⚠️ $errText",
                    timestamp = System.currentTimeMillis(),
                    isError = true
                )
                _messagesList.value = _messagesList.value + errorMsg
                messageDao.insertMessage(errorMsg.copy(id = 0))
                _errorMessage.value = errText
                _isGenerating.value = false
            }
        }
    }

    private suspend fun ensureConversationAndSaveMessages(
        firstMessage: String,
        userMsg: MessageEntity,
        assistantMsg: MessageEntity,
        settings: ApiSettings
    ) {
        var convId = _currentConversationId.value
        if (convId <= 0) {
            val title = deriveTitle(firstMessage)
            val newConv = ConversationEntity(
                title = title,
                modelUsed = settings.model
            )
            convId = conversationDao.insertConversation(newConv)
            _currentConversationId.value = convId
            _currentConversation.value = newConv.copy(id = convId)
            observeConversation(convId)
        }
        messageDao.insertMessage(userMsg.copy(id = 0, conversationId = convId))
        messageDao.insertMessage(assistantMsg.copy(id = 0, conversationId = convId))
    }

    private fun observeConversation(id: Long) {
        messagesObservationJob?.cancel()
        messagesObservationJob = viewModelScope.launch {
            messageDao.getMessagesForConversation(id).collect { roomMessages ->
                if (roomMessages.isNotEmpty()) {
                    _messagesList.value = roomMessages
                }
            }
        }
    }

    fun clearCurrentConversation() {
        val convId = _currentConversationId.value
        if (convId > 0) {
            viewModelScope.launch {
                messageDao.deleteMessagesForConversation(convId)
                _messagesList.value = emptyList()
            }
        } else {
            _messagesList.value = emptyList()
        }
    }

    fun stopGeneration() {
        activeRequestJob?.cancel()
        _isGenerating.value = false
    }

    private fun deriveTitle(firstMessage: String): String {
        val clean = firstMessage.lines().firstOrNull()?.trim().orEmpty()
        return if (clean.length > 35) {
            clean.take(35) + "…"
        } else if (clean.isEmpty()) {
            "محادثة جديدة"
        } else {
            clean
        }
    }
}
