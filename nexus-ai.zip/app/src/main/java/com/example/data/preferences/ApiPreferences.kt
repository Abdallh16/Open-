package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray

enum class ApiProvider(
    val displayNameArabic: String,
    val defaultBaseUrl: String,
    val defaultModel: String,
    val recommendedModels: List<String>
) {
    OPENAI(
        displayNameArabic = "OpenAI",
        defaultBaseUrl = "https://api.openai.com/v1",
        defaultModel = "gpt-4o-mini",
        recommendedModels = listOf("gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo")
    ),
    GROQ(
        displayNameArabic = "Groq",
        defaultBaseUrl = "https://api.groq.com/openai/v1",
        defaultModel = "llama-3.3-70b-versatile",
        recommendedModels = listOf("llama-3.3-70b-versatile", "mixtral-8x7b-32768", "gemma2-9b-it")
    ),
    OPENROUTER(
        displayNameArabic = "OpenRouter",
        defaultBaseUrl = "https://openrouter.ai/api/v1",
        defaultModel = "google/gemini-2.0-flash-001",
        recommendedModels = listOf("google/gemini-2.0-flash-001", "deepseek/deepseek-chat", "meta-llama/llama-3.3-70b-instruct")
    ),
    TOGETHER(
        displayNameArabic = "Together AI",
        defaultBaseUrl = "https://api.together.xyz/v1",
        defaultModel = "meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo",
        recommendedModels = listOf("meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo", "mistralai/Mixtral-8x7B-Instruct-v0.1")
    ),
    CUSTOM(
        displayNameArabic = "خادم مخصص (Ollama / Local)",
        defaultBaseUrl = "http://10.0.2.2:11434/v1",
        defaultModel = "llama3",
        recommendedModels = listOf("llama3", "mistral", "qwen2.5:7b")
    )
}

data class ApiSettings(
    val provider: ApiProvider = ApiProvider.OPENAI,
    val baseUrl: String = ApiProvider.OPENAI.defaultBaseUrl,
    val apiKey: String = "",
    val model: String = ApiProvider.OPENAI.defaultModel,
    val systemPrompt: String = DEFAULT_SYSTEM_PROMPT,
    val temperature: Float = 0.7f,
    val cachedModels: List<String> = emptyList()
) {
    val isConfigured: Boolean
        get() = apiKey.isNotBlank() && baseUrl.isNotBlank() && model.isNotBlank()
}

const val DEFAULT_SYSTEM_PROMPT =
    "أنت Nexus AI، مساعد ذكاء اصطناعي احترافي وموثوق. تجيب باللغة العربية بأسلوب دقيق وواضح وتدعم الأكواد والتنسيق البرمجي."

class ApiPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("nexus_ai_api_prefs", Context.MODE_PRIVATE)

    private val _settingsFlow = MutableStateFlow(loadSettings())
    val settingsFlow: StateFlow<ApiSettings> = _settingsFlow.asStateFlow()

    fun getSettings(): ApiSettings = _settingsFlow.value

    fun updateSettings(newSettings: ApiSettings) {
        val jsonArray = JSONArray(newSettings.cachedModels)
        prefs.edit()
            .putString(KEY_PROVIDER, newSettings.provider.name)
            .putString(KEY_BASE_URL, newSettings.baseUrl.trim())
            .putString(KEY_API_KEY, newSettings.apiKey.trim())
            .putString(KEY_MODEL, newSettings.model.trim())
            .putString(KEY_SYSTEM_PROMPT, newSettings.systemPrompt.trim())
            .putFloat(KEY_TEMPERATURE, newSettings.temperature)
            .putString(KEY_CACHED_MODELS, jsonArray.toString())
            .apply()

        _settingsFlow.value = newSettings
    }

    fun updateCachedModels(models: List<String>) {
        val current = _settingsFlow.value
        val updated = current.copy(cachedModels = models)
        updateSettings(updated)
    }

    private fun loadSettings(): ApiSettings {
        val providerName = prefs.getString(KEY_PROVIDER, ApiProvider.OPENAI.name) ?: ApiProvider.OPENAI.name
        val provider = try {
            ApiProvider.valueOf(providerName)
        } catch (_: Exception) {
            ApiProvider.OPENAI
        }

        val baseUrl = prefs.getString(KEY_BASE_URL, provider.defaultBaseUrl) ?: provider.defaultBaseUrl
        val apiKey = prefs.getString(KEY_API_KEY, "") ?: ""
        val model = prefs.getString(KEY_MODEL, provider.defaultModel) ?: provider.defaultModel
        val systemPrompt = prefs.getString(KEY_SYSTEM_PROMPT, DEFAULT_SYSTEM_PROMPT) ?: DEFAULT_SYSTEM_PROMPT
        val temperature = prefs.getFloat(KEY_TEMPERATURE, 0.7f)

        val cachedModelsList = mutableListOf<String>()
        val cachedModelsJson = prefs.getString(KEY_CACHED_MODELS, null)
        if (!cachedModelsJson.isNullOrBlank()) {
            try {
                val array = JSONArray(cachedModelsJson)
                for (i in 0 until array.length()) {
                    cachedModelsList.add(array.getString(i))
                }
            } catch (_: Exception) {
            }
        }

        return ApiSettings(
            provider = provider,
            baseUrl = baseUrl,
            apiKey = apiKey,
            model = model,
            systemPrompt = systemPrompt,
            temperature = temperature,
            cachedModels = cachedModelsList
        )
    }

    companion object {
        private const val KEY_PROVIDER = "key_provider"
        private const val KEY_BASE_URL = "key_base_url"
        private const val KEY_API_KEY = "key_api_key"
        private const val KEY_MODEL = "key_model"
        private const val KEY_SYSTEM_PROMPT = "key_system_prompt"
        private const val KEY_TEMPERATURE = "key_temperature"
        private const val KEY_CACHED_MODELS = "key_cached_models"

        @Volatile
        private var INSTANCE: ApiPreferences? = null

        fun getInstance(context: Context): ApiPreferences {
            return INSTANCE ?: synchronized(this) {
                val instance = ApiPreferences(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
