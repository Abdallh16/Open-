package com.example.data.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

data class ApiMessage(
    val role: String,
    val content: String
)

data class ConnectionTestResult(
    val isSuccess: Boolean,
    val latencyMs: Long,
    val message: String,
    val model: String,
    val availableModels: List<String> = emptyList()
)

class NexusApiClient {
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private fun cleanBaseUrl(url: String): String {
        var clean = url.trim()
        if (clean.endsWith("/")) {
            clean = clean.dropLast(1)
        }
        if (clean.endsWith("/chat/completions")) {
            clean = clean.removeSuffix("/chat/completions")
        }
        if (clean.endsWith("/models")) {
            clean = clean.removeSuffix("/models")
        }
        return clean
    }

    private fun formatChatEndpoint(baseUrl: String): String {
        val base = cleanBaseUrl(baseUrl)
        return "$base/chat/completions"
    }

    private fun formatModelsEndpoint(baseUrl: String): String {
        val base = cleanBaseUrl(baseUrl)
        return "$base/models"
    }

    /**
     * Real HTTP GET request to /models to fetch live model IDs for the provided key and baseUrl.
     */
    suspend fun fetchAvailableModels(
        baseUrl: String,
        apiKey: String
    ): Result<List<String>> = withContext(Dispatchers.IO) {
        try {
            val endpoint = formatModelsEndpoint(baseUrl)
            val requestBuilder = Request.Builder()
                .url(endpoint)
                .get()

            if (apiKey.isNotBlank()) {
                requestBuilder.header("Authorization", "Bearer ${apiKey.trim()}")
            }

            val response = client.newCall(requestBuilder.build()).execute()
            val responseBody = response.body?.string().orEmpty()

            if (response.isSuccessful) {
                val modelList = mutableListOf<String>()
                val json = JSONObject(responseBody)

                val dataArray = json.optJSONArray("data") ?: json.optJSONArray("models")
                if (dataArray != null) {
                    for (i in 0 until dataArray.length()) {
                        val item = dataArray.optJSONObject(i)
                        val id = item?.optString("id")?.takeIf { it.isNotBlank() }
                            ?: item?.optString("name")
                        if (!id.isNullOrBlank()) {
                            modelList.add(id.trim())
                        }
                    }
                }

                // If empty or different schema, try direct object keys
                if (modelList.isEmpty()) {
                    val keys = json.keys()
                    while (keys.hasNext()) {
                        val k = keys.next()
                        val v = json.opt(k)
                        if (v is JSONArray) {
                            for (i in 0 until v.length()) {
                                val item = v.optJSONObject(i)
                                val id = item?.optString("id")
                                if (!id.isNullOrBlank()) modelList.add(id.trim())
                            }
                        }
                    }
                }

                val sorted = modelList.distinct().sorted()
                if (sorted.isNotEmpty()) {
                    Result.success(sorted)
                } else {
                    Result.failure(IOException("استجاب الخادم بنجاح ولكن لم يتم العثور على نماذج في الاستجابة."))
                }
            } else {
                val errorMsg = parseErrorMessage(response.code, responseBody)
                Result.failure(IOException(errorMsg))
            }
        } catch (e: UnknownHostException) {
            Result.failure(IOException("تعذر الاتصال بالخادم. تحقق من صحة الرابط واتصال الإنترنت."))
        } catch (e: SocketTimeoutException) {
            Result.failure(IOException("انتهت مهلة الانتظار أثناء جلب النماذج من الخادم."))
        } catch (e: Exception) {
            Result.failure(IOException(e.localizedMessage ?: "حدث خطأ أثناء فحص النماذج."))
        }
    }

    suspend fun testConnection(
        baseUrl: String,
        apiKey: String,
        model: String
    ): ConnectionTestResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        try {
            var discoveredModels = emptyList<String>()
            val modelsResult = fetchAvailableModels(baseUrl, apiKey)
            if (modelsResult.isSuccess) {
                discoveredModels = modelsResult.getOrDefault(emptyList())
                val latency = System.currentTimeMillis() - startTime
                return@withContext ConnectionTestResult(
                    isSuccess = true,
                    latencyMs = latency,
                    message = "تم الاتصال بالخادم والتحقق بنجاح خلال $latency م/ث (تم العثور على ${discoveredModels.size} نموذج)",
                    model = model.ifBlank { discoveredModels.firstOrNull() ?: "gpt-4o-mini" },
                    availableModels = discoveredModels
                )
            }

            // Perform a quick chat completion test
            val endpoint = formatChatEndpoint(baseUrl)
            val effectiveModel = if (model.isNotBlank()) model.trim() else discoveredModels.firstOrNull() ?: "gpt-4o-mini"
            val jsonBody = JSONObject().apply {
                put("model", effectiveModel)
                put("messages", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", "ping")
                    })
                })
                put("max_tokens", 5)
            }

            val requestBuilder = Request.Builder()
                .url(endpoint)
                .post(jsonBody.toString().toRequestBody(jsonMediaType))

            if (apiKey.isNotBlank()) {
                requestBuilder.header("Authorization", "Bearer ${apiKey.trim()}")
            }

            val response = client.newCall(requestBuilder.build()).execute()
            val latency = System.currentTimeMillis() - startTime
            val responseBody = response.body?.string().orEmpty()

            if (response.isSuccessful) {
                val modelsCountStr = if (discoveredModels.isNotEmpty()) " (تم العثور على ${discoveredModels.size} نموذج)" else ""
                ConnectionTestResult(
                    isSuccess = true,
                    latencyMs = latency,
                    message = "تم الاتصال بالخادم والتحقق بنجاح خلال $latency م/ث$modelsCountStr",
                    model = effectiveModel,
                    availableModels = discoveredModels
                )
            } else {
                val errorMsg = parseErrorMessage(response.code, responseBody)
                ConnectionTestResult(
                    isSuccess = false,
                    latencyMs = latency,
                    message = errorMsg,
                    model = effectiveModel,
                    availableModels = discoveredModels
                )
            }
        } catch (e: UnknownHostException) {
            ConnectionTestResult(
                isSuccess = false,
                latencyMs = System.currentTimeMillis() - startTime,
                message = "تعذر الوصول إلى الخادم. يرجى التأكد من كتابة عنوان الرابط بشكل صحيح والاتصال بالإنترنت.",
                model = model
            )
        } catch (e: SocketTimeoutException) {
            ConnectionTestResult(
                isSuccess = false,
                latencyMs = System.currentTimeMillis() - startTime,
                message = "انتهت مهلة الانتظار أثناء الاتصال بالخادم (Timeout).",
                model = model
            )
        } catch (e: Exception) {
            ConnectionTestResult(
                isSuccess = false,
                latencyMs = System.currentTimeMillis() - startTime,
                message = e.localizedMessage ?: "حدث خطأ غير معروف في الاتصال.",
                model = model
            )
        }
    }

    suspend fun sendChatMessage(
        baseUrl: String,
        apiKey: String,
        model: String,
        messages: List<ApiMessage>,
        systemPrompt: String = "",
        temperature: Float = 0.7f
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val endpoint = formatChatEndpoint(baseUrl)
            val jsonMessages = JSONArray()

            if (systemPrompt.isNotBlank()) {
                jsonMessages.put(JSONObject().apply {
                    put("role", "system")
                    put("content", systemPrompt.trim())
                })
            }

            for (msg in messages) {
                jsonMessages.put(JSONObject().apply {
                    put("role", msg.role)
                    put("content", msg.content)
                })
            }

            val jsonBody = JSONObject().apply {
                put("model", model.trim())
                put("messages", jsonMessages)
                put("temperature", temperature.toDouble())
            }

            val requestBuilder = Request.Builder()
                .url(endpoint)
                .post(jsonBody.toString().toRequestBody(jsonMediaType))

            if (apiKey.isNotBlank()) {
                requestBuilder.header("Authorization", "Bearer ${apiKey.trim()}")
            }

            val response = client.newCall(requestBuilder.build()).execute()
            val responseBody = response.body?.string().orEmpty()

            if (response.isSuccessful) {
                val jsonResponse = JSONObject(responseBody)
                val choices = jsonResponse.optJSONArray("choices")
                if (choices != null && choices.length() > 0) {
                    val firstChoice = choices.getJSONObject(0)
                    val messageObj = firstChoice.optJSONObject("message")
                    val content = messageObj?.optString("content") ?: ""
                    Result.success(content)
                } else {
                    Result.failure(IOException("لم يُرجع الخادم أي نص إجابة."))
                }
            } else {
                val errorMsg = parseErrorMessage(response.code, responseBody)
                Result.failure(IOException(errorMsg))
            }
        } catch (e: UnknownHostException) {
            Result.failure(IOException("تعذر الاتصال بالخادم، تحقق من اتصال الإنترنت وعنوان الرابط."))
        } catch (e: SocketTimeoutException) {
            Result.failure(IOException("استغرق الخادم وقتاً أطول من المعتاد (انتهت المهلة)."))
        } catch (e: Exception) {
            Result.failure(IOException(e.localizedMessage ?: "حدث خطأ غير متوقع أثناء معالجة الطلب."))
        }
    }

    private fun parseErrorMessage(statusCode: Int, responseBody: String): String {
        var parsedDetail = ""
        try {
            if (responseBody.isNotBlank()) {
                val json = JSONObject(responseBody)
                if (json.has("error")) {
                    val err = json.get("error")
                    if (err is JSONObject) {
                        parsedDetail = err.optString("message", "")
                    } else if (err is String) {
                        parsedDetail = err
                    }
                } else if (json.has("message")) {
                    parsedDetail = json.optString("message", "")
                }
            }
        } catch (_: Exception) {
            // ignore fallback
        }

        val baseExplanation = when (statusCode) {
            401 -> "رمز 401: مفتاح API غير صالح أو غير مصرح به. تحقق من صحة المفتاح."
            403 -> "رمز 403: تم رفض الوصول. قد تكون هناك قيود على الحساب أو المنطقة الجغرافية."
            404 -> "رمز 404: المسار غير موجود. تحقق من عنوان الرابط الأساسي (Base URL)."
            429 -> "رمز 429: تم تجاوز معدل الطلبات المسموح أو استنفاد رصيد الحساب."
            500, 502, 503 -> "رمز $statusCode: مشكلة في خادم مزود الخدمة، يرجى المحاولة لاحقاً."
            else -> "فشل الطلب برمز الحالة ($statusCode)."
        }

        return if (parsedDetail.isNotBlank()) {
            "$baseExplanation\nالتفاصيل: $parsedDetail"
        } else {
            baseExplanation
        }
    }
}
