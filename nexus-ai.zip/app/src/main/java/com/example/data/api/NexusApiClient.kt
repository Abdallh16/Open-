package com.example.data.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.TimeUnit

data class ApiMessage(
    val role: String,
    val content: String
)

data class ConnectionTestResult(
    val isSuccess: Boolean,
    val latencyMs: Long,
    val message: String,
    val model: String
)

class NexusApiClient {
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    private fun formatEndpoint(baseUrl: String): String {
        var clean = baseUrl.trim()
        if (clean.endsWith("/")) {
            clean = clean.dropLast(1)
        }
        return if (clean.endsWith("/chat/completions")) {
            clean
        } else {
            "$clean/chat/completions"
        }
    }

    suspend fun testConnection(
        baseUrl: String,
        apiKey: String,
        model: String
    ): ConnectionTestResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        try {
            val endpoint = formatEndpoint(baseUrl)
            val jsonBody = JSONObject().apply {
                put("model", model.trim())
                put("messages", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("content", "ping")
                    })
                })
                put("max_tokens", 5)
            }

            val requestBuilder = Request.Builder()
                .url(endpoint)
                .post(jsonBody.toString().toRequestBody(jsonMediaType))

            if (apiKey.isNotBlank()) {
                requestBuilder.header("Authorization", "Bearer ${apiKey.trim()}")
            }

            val response = client.newCall(requestBuilder.build()).execute()
            val latency = System.currentTimeMillis() - startTime
            val responseBody = response.body?.string().orEmpty()

            if (response.isSuccessful) {
                ConnectionTestResult(
                    isSuccess = true,
                    latencyMs = latency,
                    message = "تم الاتصال بالخادم واستجابة النموذج بنجاح ($latency ملي ثانية)",
                    model = model
                )
            } else {
                val errorMsg = parseErrorMessage(response.code, responseBody)
                ConnectionTestResult(
                    isSuccess = false,
                    latencyMs = latency,
                    message = errorMsg,
                    model = model
                )
            }
        } catch (e: UnknownHostException) {
            ConnectionTestResult(
                isSuccess = false,
                latencyMs = System.currentTimeMillis() - startTime,
                message = "تعذر الوصول إلى الخادم، يرجى التأكد من كتابة عنوان الرابط بشكل صحيح والاتصال بالإنترنت.",
                model = model
            )
        } catch (e: SocketTimeoutException) {
            ConnectionTestResult(
                isSuccess = false,
                latencyMs = System.currentTimeMillis() - startTime,
                message = "انتهت مهلة الانتظار أثناء الاتصال بالخادم (Timeout).",
                model = model
            )
        } catch (e: Exception) {
            ConnectionTestResult(
                isSuccess = false,
                latencyMs = System.currentTimeMillis() - startTime,
                message = e.localizedMessage ?: "حدث خطأ غير معروف في الاتصال.",
                model = model
            )
        }
    }

    suspend fun sendChatMessage(
        baseUrl: String,
        apiKey: String,
        model: String,
        messages: List<ApiMessage>,
        systemPrompt: String = "",
        temperature: Float = 0.7f
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val endpoint = formatEndpoint(baseUrl)
            val jsonMessages = JSONArray()

            if (systemPrompt.isNotBlank()) {
                jsonMessages.put(JSONObject().apply {
                    put("role", "system")
                    put("content", systemPrompt.trim())
                })
            }

            for (msg in messages) {
                jsonMessages.put(JSONObject().apply {
                    put("role", msg.role)
                    put("content", msg.content)
                })
            }

            val jsonBody = JSONObject().apply {
                put("model", model.trim())
                put("messages", jsonMessages)
                put("temperature", temperature.toDouble())
            }

            val requestBuilder = Request.Builder()
                .url(endpoint)
                .post(jsonBody.toString().toRequestBody(jsonMediaType))

            if (apiKey.isNotBlank()) {
                requestBuilder.header("Authorization", "Bearer ${apiKey.trim()}")
            }

            val response = client.newCall(requestBuilder.build()).execute()
            val responseBody = response.body?.string().orEmpty()

            if (response.isSuccessful) {
                val jsonResponse = JSONObject(responseBody)
                val choices = jsonResponse.optJSONArray("choices")
                if (choices != null && choices.length() > 0) {
                    val firstChoice = choices.getJSONObject(0)
                    val messageObj = firstChoice.optJSONObject("message")
                    val content = messageObj?.optString("content") ?: ""
                    Result.success(content)
                } else {
                    Result.failure(IOException("لم يُرجع الخادم أي رد في مصفوفة choices."))
                }
            } else {
                val errorMsg = parseErrorMessage(response.code, responseBody)
                Result.failure(IOException(errorMsg))
            }
        } catch (e: UnknownHostException) {
            Result.failure(IOException("تعذر الاتصال بالخادم، يرجى التأكد من اتصال الإنترنت وصحة رابط الـ API."))
        } catch (e: SocketTimeoutException) {
            Result.failure(IOException("استغرق الخادم وقتاً أطول من المعتاد للرد (انتهت مهلة الانتظار)."))
        } catch (e: Exception) {
            Result.failure(IOException(e.localizedMessage ?: "حدث خطأ غير متوقع أثناء معالجة الطلب."))
        }
    }

    private fun parseErrorMessage(statusCode: Int, responseBody: String): String {
        var parsedDetail = ""
        try {
            if (responseBody.isNotBlank()) {
                val json = JSONObject(responseBody)
                if (json.has("error")) {
                    val err = json.get("error")
                    if (err is JSONObject) {
                        parsedDetail = err.optString("message", "")
                    } else if (err is String) {
                        parsedDetail = err
                    }
                } else if (json.has("message")) {
                    parsedDetail = json.optString("message", "")
                }
            }
        } catch (_: Exception) {
            // ignore json parsing fallback
        }

        val baseExplanation = when (statusCode) {
            401 -> "رمز الخطأ 401: مفتاح API غير صالح أو غير مصرح به. يرجى مراجعة المفتاح في الإعدادات."
            403 -> "رمز الخطأ 403: تم رفض الوصول. قد تكون هناك قيود على الحساب أو المنطقة الجغرافية."
            404 -> "رمز الخطأ 404: الرابط غير موجود. يرجى التحقق من عنوان Base URL ومسار /chat/completions."
            429 -> "رمز الخطأ 429: تم استنفاد رصيد الحساب أو تم تجاوز معدل الطلبات المسموح (Rate Limit)."
            500, 502, 503 -> "رمز الخطأ $statusCode: مشكلة في خوادم مزود الخدمة، يرجى المحاولة بعد قليل."
            else -> "فشل الطلب برمز الحالة ($statusCode)."
        }

        return if (parsedDetail.isNotBlank()) {
            "$baseExplanation\nالتفاصيل: $parsedDetail"
        } else {
            baseExplanation
        }
    }
}
