package com.example.util

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object DateFormatter {
    private val arabicLocale = Locale("ar")

    fun formatMessageTime(timestamp: Long): String {
        val sdf = SimpleDateFormat("h:mm a", arabicLocale)
        return sdf.format(Date(timestamp))
    }

    fun formatConversationDate(timestamp: Long): String {
        val now = Calendar.getInstance()
        val timeCal = Calendar.getInstance().apply { timeInMillis = timestamp }

        val isToday = now.get(Calendar.YEAR) == timeCal.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) == timeCal.get(Calendar.DAY_OF_YEAR)

        val isYesterday = now.get(Calendar.YEAR) == timeCal.get(Calendar.YEAR) &&
                now.get(Calendar.DAY_OF_YEAR) - timeCal.get(Calendar.DAY_OF_YEAR) == 1

        val timeStr = SimpleDateFormat("h:mm a", arabicLocale).format(Date(timestamp))

        return when {
            isToday -> "اليوم، $timeStr"
            isYesterday -> "أمس، $timeStr"
            else -> {
                val dateStr = SimpleDateFormat("d MMMM", arabicLocale).format(Date(timestamp))
                "$dateStr، $timeStr"
            }
        }
    }
}
