package com.example.data.mcp

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class McpPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("nexus_ai_mcp_prefs", Context.MODE_PRIVATE)

    private val _configsFlow = MutableStateFlow(loadAllConfigs())
    val configsFlow: StateFlow<Map<McpIntegrationType, McpServiceConfig>> = _configsFlow.asStateFlow()

    fun getAllConfigs(): Map<McpIntegrationType, McpServiceConfig> = _configsFlow.value

    fun getConfig(type: McpIntegrationType): McpServiceConfig {
        return _configsFlow.value[type] ?: defaultFor(type)
    }

    fun updateConfig(config: McpServiceConfig) {
        val scopesArray = JSONArray(config.scopes)
        val json = JSONObject().apply {
            put("isEnabled", config.isEnabled)
            put("oauthStatus", config.oauthStatus.name)
            put("accountName", config.accountName.trim())
            put("accountEmail", config.accountEmail.trim())
            put("token", config.token.trim())
            put("endpoint", config.endpoint.trim())
            put("clientId", config.clientId.trim())
            put("clientSecret", config.clientSecret.trim())
            put("extraParam", config.extraParam.trim())
            put("scopes", scopesArray)
            put("lastConnectedTime", config.lastConnectedTime)
            if (config.lastTestedSuccess != null) {
                put("lastTestedSuccess", config.lastTestedSuccess)
            }
            if (config.lastStatusMessage != null) {
                put("lastStatusMessage", config.lastStatusMessage)
            }
        }
        prefs.edit().putString(KEY_PREFIX + config.type.name, json.toString()).apply()

        val updatedMap = _configsFlow.value.toMutableMap()
        updatedMap[config.type] = config
        _configsFlow.value = updatedMap
    }

    fun updateOAuthSuccess(
        type: McpIntegrationType,
        accountName: String,
        accountEmail: String,
        token: String
    ) {
        val current = getConfig(type)
        val updated = current.copy(
            isEnabled = true,
            oauthStatus = OAuthStatus.CONNECTED,
            accountName = accountName,
            accountEmail = accountEmail,
            token = token,
            lastConnectedTime = System.currentTimeMillis(),
            lastTestedSuccess = true,
            lastStatusMessage = "متصل بنجاح بالحساب: $accountName"
        )
        updateConfig(updated)
    }

    fun disconnectOAuth(type: McpIntegrationType) {
        val current = getConfig(type)
        val updated = current.copy(
            isEnabled = false,
            oauthStatus = OAuthStatus.DISCONNECTED,
            accountName = "",
            accountEmail = "",
            token = "",
            lastTestedSuccess = null,
            lastStatusMessage = null
        )
        updateConfig(updated)
    }

    fun updateTestResult(type: McpIntegrationType, success: Boolean, message: String) {
        val current = getConfig(type)
        val updated = current.copy(
            lastTestedSuccess = success,
            lastStatusMessage = message
        )
        updateConfig(updated)
    }

    private fun loadAllConfigs(): Map<McpIntegrationType, McpServiceConfig> {
        val map = mutableMapOf<McpIntegrationType, McpServiceConfig>()
        for (type in McpIntegrationType.entries) {
            val rawJson = prefs.getString(KEY_PREFIX + type.name, null)
            if (rawJson != null) {
                try {
                    val obj = JSONObject(rawJson)
                    val statusName = obj.optString("oauthStatus", OAuthStatus.DISCONNECTED.name)
                    val oauthStatus = try {
                        OAuthStatus.valueOf(statusName)
                    } catch (_: Exception) {
                        OAuthStatus.DISCONNECTED
                    }
                    val scopesList = mutableListOf<String>()
                    val scopesArr = obj.optJSONArray("scopes")
                    if (scopesArr != null) {
                        for (i in 0 until scopesArr.length()) {
                            scopesList.add(scopesArr.getString(i))
                        }
                    }

                    map[type] = McpServiceConfig(
                        type = type,
                        isEnabled = obj.optBoolean("isEnabled", type == McpIntegrationType.WEB_SEARCH),
                        oauthStatus = oauthStatus,
                        accountName = obj.optString("accountName", ""),
                        accountEmail = obj.optString("accountEmail", ""),
                        token = obj.optString("token", ""),
                        endpoint = obj.optString("endpoint", type.defaultEndpoint),
                        clientId = obj.optString("clientId", ""),
                        clientSecret = obj.optString("clientSecret", ""),
                        extraParam = obj.optString("extraParam", ""),
                        scopes = if (scopesList.isNotEmpty()) scopesList else type.defaultScopes,
                        lastConnectedTime = obj.optLong("lastConnectedTime", 0L),
                        lastTestedSuccess = if (obj.has("lastTestedSuccess")) obj.optBoolean("lastTestedSuccess") else null,
                        lastStatusMessage = if (obj.has("lastStatusMessage")) obj.optString("lastStatusMessage") else null
                    )
                } catch (_: Exception) {
                    map[type] = defaultFor(type)
                }
            } else {
                map[type] = defaultFor(type)
            }
        }
        return map
    }

    private fun defaultFor(type: McpIntegrationType): McpServiceConfig {
        return McpServiceConfig(
            type = type,
            isEnabled = type == McpIntegrationType.WEB_SEARCH,
            oauthStatus = if (type == McpIntegrationType.WEB_SEARCH) OAuthStatus.CONNECTED else OAuthStatus.DISCONNECTED,
            accountName = if (type == McpIntegrationType.WEB_SEARCH) "Live Internet Engine" else "",
            accountEmail = "",
            token = "",
            endpoint = type.defaultEndpoint,
            scopes = type.defaultScopes
        )
    }

    companion object {
        private const val KEY_PREFIX = "mcp_service_"

        @Volatile
        private var INSTANCE: McpPreferences? = null

        fun getInstance(context: Context): McpPreferences {
            return INSTANCE ?: synchronized(this) {
                val instance = McpPreferences(context.applicationContext)
                INSTANCE = instance
                instance
            }
        }
    }
}
