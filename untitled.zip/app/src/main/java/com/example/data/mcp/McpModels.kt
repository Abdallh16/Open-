package com.example.data.mcp

enum class OAuthStatus {
    DISCONNECTED,
    CONNECTING,
    CONNECTED
}

/**
 * Supported MCP integrations and third-party tools
 */
enum class McpIntegrationType(
    val id: String,
    val displayNameArabic: String,
    val descriptionArabic: String,
    val categoryArabic: String,
    val defaultEndpoint: String,
    val serviceProviderArabic: String,
    val defaultScopes: List<String>
) {
    NOTION(
        id = "notion",
        displayNameArabic = "Notion",
        descriptionArabic = "الربط بمساحة العمل للبحث في الملاحظات والصفحات وقواعد البيانات وتعديلها",
        categoryArabic = "المستندات وقواعد البيانات",
        defaultEndpoint = "https://api.notion.com/v1",
        serviceProviderArabic = "Notion Labs Inc.",
        defaultScopes = listOf("read:pages", "write:pages", "read:databases", "read:user")
    ),
    CANVA(
        id = "canva",
        displayNameArabic = "Canva",
        descriptionArabic = "الاتصال بحساب Canva لإنشاء وتوليد قوالب التصاميم والمنشورات والعروض",
        categoryArabic = "التصميم والجرافيك",
        defaultEndpoint = "https://api.canva.com/v1",
        serviceProviderArabic = "Canva Pty Ltd.",
        defaultScopes = listOf("design:content:read", "design:content:write", "asset:read", "profile:read")
    ),
    ADOBE(
        id = "adobe",
        displayNameArabic = "Adobe Creative Cloud",
        descriptionArabic = "ربط حساب Adobe للوصول إلى مكتبات الأصول، Photoshop، وتوليد موجهات Firefly",
        categoryArabic = "التصميم الرقمي والأصول",
        defaultEndpoint = "https://stock.adobe.io/Rest/Media/1",
        serviceProviderArabic = "Adobe Inc.",
        defaultScopes = listOf("creative_cloud", "stock:read", "firefly:generate")
    ),
    GITHUB(
        id = "github",
        displayNameArabic = "GitHub",
        descriptionArabic = "ربط حساب GitHub لتصفح المستودعات، قراءة الأكواد، ومتابعة قضايا البرمجة",
        categoryArabic = "المطورين والمستودعات",
        defaultEndpoint = "https://api.github.com",
        serviceProviderArabic = "GitHub / Microsoft",
        defaultScopes = listOf("repo", "read:user", "read:org")
    ),
    WEB_SEARCH(
        id = "web_search",
        displayNameArabic = "محرك الويب و Curl المباشر",
        descriptionArabic = "اتصال حي بالإنترنت للبحث الفعلي عن المعلومات وجلب محتوى الروابط والصفحات عبر curl",
        categoryArabic = "الإنترنت والشبكة",
        defaultEndpoint = "https://html.duckduckgo.com/html",
        serviceProviderArabic = "Nexus Live Web Engine",
        defaultScopes = listOf("web:search", "http:fetch")
    ),
    CUSTOM_MCP(
        id = "custom_mcp",
        displayNameArabic = "خادم MCP التلقائي (Auto-Discovery)",
        descriptionArabic = "اكتشاف وتوصيل تلقائي لأي خادم MCP محلي أو سحابي عبر بروتوكول JSON-RPC 2.0",
        categoryArabic = "بروتوكول MCP المفتوح",
        defaultEndpoint = "http://10.0.2.2:8000/mcp",
        serviceProviderArabic = "Anthropic / Model Context Protocol",
        defaultScopes = listOf("mcp:tools:call", "mcp:resources:read", "mcp:prompts:get")
    )
}

/**
 * Configuration state for an individual MCP / OAuth service
 */
data class McpServiceConfig(
    val type: McpIntegrationType,
    val isEnabled: Boolean = false,
    val oauthStatus: OAuthStatus = OAuthStatus.DISCONNECTED,
    val accountName: String = "",
    val accountEmail: String = "",
    val token: String = "",
    val endpoint: String = type.defaultEndpoint,
    val clientId: String = "",
    val clientSecret: String = "",
    val extraParam: String = "",
    val scopes: List<String> = type.defaultScopes,
    val lastConnectedTime: Long = 0L,
    val lastTestedSuccess: Boolean? = null,
    val lastStatusMessage: String? = null
)

/**
 * Definition of an individual tool that the AI agent can call
 */
data class McpToolDefinition(
    val id: String,
    val serviceType: McpIntegrationType,
    val nameArabic: String,
    val descriptionArabic: String,
    val exampleUsage: String
)

/**
 * Result of a tool call
 */
data class ToolCallResult(
    val toolId: String,
    val toolName: String,
    val serviceType: McpIntegrationType,
    val isSuccess: Boolean,
    val outputText: String,
    val rawJson: String = "",
    val latencyMs: Long = 0,
    val sourceUrl: String? = null
)

/**
 * In-chat tool call representation
 */
data class ChatToolInvocation(
    val toolId: String,
    val toolName: String,
    val serviceType: McpIntegrationType,
    val parameters: Map<String, String>,
    val isExecuting: Boolean = false,
    val result: ToolCallResult? = null
)
