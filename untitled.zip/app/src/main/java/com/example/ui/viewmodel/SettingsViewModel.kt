package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.ConnectionTestResult
import com.example.data.api.NexusApiClient
import com.example.data.local.NexusDatabase
import com.example.data.mcp.McpIntegrationType
import com.example.data.mcp.McpPreferences
import com.example.data.mcp.McpServiceConfig
import com.example.data.mcp.McpToolDefinition
import com.example.data.mcp.McpToolExecutor
import com.example.data.mcp.OAuthStatus
import com.example.data.preferences.ApiPreferences
import com.example.data.preferences.ApiProvider
import com.example.data.preferences.ApiSettings
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class SettingsSection {
    HUB,
    MODELS_AND_PROVIDERS,
    MCP_INTEGRATIONS,
    DATA_MANAGEMENT
}

sealed class TestConnectionState {
    object Idle : TestConnectionState()
    object Testing : TestConnectionState()
    data class Success(val latencyMs: Long, val message: String, val modelsCount: Int) : TestConnectionState()
    data class Error(val message: String) : TestConnectionState()
}

class SettingsViewModel(application: Application) : AndroidViewModel(application) {
    private val apiPreferences = ApiPreferences.getInstance(application)
    private val mcpPreferences = McpPreferences.getInstance(application)
    private val mcpToolExecutor = McpToolExecutor(application)
    private val db = NexusDatabase.getInstance(application)
    private val apiClient = NexusApiClient()

    // Navigation section state
    private val _currentSection = MutableStateFlow(SettingsSection.HUB)
    val currentSection: StateFlow<SettingsSection> = _currentSection.asStateFlow()

    // AI Provider & Model State
    private val _provider = MutableStateFlow(ApiProvider.OPENAI)
    val provider: StateFlow<ApiProvider> = _provider.asStateFlow()

    private val _baseUrl = MutableStateFlow("")
    val baseUrl: StateFlow<String> = _baseUrl.asStateFlow()

    private val _apiKey = MutableStateFlow("")
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    private val _model = MutableStateFlow("")
    val model: StateFlow<String> = _model.asStateFlow()

    private val _systemPrompt = MutableStateFlow("")
    val systemPrompt: StateFlow<String> = _systemPrompt.asStateFlow()

    private val _temperature = MutableStateFlow(0.7f)
    val temperature: StateFlow<Float> = _temperature.asStateFlow()

    private val _availableModels = MutableStateFlow<List<String>>(emptyList())
    val availableModels: StateFlow<List<String>> = _availableModels.asStateFlow()

    private val _isFetchingModels = MutableStateFlow(false)
    val isFetchingModels: StateFlow<Boolean> = _isFetchingModels.asStateFlow()

    private val _testState = MutableStateFlow<TestConnectionState>(TestConnectionState.Idle)
    val testState: StateFlow<TestConnectionState> = _testState.asStateFlow()

    private val _statusNotification = MutableStateFlow<String?>(null)
    val statusNotification: StateFlow<String?> = _statusNotification.asStateFlow()

    // MCP Integrations State
    val mcpConfigs: StateFlow<Map<McpIntegrationType, McpServiceConfig>> = mcpPreferences.configsFlow
    val availableMcpTools: List<McpToolDefinition> = mcpToolExecutor.availableTools

    private val _verifyingMcpType = MutableStateFlow<McpIntegrationType?>(null)
    val verifyingMcpType: StateFlow<McpIntegrationType?> = _verifyingMcpType.asStateFlow()

    init {
        loadSettings()
    }

    fun setSection(section: SettingsSection) {
        _currentSection.value = section
    }

    fun navigateBack(): Boolean {
        return if (_currentSection.value != SettingsSection.HUB) {
            _currentSection.value = SettingsSection.HUB
            true
        } else {
            false
        }
    }

    private fun loadSettings() {
        val s = apiPreferences.getSettings()
        _provider.value = s.provider
        _baseUrl.value = s.baseUrl
        _apiKey.value = s.apiKey
        _model.value = s.model
        _systemPrompt.value = s.systemPrompt
        _temperature.value = s.temperature
        _availableModels.value = s.cachedModels.ifEmpty { s.provider.recommendedModels }
    }

    fun selectProvider(newProvider: ApiProvider) {
        _provider.value = newProvider
        _baseUrl.value = newProvider.defaultBaseUrl
        _model.value = newProvider.defaultModel
        _availableModels.value = newProvider.recommendedModels
        _testState.value = TestConnectionState.Idle
    }

    fun setBaseUrl(url: String) {
        _baseUrl.value = url
        _testState.value = TestConnectionState.Idle
    }

    fun setApiKey(key: String) {
        _apiKey.value = key
        _testState.value = TestConnectionState.Idle
    }

    fun setModel(m: String) {
        _model.value = m
    }

    fun setSystemPrompt(prompt: String) {
        _systemPrompt.value = prompt
    }

    fun setTemperature(temp: Float) {
        _temperature.value = temp
    }

    fun fetchModelsLive() {
        val currentUrl = _baseUrl.value.trim()
        val currentKey = _apiKey.value.trim()

        if (currentUrl.isBlank()) {
            _testState.value = TestConnectionState.Error("يرجى إدخال عنوان خادم الـ API (Base URL)")
            return
        }

        _isFetchingModels.value = true
        _testState.value = TestConnectionState.Testing

        viewModelScope.launch {
            val result = apiClient.fetchAvailableModels(currentUrl, currentKey)
            _isFetchingModels.value = false

            result.onSuccess { models ->
                _availableModels.value = models
                apiPreferences.updateCachedModels(models)
                if (models.isNotEmpty() && (_model.value.isBlank() || !models.contains(_model.value))) {
                    _model.value = models.first()
                }
                _testState.value = TestConnectionState.Success(
                    latencyMs = 0,
                    message = "تم الاتصال بنجاح وجلب ${models.size} نموذج متوفر للخادم!",
                    modelsCount = models.size
                )
                _statusNotification.value = "تم جلب ${models.size} نموذج بنجاح"
            }.onFailure { err ->
                val errorMsg = err.localizedMessage ?: "تعذر جلب النماذج من الخادم."
                _testState.value = TestConnectionState.Error(errorMsg)
            }
        }
    }

    fun saveSettings() {
        val newSettings = ApiSettings(
            provider = _provider.value,
            baseUrl = _baseUrl.value.trim(),
            apiKey = _apiKey.value.trim(),
            model = _model.value.trim(),
            systemPrompt = _systemPrompt.value.trim(),
            temperature = _temperature.value,
            cachedModels = _availableModels.value
        )
        apiPreferences.updateSettings(newSettings)
        _statusNotification.value = "تم حفظ الإعدادات بنجاح"
    }

    fun clearNotification() {
        _statusNotification.value = null
    }

    fun testConnection() {
        val currentUrl = _baseUrl.value.trim()
        val currentKey = _apiKey.value.trim()
        val currentModel = _model.value.trim()

        if (currentUrl.isBlank()) {
            _testState.value = TestConnectionState.Error("يرجى إدخال عنوان خادم الـ API (Base URL)")
            return
        }

        _testState.value = TestConnectionState.Testing

        viewModelScope.launch {
            val result: ConnectionTestResult = apiClient.testConnection(
                baseUrl = currentUrl,
                apiKey = currentKey,
                model = currentModel
            )

            if (result.isSuccess) {
                if (result.availableModels.isNotEmpty()) {
                    _availableModels.value = result.availableModels
                    apiPreferences.updateCachedModels(result.availableModels)
                }
                _testState.value = TestConnectionState.Success(
                    result.latencyMs,
                    result.message,
                    result.availableModels.size
                )
            } else {
                _testState.value = TestConnectionState.Error(result.message)
            }
        }
    }

    // ========================================================
    // Real OAuth & MCP Integration with Browser Authorization
    // ========================================================

    fun openOAuthInBrowser(type: McpIntegrationType, clientId: String = ""): String {
        return mcpToolExecutor.openOAuthInBrowser(type, clientId)
    }

    fun verifyAndConnectOAuth(
        type: McpIntegrationType,
        token: String,
        customEndpoint: String = "",
        onResult: (isSuccess: Boolean, message: String) -> Unit
    ) {
        _verifyingMcpType.value = type
        viewModelScope.launch {
            val result = mcpToolExecutor.verifyRealOAuthToken(type, token, customEndpoint)
            _verifyingMcpType.value = null
            result.onSuccess { (accName, email) ->
                mcpPreferences.updateOAuthSuccess(type, accName, email, token.trim())
                val successMsg = "تم التحقق الفعلي بنجاح! متصل بـ: $accName"
                _statusNotification.value = successMsg
                onResult(true, successMsg)
            }.onFailure { err ->
                val errorMsg = err.localizedMessage ?: "فشل التحقق من صحة الرمز لدى خوادم الخدمة."
                _statusNotification.value = errorMsg
                onResult(false, errorMsg)
            }
        }
    }

    fun disconnectOAuthAccount(type: McpIntegrationType) {
        mcpPreferences.disconnectOAuth(type)
        _statusNotification.value = "تم إلغاء ربط حساب ${type.displayNameArabic}"
    }

    fun autoDiscoverMcpServer(
        endpoint: String,
        token: String = "",
        onResult: (isSuccess: Boolean, message: String) -> Unit
    ) {
        _verifyingMcpType.value = McpIntegrationType.CUSTOM_MCP
        viewModelScope.launch {
            val result = mcpToolExecutor.verifyRealOAuthToken(McpIntegrationType.CUSTOM_MCP, token, endpoint)
            _verifyingMcpType.value = null
            result.onSuccess { (accName, ep) ->
                mcpPreferences.updateOAuthSuccess(McpIntegrationType.CUSTOM_MCP, accName, ep, token)
                val msg = "تم الاتصال الفعلي بخادم MCP ($accName)"
                _statusNotification.value = msg
                onResult(true, msg)
            }.onFailure { err ->
                val errorMsg = err.localizedMessage ?: "تعذر الاتصال بخادم MCP."
                _statusNotification.value = errorMsg
                onResult(false, errorMsg)
            }
        }
    }

    fun getActiveMcpToolsCount(): Int {
        val configs = mcpPreferences.getAllConfigs()
        var count = 0
        configs.forEach { (_, config) ->
            if (config.isEnabled && config.oauthStatus == OAuthStatus.CONNECTED) {
                count += availableMcpTools.count { it.serviceType == config.type }
            }
        }
        return count
    }

    fun clearAllConversations(onDone: () -> Unit) {
        viewModelScope.launch {
            db.conversationDao().deleteAllConversations()
            onDone()
        }
    }
}
