package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.ApiMessage
import com.example.data.api.NexusApiClient
import com.example.data.local.ConversationEntity
import com.example.data.local.MessageEntity
import com.example.data.local.NexusDatabase
import com.example.data.mcp.McpIntegrationType
import com.example.data.mcp.McpPreferences
import com.example.data.mcp.McpServiceConfig
import com.example.data.mcp.McpToolDefinition
import com.example.data.mcp.McpToolExecutor
import com.example.data.mcp.ToolCallResult
import com.example.data.preferences.ApiPreferences
import com.example.data.preferences.ApiSettings
import com.example.util.NetworkMonitor
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONObject

class ChatViewModel(application: Application) : AndroidViewModel(application) {
    private val db = NexusDatabase.getInstance(application)
    private val conversationDao = db.conversationDao()
    private val messageDao = db.messageDao()
    private val apiPreferences = ApiPreferences.getInstance(application)
    private val mcpPreferences = McpPreferences.getInstance(application)
    private val mcpToolExecutor = McpToolExecutor(application)
    private val apiClient = NexusApiClient()
    private val networkMonitor = NetworkMonitor(application)

    val apiSettings: StateFlow<ApiSettings> = apiPreferences.settingsFlow
    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val allConversations: StateFlow<List<ConversationEntity>> = conversationDao.getAllConversations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mcpConfigs: StateFlow<Map<McpIntegrationType, McpServiceConfig>> = mcpPreferences.configsFlow
    val allMcpTools: List<McpToolDefinition> = mcpToolExecutor.availableTools

    private val _currentConversationId = MutableStateFlow<Long>(-1L)
    val currentConversationId: StateFlow<Long> = _currentConversationId.asStateFlow()

    private val _currentConversation = MutableStateFlow<ConversationEntity?>(null)
    val currentConversation: StateFlow<ConversationEntity?> = _currentConversation.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _activeToolExecuting = MutableStateFlow<String?>(null)
    val activeToolExecuting: StateFlow<String?> = _activeToolExecuting.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Immediate reactive state for messages - ensures UI updates in 0ms!
    private val _messagesList = MutableStateFlow<List<MessageEntity>>(emptyList())
    val messages: StateFlow<List<MessageEntity>> = _messagesList.asStateFlow()

    private var activeRequestJob: Job? = null
    private var messagesObservationJob: Job? = null

    init {
        viewModelScope.launch {
            val latest = conversationDao.getLatestConversation()
            if (latest != null && _currentConversationId.value == -1L) {
                selectConversation(latest.id)
            }
        }
    }

    fun selectConversation(id: Long) {
        activeRequestJob?.cancel()
        _isGenerating.value = false
        _activeToolExecuting.value = null
        _errorMessage.value = null
        _currentConversationId.value = id

        messagesObservationJob?.cancel()
        messagesObservationJob = viewModelScope.launch {
            _currentConversation.value = conversationDao.getConversationById(id)
            messageDao.getMessagesForConversation(id).collect { roomMessages ->
                _messagesList.value = roomMessages
            }
        }
    }

    fun startNewConversation() {
        activeRequestJob?.cancel()
        messagesObservationJob?.cancel()
        _isGenerating.value = false
        _activeToolExecuting.value = null
        _errorMessage.value = null
        _currentConversationId.value = -1L
        _currentConversation.value = null
        _messagesList.value = emptyList()
    }

    fun deleteConversation(id: Long) {
        viewModelScope.launch {
            conversationDao.deleteConversationById(id)
            if (_currentConversationId.value == id) {
                startNewConversation()
            }
        }
    }

    fun getActiveToolsCount(): Int {
        val configs = mcpPreferences.getAllConfigs()
        return allMcpTools.count { tool ->
            configs[tool.serviceType]?.isEnabled == true
        }
    }

    fun sendMessage(userText: String) {
        val trimmed = userText.trim()
        if (trimmed.isEmpty() || _isGenerating.value) return

        val now = System.currentTimeMillis()
        val tempId = now

        // 1. Append user message to local reactive state immediately
        val userMsg = MessageEntity(
            id = tempId,
            conversationId = _currentConversationId.value.coerceAtLeast(0),
            role = "user",
            content = trimmed,
            timestamp = now
        )
        _messagesList.value = _messagesList.value + userMsg

        val settings = apiPreferences.getSettings()

        // Check if user is asking for a direct MCP tool execution or if API settings are missing
        val directToolMatch = detectDirectMcpIntent(trimmed)

        if (!settings.isConfigured && directToolMatch == null) {
            val assistantHelpMsg = MessageEntity(
                id = now + 1,
                conversationId = _currentConversationId.value.coerceAtLeast(0),
                role = "assistant",
                content = "⚠️ لم يتم ضبط مفتاح API بعد.\nيرجى فتح **الإعدادات** (النموذج ومزودو الخدمة) وضبط المفتاح، أو تجربة أدوات MCP المباشرة مثل: 'ابحث على الويب عن...' أو 'ابحث في كانفا عن...' أو 'ابحث في نوشن عن...'.",
                timestamp = now + 1,
                isError = true
            )
            _messagesList.value = _messagesList.value + assistantHelpMsg

            viewModelScope.launch {
                ensureConversationAndSaveMessages(trimmed, userMsg, assistantHelpMsg, settings)
            }
            return
        }

        _isGenerating.value = true
        _errorMessage.value = null

        activeRequestJob = viewModelScope.launch {
            var convId = _currentConversationId.value

            // Create or update conversation in DB
            if (convId <= 0) {
                val title = deriveTitle(trimmed)
                val newConv = ConversationEntity(
                    title = title,
                    modelUsed = settings.model.ifBlank { "Nexus AI" },
                    createdAt = now,
                    updatedAt = now
                )
                convId = conversationDao.insertConversation(newConv)
                _currentConversationId.value = convId
                _currentConversation.value = newConv.copy(id = convId)
                observeConversation(convId)
            } else {
                val existing = _currentConversation.value
                if (existing != null) {
                    conversationDao.updateConversation(
                        existing.copy(updatedAt = now, modelUsed = settings.model.ifBlank { "Nexus AI" })
                    )
                }
            }

            // Save user message to database
            val dbUserMsg = userMsg.copy(id = 0, conversationId = convId)
            messageDao.insertMessage(dbUserMsg)

            // Direct tool execution if requested directly and matched
            if (directToolMatch != null) {
                executeDirectMcpTool(convId, directToolMatch.first, directToolMatch.second, settings)
                return@launch
            }

            // Otherwise, construct dynamic system prompt containing active MCP tools
            val enrichedSystemPrompt = buildSystemPromptWithMcp(settings.systemPrompt)

            val history = _messagesList.value.filter { !it.isError }.map {
                ApiMessage(role = it.role, content = it.content)
            }

            // Execute real chat completion request
            val result = apiClient.sendChatMessage(
                baseUrl = settings.baseUrl,
                apiKey = settings.apiKey,
                model = settings.model,
                messages = history,
                systemPrompt = enrichedSystemPrompt,
                temperature = settings.temperature
            )

            result.onSuccess { reply ->
                // Check if the reply includes a tool call syntax
                val parsedToolCall = parseToolCallSyntax(reply)
                if (parsedToolCall != null) {
                    handleModelToolCall(convId, parsedToolCall.first, parsedToolCall.second, reply, settings)
                } else {
                    val assistantMsg = MessageEntity(
                        id = System.currentTimeMillis(),
                        conversationId = convId,
                        role = "assistant",
                        content = reply,
                        timestamp = System.currentTimeMillis(),
                        isError = false
                    )
                    _messagesList.value = _messagesList.value + assistantMsg
                    messageDao.insertMessage(assistantMsg.copy(id = 0))
                    _isGenerating.value = false
                }
            }.onFailure { err ->
                val errText = err.localizedMessage ?: "حدث خطأ أثناء معالجة الطلب."
                val errorMsg = MessageEntity(
                    id = System.currentTimeMillis(),
                    conversationId = convId,
                    role = "assistant",
                    content = "⚠️ $errText",
                    timestamp = System.currentTimeMillis(),
                    isError = true
                )
                _messagesList.value = _messagesList.value + errorMsg
                messageDao.insertMessage(errorMsg.copy(id = 0))
                _errorMessage.value = errText
                _isGenerating.value = false
            }
        }
    }

    /**
     * Executes a tool requested directly by the user (fallback or fast path)
     */
    private suspend fun executeDirectMcpTool(
        convId: Long,
        toolId: String,
        params: Map<String, String>,
        settings: ApiSettings
    ) {
        val toolDef = allMcpTools.firstOrNull { it.id == toolId }
        val serviceType = toolDef?.serviceType ?: McpIntegrationType.WEB_SEARCH
        val config = mcpPreferences.getConfig(serviceType)

        _activeToolExecuting.value = toolDef?.nameArabic ?: toolId

        val toolResult = mcpToolExecutor.executeTool(toolId, params, config)
        _activeToolExecuting.value = null

        val formattedToolContent = buildString {
            append("### ⚡ استدعاء أداة بروتوكول MCP: ${toolDef?.nameArabic ?: toolId}\n")
            append("**الحالة:** ${if (toolResult.isSuccess) "✅ تم التنفيذ بنجاح (${toolResult.latencyMs} م/ث)" else "❌ تعذر الاتصال"}\n\n")
            append(toolResult.outputText)
        }

        val toolMsg = MessageEntity(
            id = System.currentTimeMillis(),
            conversationId = convId,
            role = "assistant",
            content = formattedToolContent,
            timestamp = System.currentTimeMillis(),
            isError = !toolResult.isSuccess
        )
        _messagesList.value = _messagesList.value + toolMsg
        messageDao.insertMessage(toolMsg.copy(id = 0))
        _isGenerating.value = false
    }

    /**
     * Handles tool calls generated by the LLM
     */
    private suspend fun handleModelToolCall(
        convId: Long,
        toolId: String,
        params: Map<String, String>,
        originalReply: String,
        settings: ApiSettings
    ) {
        val toolDef = allMcpTools.firstOrNull { it.id == toolId }
        val serviceType = toolDef?.serviceType ?: McpIntegrationType.WEB_SEARCH
        val config = mcpPreferences.getConfig(serviceType)

        _activeToolExecuting.value = toolDef?.nameArabic ?: toolId

        val toolResult = mcpToolExecutor.executeTool(toolId, params, config)
        _activeToolExecuting.value = null

        val cleanReply = originalReply.replace(Regex("```tool_call:[^`]+```"), "").trim()

        val combinedContent = buildString {
            if (cleanReply.isNotBlank()) {
                append(cleanReply)
                append("\n\n")
            }
            append("### ⚡ أداة MCP: ${toolDef?.nameArabic ?: toolId}\n")
            append("**الخدمة:** ${serviceType.displayNameArabic} | **الحالة:** ${if (toolResult.isSuccess) "✅ نجاح (${toolResult.latencyMs} م/ث)" else "❌ خطأ"}\n\n")
            append(toolResult.outputText)
        }

        val toolMsg = MessageEntity(
            id = System.currentTimeMillis(),
            conversationId = convId,
            role = "assistant",
            content = combinedContent,
            timestamp = System.currentTimeMillis(),
            isError = !toolResult.isSuccess
        )
        _messagesList.value = _messagesList.value + toolMsg
        messageDao.insertMessage(toolMsg.copy(id = 0))
        _isGenerating.value = false
    }

    /**
     * Injects enabled MCP tools into the system prompt
     */
    private fun buildSystemPromptWithMcp(basePrompt: String): String {
        val configs = mcpPreferences.getAllConfigs()
        val enabledTools = allMcpTools.filter { tool ->
            configs[tool.serviceType]?.isEnabled == true
        }

        if (enabledTools.isEmpty()) return basePrompt

        val toolsCatalog = enabledTools.joinToString("\n") { tool ->
            "- ${tool.id}: ${tool.descriptionArabic} (مثال: ${tool.exampleUsage})"
        }

        return buildString {
            append(basePrompt)
            append("\n\n")
            append("=== دعم بروتوكول سياق النموذج (MCP Tools) ===\n")
            append("لديك أدوات MCP حقيقية متصلة يمكنك استدعاؤها لإنجاز مهام المستخدم:\n")
            append(toolsCatalog)
            append("\nعند الحاجة لاستدعاء أداة، أدرج في إجابتك استدعاء الأداة بالتنسيق:\n")
            append("```tool_call:{\"tool\": \"معرف_الأداة\", \"parameters\": {\"query\": \"النص\"}}```\n")
            append("وسيقوم خادم Nexus AI بتنفيذ الأداة تلقائياً.\n")
        }
    }

    /**
     * Detects if user typed a direct intent to invoke a tool
     */
    private fun detectDirectMcpIntent(text: String): Pair<String, Map<String, String>>? {
        val lower = text.trim()

        // Direct cURL command or URL fetch request
        if (lower.startsWith("curl ") || lower.startsWith("curl_fetch ") || lower.startsWith("تصفح ") || lower.startsWith("افحص الرابط ")) {
            val url = lower.substringAfter(" ").trim()
            if (url.contains("http://") || url.contains("https://") || url.contains(".")) {
                return Pair("curl_fetch", mapOf("url" to url))
            }
        }

        // Web search (Arabic & English intents)
        if (lower.startsWith("ابحث على الويب") || lower.startsWith("ابحث في الويب") || 
            lower.startsWith("ابحث في جوجل") || lower.startsWith("ابحث عن") || 
            lower.startsWith("بحث عن") || lower.startsWith("search ")) {
            val q = when {
                lower.contains(" عن ") -> lower.substringAfter(" عن ")
                lower.startsWith("search ") -> lower.substringAfter("search ")
                else -> lower.substringAfter(" ")
            }.trim()
            return Pair("web_search", mapOf("query" to q.ifBlank { lower }))
        }

        // Notion
        if (lower.contains("نوشن") || lower.contains("notion")) {
            return if (lower.contains("أنشئ") || lower.contains("اكتب") || lower.contains("سجل")) {
                Pair("notion_create_page", mapOf("title" to lower.take(40), "content" to lower))
            } else {
                val q = lower.substringAfter("عن").trim()
                Pair("notion_search", mapOf("query" to q.ifBlank { "ملاحظات" }))
            }
        }

        // Canva
        if (lower.contains("كانفا") || lower.contains("canva")) {
            return if (lower.contains("أنشئ") || lower.contains("صمم")) {
                Pair("canva_create_design", mapOf("title" to lower.take(40), "format" to "1080x1080"))
            } else {
                val q = lower.substringAfter("عن").trim()
                Pair("canva_search_templates", mapOf("query" to q.ifBlank { "قوالب" }))
            }
        }

        // Adobe
        if (lower.contains("أدوبي") || lower.contains("ادوبي") || lower.contains("adobe")) {
            return if (lower.contains("ولد") || lower.contains("صمم") || lower.contains("شعار")) {
                Pair("adobe_generate_asset", mapOf("prompt" to lower, "style" to "فوتوغرافي واقعي"))
            } else {
                val q = lower.substringAfter("عن").trim()
                Pair("adobe_asset_search", mapOf("keywords" to q.ifBlank { "تصميم" }))
            }
        }

        // GitHub
        if (lower.contains("جيت هاب") || lower.contains("غيتهاب") || lower.contains("github")) {
            val q = lower.substringAfter("عن").trim()
            return Pair("github_search_repos", mapOf("query" to q.ifBlank { "android compose" }))
        }

        // Auto MCP discovery
        if (lower.contains("توصيل mcp") || lower.contains("mcp connect") || lower.contains("خادم mcp")) {
            return Pair("mcp_auto_connect", emptyMap())
        }

        return null
    }

    /**
     * Parses ```tool_call:{"tool": "...", "parameters": {...}}```
     */
    private fun parseToolCallSyntax(text: String): Pair<String, Map<String, String>>? {
        val regex = Regex("```tool_call:\\s*(\\{.*?\\})\\s*```", RegexOption.DOT_MATCHES_ALL)
        val match = regex.find(text) ?: return null
        return try {
            val jsonStr = match.groupValues[1]
            val obj = JSONObject(jsonStr)
            val toolName = obj.optString("tool", "")
            val paramsObj = obj.optJSONObject("parameters") ?: JSONObject()
            val paramsMap = mutableMapOf<String, String>()
            val keys = paramsObj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                paramsMap[k] = paramsObj.optString(k, "")
            }
            if (toolName.isNotBlank()) Pair(toolName, paramsMap) else null
        } catch (_: Exception) {
            null
        }
    }

    private suspend fun ensureConversationAndSaveMessages(
        firstMessage: String,
        userMsg: MessageEntity,
        assistantMsg: MessageEntity,
        settings: ApiSettings
    ) {
        var convId = _currentConversationId.value
        if (convId <= 0) {
            val title = deriveTitle(firstMessage)
            val newConv = ConversationEntity(
                title = title,
                modelUsed = settings.model.ifBlank { "Nexus AI" }
            )
            convId = conversationDao.insertConversation(newConv)
            _currentConversationId.value = convId
            _currentConversation.value = newConv.copy(id = convId)
            observeConversation(convId)
        }
        messageDao.insertMessage(userMsg.copy(id = 0, conversationId = convId))
        messageDao.insertMessage(assistantMsg.copy(id = 0, conversationId = convId))
    }

    private fun observeConversation(id: Long) {
        messagesObservationJob?.cancel()
        messagesObservationJob = viewModelScope.launch {
            messageDao.getMessagesForConversation(id).collect { roomMessages ->
                if (roomMessages.isNotEmpty()) {
                    _messagesList.value = roomMessages
                }
            }
        }
    }

    fun clearCurrentConversation() {
        val convId = _currentConversationId.value
        if (convId > 0) {
            viewModelScope.launch {
                messageDao.deleteMessagesForConversation(convId)
                _messagesList.value = emptyList()
            }
        } else {
            _messagesList.value = emptyList()
        }
    }

    fun stopGeneration() {
        activeRequestJob?.cancel()
        _isGenerating.value = false
        _activeToolExecuting.value = null
    }

    private fun deriveTitle(firstMessage: String): String {
        val clean = firstMessage.lines().firstOrNull()?.trim().orEmpty()
        return if (clean.length > 35) {
            clean.take(35) + "…"
        } else if (clean.isEmpty()) {
            "محادثة جديدة"
        } else {
            clean
        }
    }
}
