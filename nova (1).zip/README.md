# NOVA — Private Android Media Downloader & Queue Manager

NOVA is a privacy-first, ad-free, high-performance Android media downloader and queue manager built with modern Android standards: Kotlin, Jetpack Compose (Material 3), Room Database, OkHttp, and Android Foreground Services.

Unlike typical downloaders loaded with aggressive advertisements, telemetry tracking, and bloated fake buttons, NOVA focuses strictly on **reliability, transparency, and user privacy**.

---

## 🚀 Key Features

### 1. Smart Link Analyzer
- **Real Probing Engine**: Dispatches HTTP HEAD or byte-range GET requests to inspect server responses and remote headers without downloading unwanted full bodies.
- **Header Inspection**: Accurately extracts `Content-Type`, `Content-Length`, `Accept-Ranges`, `Server`, and `ETag`.
- **RFC 5987 / 6266 Filename Resolution**: Decodes `filename*="UTF-8''..."` and standard `filename="..."` headers, with fallback to decoded URL path segments and MIME-based extension derivation.
- **Resumability Detection**: Determines whether the remote server supports HTTP 206 Partial Content byte ranges (`bytes=X-`).
- **Webpage vs Direct Media Detection**: Clearly warns users when a link points to an HTML webpage rather than a directly downloadable media asset.
- **One-Tap Test Presets**: Includes verified direct media URLs (Big Buck Bunny MP4, Elephants Dream MP4, SoundHelix MP3, Sample PDF) for immediate verification.

### 2. Universal Download Engine
- **Multi-Task Queue Manager**: Concurrent worker pool respecting user-configured concurrency limits (1 to 5 simultaneous downloads).
- **HTTP Range Resumable Downloads**: Checks existing partial files (`.nova_tmp`). If Range requests are supported and the server returns HTTP 206, it streams and appends remaining bytes. If 200 OK is returned, it safely resets and downloads from byte 0.
- **Accurate Real-Time Telemetry**:
  - Sliding delta byte window calculates exact download speed (e.g., `1.8 MB/s`).
  - Remaining time estimation (ETA) based on active speed and remaining bytes.
  - Byte-accurate progress percentages (`14.2 MB / 45.0 MB (31%)`).
- **Atomic File Management**: Downloads stream into temporary files and are renamed/moved to the destination folder only upon verified completion.
- **Storage Protection**: Queries device storage space via `StatFs` before commencing downloads, preventing corrupted transfers due to full storage.
- **Network Interruption Recovery**: Configurable automatic retry limit (0 to 5) with exponential backoff on `IOException`.
- **Full Task Controls**: Pause, Resume, Cancel, and Retry with immediate thread-safe cancellation and state persistence.

### 3. Android Foreground Service & Background Downloads
- **Foreground Service**: Registered as `foregroundServiceType="dataSync"` for Android 14+ compatibility.
- **Persistent Progress Notification**: Shows active filename, transfer speed, progress bar (percentage or indeterminate), and ETA.
- **Interactive Notification Actions**: Direct notification action buttons to Pause, Resume, or Cancel tasks without opening the application.
- **Restart Recovery**: Interrupted active downloads from unexpected process termination are safely recorded and restored to `PAUSED` state on next launch.

### 4. File Management & Media Library
- **Completed Downloads**: Organized view of all finished files.
- **Media Type Filtering**: Filter by All, Video, Audio, or Documents/Archives.
- **Instant Search**: Real-time filename search.
- **Storage Metrics**: Total disk space utilized by downloaded media files.
- **Android Intent Sharing & Opening**: Integrates with Android `FileProvider` (`content://`) to safely open downloaded files in default media players or share them to other apps.
- **File Deletion**: Safely removes records and deletes the physical files from storage.

### 5. Privacy & Zero-Tracking Guarantee
- **No Advertisements**: Zero ad SDKs, banners, interstitials, or tracking tokens.
- **No Cloud Account Required**: Operates 100% locally on your device.
- **Zero Remote Telemetry**: Does not contact developer servers. HTTP/HTTPS connections are dispatched exclusively to the download targets requested by the user.
- **Storage & Cache Maintenance**: One-click cleanup to flush temporary `.nova_tmp` partial files and clear completed history.

---

## 🏛️ Architecture & Tech Stack

```
com.example
├── NovaApplication.kt              // App entry & singleton initialization
├── MainActivity.kt                 // Edge-to-edge Compose activity & Share Intent handler
├── analyzer/
│   ├── LinkAnalyzer.kt             // Network probing & header resolution
│   └── LinkAnalysisResult.kt       // Resource metadata data model
├── data/
│   ├── NovaDatabase.kt             // Room Database (SQLite)
│   ├── Converters.kt               // Room type converters
│   ├── model/
│   │   ├── DownloadTaskEntity.kt   // Persistent task entity
│   │   ├── DownloadStatus.kt       // State machine enum
│   │   └── AppSettingEntity.kt     // Settings key-value entity
│   ├── dao/
│   │   ├── DownloadDao.kt          // Reactive Flow DAO
│   │   └── SettingDao.kt           // Settings DAO
│   └── repository/
│       └── SettingsRepository.kt   // Config preferences abstraction
├── download/
│   ├── engine/
│   │   └── DownloadEngine.kt       // Queue, Range streaming, speed & ETA
│   └── service/
│       └── DownloadForegroundService.kt // Persistent Android notification & actions
└── ui/
    ├── MainViewModel.kt            // StateFlow coordination & user actions
    ├── theme/                      // Nova dark/light high-contrast theme
    └── screens/
        ├── MainScaffold.kt         // NavigationBar & Notification permissions
        ├── AnalyzerScreen.kt       // Probing & Link input
        ├── QueueScreen.kt          // Active downloads & progress
        ├── LibraryScreen.kt        // Completed files & sharing
        └── SettingsScreen.kt       // Preferences & privacy report
```

---

## 🧪 Automated Testing

All tests are implemented using JUnit 4 and Robolectric for fast, deterministic JVM execution:

- **`NovaDatabaseTest`**:
  - In-memory Room database initialization.
  - Inserting tasks, querying active vs completed queues.
  - State machine transitions (`QUEUED` -> `DOWNLOADING` -> `COMPLETED`).
  - Interrupted task detection and restoration.
  - SettingDao persistence.
- **`LinkAnalyzerTest`**:
  - Byte formatting logic (`formatBytes`).
  - Invalid protocol rejection (rejects non-HTTP/HTTPS URLs).
  - Malformed URL handling.
- **`DownloadTaskEntityTest`**:
  - Progress percentage calculations.
  - Indeterminate stream handling (`totalBytes = -1`).
  - Status flags (`isActive`, `isTerminal`).

To execute tests:
```bash
gradle :app:testDebugUnitTest
```

---

## 🛠️ Build & Installation

### Requirements
- Android SDK 36 (targetSdk 36, minSdk 24)
- JDK 17
- Gradle 9.x

### Build Debug APK
```bash
gradle :app:assembleDebug
```
The resulting APK will be generated at:
`app/build/outputs/apk/debug/app-debug.apk`

---

## 📋 Implementation Status & Roadmap

| Feature / Component | Status | Notes |
| :--- | :--- | :--- |
| **Direct HTTP/HTTPS Downloads** | ✅ Implemented | Full streaming via OkHttp |
| **HTTP Range Resumable Downloads** | ✅ Implemented | Partial content (206) appending |
| **Queue & Concurrency Management** | ✅ Implemented | Configurable (1–5 simultaneous) |
| **Speed & ETA Calculation** | ✅ Implemented | Real-time sliding window calculations |
| **Persistent Task Database** | ✅ Implemented | Room SQLite with Flow |
| **Foreground Service & Notification** | ✅ Implemented | Shows speed, ETA, progress, and actions |
| **Storage & Disk Checks** | ✅ Implemented | Pre-download checks via `StatFs` |
| **Share Intent Integration** | ✅ Implemented | Share links from browsers directly to NOVA |
| **File Provider Sharing & Opening** | ✅ Implemented | Secure `content://` URI sharing |
| **Settings & Privacy Report** | ✅ Implemented | Concurrency tuning, temp cleanup |
| **Built-in Media Player** | ✅ Implemented | Full video/audio playback, seekbar, speeds, playlist navigation |
| **Built-in Lightweight Browser** | ✅ Implemented | WebView with DuckDuckGo search & direct media link detection |
| **Arabic & English Localization** | ✅ Implemented | Full RTL support & Arabic translations |
