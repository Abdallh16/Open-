package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "download_tasks")
data class DownloadTaskEntity(
    @PrimaryKey
    val id: String,
    val url: String,
    val filename: String,
    val mimeType: String = "application/octet-stream",
    val totalBytes: Long = -1L,
    val downloadedBytes: Long = 0L,
    val status: DownloadStatus = DownloadStatus.QUEUED,
    val speedBytesPerSec: Long = 0L,
    val etaSeconds: Long = -1L,
    val etag: String? = null,
    val isResumable: Boolean = false,
    val errorReason: String? = null,
    val filePath: String,
    val tempFilePath: String,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null,
    val retryCount: Int = 0
) {
    val progressPercent: Float
        get() = if (totalBytes > 0) {
            (downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }

    val isIndeterminate: Boolean
        get() = totalBytes <= 0 && status == DownloadStatus.DOWNLOADING
}
