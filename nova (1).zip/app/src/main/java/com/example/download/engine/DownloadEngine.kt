package com.example.download.engine

import android.content.Context
import android.os.StatFs
import android.util.Log
import com.example.analyzer.LinkAnalysisResult
import com.example.data.dao.DownloadDao
import com.example.data.model.DownloadStatus
import com.example.data.model.DownloadTaskEntity
import com.example.data.repository.SettingsRepository
import com.example.data.repository.UserSettings
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class DownloadEngine(
    private val context: Context,
    private val downloadDao: DownloadDao,
    private val settingsRepository: SettingsRepository,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()
) {
    companion object {
        private const val TAG = "DownloadEngine"
        private const val BUFFER_SIZE = 32 * 1024 // 32 KB buffer
        private const val UPDATE_INTERVAL_MS = 500L
    }

    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val activeJobs = ConcurrentHashMap<String, Job>()
    private val runningTasks = ConcurrentHashMap.newKeySet<String>()
    private val queueMutex = Mutex()
    private val pauseFlags = ConcurrentHashMap<String, AtomicBoolean>()

    // Call this at application launch to recover interrupted downloads
    fun initialize() {
        engineScope.launch {
            try {
                // Any tasks that were left in DOWNLOADING or CONNECTING when the process was killed
                // get moved back to QUEUED or PAUSED safely.
                val interrupted = downloadDao.getInterruptedTasks()
                for (task in interrupted) {
                    downloadDao.updateStatus(task.id, DownloadStatus.PAUSED, "Restored after app restart")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to restore interrupted tasks: ${e.message}", e)
            }
        }
    }

    suspend fun enqueueDownload(
        url: String,
        filename: String,
        mimeType: String,
        totalBytes: Long,
        isResumable: Boolean,
        customDir: File? = null
    ): DownloadTaskEntity = withContext(Dispatchers.IO) {
        val destDir = customDir ?: settingsRepository.getDefaultDownloadDirectory()
        if (!destDir.exists()) {
            destDir.mkdirs()
        }

        val targetFile = resolveUniqueFile(destDir, filename)
        val tempDir = settingsRepository.getTempDirectory()
        val taskId = java.util.UUID.randomUUID().toString()
        val tempFile = File(tempDir, "$taskId.nova_tmp")

        val task = DownloadTaskEntity(
            id = taskId,
            url = url,
            filename = targetFile.name,
            mimeType = mimeType,
            totalBytes = totalBytes,
            downloadedBytes = 0L,
            status = DownloadStatus.QUEUED,
            speedBytesPerSec = 0L,
            etaSeconds = -1L,
            isResumable = isResumable,
            filePath = targetFile.absolutePath,
            tempFilePath = tempFile.absolutePath,
            createdAt = System.currentTimeMillis()
        )

        downloadDao.insertTask(task)
        processQueue()
        return@withContext task
    }

    fun pauseDownload(taskId: String) {
        val flag = pauseFlags.getOrPut(taskId) { AtomicBoolean(false) }
        flag.set(true)
        val job = activeJobs.remove(taskId)
        job?.cancel()
        runningTasks.remove(taskId)

        engineScope.launch {
            downloadDao.updateProgress(
                id = taskId,
                downloaded = getTempFileSize(taskId),
                total = -1L,
                speed = 0L,
                eta = 0L,
                status = DownloadStatus.PAUSED
            )
            processQueue()
        }
    }

    fun resumeDownload(taskId: String) {
        engineScope.launch {
            val task = downloadDao.getTaskById(taskId) ?: return@launch
            if (task.status == DownloadStatus.PAUSED || task.status == DownloadStatus.FAILED) {
                pauseFlags[taskId]?.set(false)
                downloadDao.updateStatus(taskId, DownloadStatus.QUEUED, null)
                processQueue()
            }
        }
    }

    fun cancelDownload(taskId: String) {
        val flag = pauseFlags.getOrPut(taskId) { AtomicBoolean(false) }
        flag.set(true)
        val job = activeJobs.remove(taskId)
        job?.cancel()
        runningTasks.remove(taskId)

        engineScope.launch {
            val task = downloadDao.getTaskById(taskId)
            if (task != null) {
                // Clean up partial file
                try {
                    val temp = File(task.tempFilePath)
                    if (temp.exists()) temp.delete()
                } catch (_: Exception) {}

                downloadDao.updateStatus(taskId, DownloadStatus.CANCELLED, "Download cancelled by user")
            }
            processQueue()
        }
    }

    fun retryDownload(taskId: String) {
        engineScope.launch {
            val task = downloadDao.getTaskById(taskId) ?: return@launch
            pauseFlags[taskId]?.set(false)
            downloadDao.updateTask(task.copy(status = DownloadStatus.QUEUED, errorReason = null, retryCount = 0))
            processQueue()
        }
    }

    fun deleteDownload(taskId: String, deleteFileOnDisk: Boolean) {
        cancelDownload(taskId)
        engineScope.launch {
            val task = downloadDao.getTaskById(taskId)
            if (task != null) {
                if (deleteFileOnDisk) {
                    try {
                        val file = File(task.filePath)
                        if (file.exists()) file.delete()
                        val temp = File(task.tempFilePath)
                        if (temp.exists()) temp.delete()
                    } catch (_: Exception) {}
                }
                downloadDao.deleteTaskById(taskId)
            }
        }
    }

    fun processQueue() {
        engineScope.launch {
            queueMutex.withLock {
                val settings = settingsRepository.settingsFlow.firstOrNull() ?: UserSettings()
                val maxConcurrent = settings.maxConcurrentDownloads.coerceIn(1, 5)

                while (runningTasks.size < maxConcurrent) {
                    // Pick the oldest QUEUED task
                    val pendingTasks = downloadDao.getActiveDownloadsFlow().firstOrNull() ?: emptyList()
                    val nextTask = pendingTasks.firstOrNull { it.status == DownloadStatus.QUEUED && !runningTasks.contains(it.id) }
                        ?: break

                    runningTasks.add(nextTask.id)
                    val job = engineScope.launch {
                        executeDownload(nextTask.id)
                    }
                    activeJobs[nextTask.id] = job
                }
            }
        }
    }

    private suspend fun executeDownload(taskId: String) = withContext(Dispatchers.IO) {
        var currentTask = downloadDao.getTaskById(taskId)
        if (currentTask == null) {
            runningTasks.remove(taskId)
            return@withContext
        }

        val pauseFlag = pauseFlags.getOrPut(taskId) { AtomicBoolean(false) }
        pauseFlag.set(false)

        val settings = settingsRepository.settingsFlow.firstOrNull() ?: UserSettings()
        var attempt = 0
        var success = false

        while (attempt <= settings.retryLimit && !success && !pauseFlag.get() && isActive) {
            try {
                attempt++
                downloadDao.updateStatus(taskId, DownloadStatus.CONNECTING, null)
                performDownloadStream(taskId, pauseFlag)
                success = true
            } catch (ce: CancellationException) {
                // User paused or cancelled
                Log.d(TAG, "Download $taskId was cancelled/paused")
                break
            } catch (ioe: IOException) {
                Log.w(TAG, "Download $taskId attempt $attempt failed: ${ioe.message}")
                if (pauseFlag.get() || !isActive) {
                    break
                }
                if (attempt > settings.retryLimit) {
                    downloadDao.updateStatus(
                        taskId,
                        DownloadStatus.FAILED,
                        "Network error after $attempt attempts: ${ioe.localizedMessage ?: "Connection interrupted"}"
                    )
                } else {
                    // Wait with exponential backoff before retry
                    delay(1000L * attempt)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Download $taskId encountered fatal error: ${e.message}", e)
                downloadDao.updateStatus(
                    taskId,
                    DownloadStatus.FAILED,
                    e.localizedMessage ?: "Unexpected error"
                )
                break
            }
        }

        runningTasks.remove(taskId)
        activeJobs.remove(taskId)
        processQueue()
    }

    private suspend fun performDownloadStream(taskId: String, pauseFlag: AtomicBoolean) {
        val task = downloadDao.getTaskById(taskId) ?: throw IOException("Task not found")
        val tempFile = File(task.tempFilePath)
        val targetFile = File(task.filePath)

        val existingBytes = if (tempFile.exists()) tempFile.length() else 0L

        // Check storage space
        val parentDir = targetFile.parentFile ?: context.filesDir
        val stat = StatFs(parentDir.absolutePath)
        val availableBytes = stat.availableBlocksLong * stat.blockSizeLong
        val bytesNeeded = if (task.totalBytes > 0) task.totalBytes - existingBytes else 10 * 1024 * 1024L
        if (availableBytes < bytesNeeded) {
            throw IOException("Insufficient storage space on device. Available: ${LinkAnalysisResult.formatBytes(availableBytes)}, required: ${LinkAnalysisResult.formatBytes(bytesNeeded)}")
        }

        val reqBuilder = Request.Builder()
            .url(task.url)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; Mobile) NOVA/1.0")

        var isAppend = false
        if (existingBytes > 0 && task.isResumable) {
            reqBuilder.header("Range", "bytes=$existingBytes-")
            isAppend = true
        }

        val request = reqBuilder.build()
        val response = client.newCall(request).execute()

        response.use { res ->
            val code = res.code
            if (code != 200 && code != 206) {
                throw IOException("Server returned HTTP $code: ${res.message}")
            }

            // Determine if range request was accepted
            var startByte = 0L
            var effectiveTotal = task.totalBytes

            if (code == 206) {
                startByte = existingBytes
                val contentRange = res.header("Content-Range")
                if (contentRange != null) {
                    val slash = contentRange.lastIndexOf('/')
                    if (slash != -1 && slash < contentRange.length - 1) {
                        contentRange.substring(slash + 1).trim().toLongOrNull()?.let {
                            effectiveTotal = it
                        }
                    }
                }
            } else {
                // Server responded 200 OK -> ignored Range header or fresh download
                startByte = 0L
                res.header("Content-Length")?.toLongOrNull()?.let {
                    effectiveTotal = it
                }
                if (tempFile.exists()) {
                    tempFile.delete()
                }
            }

            val body = res.body ?: throw IOException("Empty response body from server")
            val inputStream: InputStream = body.byteStream()

            tempFile.parentFile?.mkdirs()
            val outputStream = FileOutputStream(tempFile, code == 206 && existingBytes > 0)

            downloadDao.updateProgress(
                id = taskId,
                downloaded = startByte,
                total = effectiveTotal,
                speed = 0L,
                eta = -1L,
                status = DownloadStatus.DOWNLOADING
            )

            val buffer = ByteArray(BUFFER_SIZE)
            var bytesCopied = startByte
            var lastUpdateBytes = startByte
            var lastUpdateTime = System.currentTimeMillis()

            try {
                var read: Int
                while (inputStream.read(buffer).also { read = it } != -1) {
                    if (pauseFlag.get()) {
                        throw CancellationException("Download paused by user")
                    }

                    outputStream.write(buffer, 0, read)
                    bytesCopied += read

                    val now = System.currentTimeMillis()
                    val timeDelta = now - lastUpdateTime
                    if (timeDelta >= UPDATE_INTERVAL_MS) {
                        val bytesDelta = bytesCopied - lastUpdateBytes
                        val speed = if (timeDelta > 0) (bytesDelta * 1000L) / timeDelta else 0L
                        val remainingBytes = if (effectiveTotal > 0) effectiveTotal - bytesCopied else -1L
                        val eta = if (speed > 0 && remainingBytes > 0) remainingBytes / speed else -1L

                        downloadDao.updateProgress(
                            id = taskId,
                            downloaded = bytesCopied,
                            total = effectiveTotal,
                            speed = speed,
                            eta = eta,
                            status = DownloadStatus.DOWNLOADING
                        )

                        lastUpdateTime = now
                        lastUpdateBytes = bytesCopied
                    }
                }
                outputStream.flush()
            } finally {
                try { outputStream.close() } catch (_: Exception) {}
                try { inputStream.close() } catch (_: Exception) {}
            }

            // Verify completion
            if (effectiveTotal > 0 && bytesCopied < effectiveTotal) {
                throw IOException("Download stream terminated prematurely ($bytesCopied of $effectiveTotal bytes)")
            }

            // Rename .part to targetFile
            if (targetFile.exists()) {
                targetFile.delete()
            }
            val renamed = tempFile.renameTo(targetFile)
            if (!renamed) {
                // Try manual copy if atomic rename failed across filesystems
                tempFile.copyTo(targetFile, overwrite = true)
                tempFile.delete()
            }

            downloadDao.markCompleted(taskId)
        }
    }

    private suspend fun getTempFileSize(taskId: String): Long {
        val task = downloadDao.getTaskById(taskId) ?: return 0L
        val file = File(task.tempFilePath)
        return if (file.exists()) file.length() else task.downloadedBytes
    }

    private fun resolveUniqueFile(directory: File, baseName: String): File {
        var file = File(directory, baseName)
        if (!file.exists()) return file

        val dotIdx = baseName.lastIndexOf('.')
        val namePart = if (dotIdx != -1) baseName.substring(0, dotIdx) else baseName
        val extPart = if (dotIdx != -1) baseName.substring(dotIdx) else ""

        var counter = 1
        while (file.exists()) {
            file = File(directory, "$namePart ($counter)$extPart")
            counter++
        }
        return file
    }
}
